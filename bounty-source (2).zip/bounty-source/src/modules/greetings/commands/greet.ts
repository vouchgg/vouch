/**
 * `,welcome …`, `,goodbye …`, `,boostmsg …`
 *
 * One builder, three trees. The three differ only in which row they write and
 * a few words of copy, so generating them keeps the behaviour identical —
 * which matters, because a server owner who learns `,welcome` has also
 * learned the other two.
 */

import { ChannelType, PermissionFlagsBits, type TextChannel } from 'discord.js';
import { defineCommand, type Command, type Context } from '../../../core/command.js';
import { UsageError } from '../../../core/errors.js';
import { db, schema } from '../../../db/index.js';
import { GreetingEngine, render, VARIABLES, previewContext, type GreetKind } from '../engine.js';

async function save(
  ctx: Context,
  kind: GreetKind,
  patch: Partial<typeof schema.greetConfigs.$inferInsert>,
): Promise<void> {
  await db.insert(schema.greetConfigs)
    .values({ guildId: ctx.guild.id, kind, ...patch })
    .onConflictDoUpdate({
      target: [schema.greetConfigs.guildId, schema.greetConfigs.kind],
      set: { ...patch, updatedAt: new Date() },
    });
  await GreetingEngine.invalidate(ctx.guild.id, kind);
}

async function load(ctx: Context, kind: GreetKind) {
  return ctx.client.greetings.config(ctx.guild.id, kind);
}

function resolveChannel(ctx: Context): TextChannel {
  const raw = ctx.args[0];
  if (!raw) throw new UsageError('Name a channel.');
  const id = raw.match(/^<#(\d{17,20})>$/)?.[1] ?? (/^\d{17,20}$/.test(raw) ? raw : null);
  const channel = id
    ? ctx.guild.channels.cache.get(id)
    : ctx.guild.channels.cache.find((c) => c.name === raw.replace(/^#/, ''));

  if (!channel || channel.type !== ChannelType.GuildText) {
    throw new UsageError(`No text channel matched \`${raw.slice(0, 40)}\`.`);
  }
  const perms = channel.permissionsFor(ctx.me);
  if (!perms?.has(PermissionFlagsBits.SendMessages) || !perms.has(PermissionFlagsBits.EmbedLinks)) {
    throw new UsageError(`Bounty cannot post in ${channel}.`,
      'It needs View Channel, Send Messages and Embed Links there.');
  }
  return channel;
}

interface GreetWords {
  /** "welcome card", used mid-sentence. */
  noun: string;
  /** What fires it. */
  trigger: string;
  sample: string;
}

const WORDS: Record<GreetKind, GreetWords> = {
  welcome: {
    noun: 'welcome card',
    trigger: 'someone joins',
    sample: '{user} joined. You are our {guild.count.ordinal} member.',
  },
  goodbye: {
    noun: 'goodbye card',
    trigger: 'someone leaves',
    sample: '{user.name} left. {guild.count} left in {guild.name}.',
  },
  boost: {
    noun: 'boost card',
    trigger: 'someone boosts the server',
    sample: 'Thank you {user}, that is boost number {guild.boosts}.',
  },
};

function buildTree(kind: GreetKind, name: string, aliases: string[]): Command {
  const w = WORDS[kind];

  const children: Command[] = [
    {
      name: 'channel', aliases: ['setup', 'set'], module: 'Utility',
      description: `Choose where the ${w.noun} is posted`,
      usage: `${name} channel <#channel>`,
      execute: async (ctx) => {
        const channel = resolveChannel(ctx);
        await save(ctx, kind, { channelId: channel.id, enabled: true });
        const existing = await load(ctx, kind);
        return ctx.ok(
          `${cap(w.noun)}s go to ${channel}.` +
          (existing?.content || existing?.embedJson
            ? ''
            : `\nSet what it says with \`${ctx.guildConfig.prefix}${name} message <text>\`.`),
        );
      },
    },
    {
      name: 'message', aliases: ['msg', 'text'], module: 'Utility',
      description: `Set the text sent when ${w.trigger}`,
      usage: `${name} message <text>`,
      examples: [`${name} message ${w.sample}`],
      execute: async (ctx) => {
        const text = ctx.rest();
        if (!text) {
          throw new UsageError('Give the message text.',
            `Try: \`${ctx.guildConfig.prefix}${name} message ${w.sample}\``);
        }
        if (text.length > 1900) throw new UsageError('Keep it under 1900 characters.');
        await save(ctx, kind, { content: text, enabled: true });
        return ctx.ok(`Saved. Preview it with \`${ctx.guildConfig.prefix}${name} test\`.`);
      },
    },
    {
      name: 'embed', module: 'Utility',
      description: `Set the ${w.noun} from embed JSON`,
      usage: `${name} embed <json|none>`,
      execute: async (ctx) => {
        const raw = ctx.rest().replace(/^```(?:json)?|```$/g, '').trim();
        if (!raw || raw.toLowerCase() === 'none') {
          await save(ctx, kind, { embedJson: null });
          return ctx.ok(`The ${w.noun} is plain text now.`);
        }
        let parsed: Record<string, unknown>;
        try { parsed = JSON.parse(raw) as Record<string, unknown>; }
        catch {
          throw new UsageError('That is not valid JSON.',
            'Build it at discohook.org, then paste the embed object here.');
        }
        await save(ctx, kind, { embedJson: parsed, enabled: true });
        return ctx.ok(`Embed saved. Check it with \`${ctx.guildConfig.prefix}${name} test\`.`);
      },
    },
    {
      name: 'test', aliases: ['preview'], module: 'Utility',
      description: `Send yourself a preview of the ${w.noun}`,
      execute: async (ctx) => {
        const config = await load(ctx, kind);
        if (!config) throw new UsageError(`No ${w.noun} is set up yet.`);
        const payload = render(config, previewContext(ctx.member));
        await ctx.channel.send(payload);
        return ctx.ok(`That is what it looks like when ${w.trigger}.`);
      },
    },
    {
      name: 'delete', aliases: ['deleteafter', 'cleanup'], module: 'Utility',
      description: `Delete the ${w.noun} after a number of seconds`,
      usage: `${name} delete <seconds|off>`,
      execute: async (ctx) => {
        const raw = ctx.args[0]?.toLowerCase();
        if (!raw || raw === 'off' || raw === 'never') {
          await save(ctx, kind, { deleteAfter: 0 });
          return ctx.ok(`${cap(w.noun)}s stay in the channel.`);
        }
        const seconds = Number.parseInt(raw, 10);
        if (Number.isNaN(seconds) || seconds < 5 || seconds > 3600) {
          throw new UsageError('Give a number of seconds between 5 and 3600, or `off`.');
        }
        await save(ctx, kind, { deleteAfter: seconds });
        return ctx.ok(`${cap(w.noun)}s are removed after ${seconds} seconds.`);
      },
    },
    {
      name: 'variables', aliases: ['vars', 'placeholders'], module: 'Utility',
      description: 'List every variable you can put in the message',
      execute: async (ctx) => ctx.send({
        title: 'Variables',
        description: VARIABLES.map(([token, what]) => `\`${token}\` — ${what}`).join('\n'),
        footer: 'They work in the text, the embed, and the DM',
      }),
    },
    {
      name: 'toggle', aliases: ['enable', 'disable'], module: 'Utility',
      description: `Turn the ${w.noun} on or off without losing it`,
      execute: async (ctx) => {
        const config = await load(ctx, kind);
        if (!config) throw new UsageError(`No ${w.noun} is set up yet.`);
        await save(ctx, kind, { enabled: !config.enabled });
        return ctx.ok(config.enabled
          ? `${cap(w.noun)}s are paused. Everything is kept.`
          : `${cap(w.noun)}s are back on.`);
      },
    },
    {
      name: 'config', aliases: ['show', 'view'], module: 'Utility',
      description: `Show the current ${w.noun} setup`,
      execute: async (ctx) => {
        const config = await load(ctx, kind);
        if (!config) {
          return ctx.warn(`Nothing set up. Start with \`${ctx.guildConfig.prefix}${name} channel #channel\`.`);
        }
        return ctx.send({
          title: cap(w.noun),
          fields: [
            { name: 'Channel', value: config.channelId ? `<#${config.channelId}>` : 'Not set', inline: true },
            { name: 'Status', value: config.enabled ? 'On' : 'Paused', inline: true },
            { name: 'Auto delete', value: config.deleteAfter ? `${config.deleteAfter}s` : 'Off', inline: true },
            { name: 'Message', value: config.content ? `\`\`\`${config.content.slice(0, 500)}\`\`\`` : 'None' },
            { name: 'Embed', value: config.embedJson ? 'Set' : 'None', inline: true },
            ...(kind === 'welcome' ? [{
              name: 'Auto roles',
              value: config.autoRoleIds.length
                ? config.autoRoleIds.map((id) => `<@&${id}>`).join(' ')
                : 'None',
            }] : []),
          ],
        });
      },
    },
    {
      name: 'reset', module: 'Utility',
      description: `Delete the ${w.noun} setup`,
      execute: async (ctx) => {
        await db.delete(schema.greetConfigs).where(
          sqlAnd(ctx.guild.id, kind),
        );
        await GreetingEngine.invalidate(ctx.guild.id, kind);
        return ctx.ok(`${cap(w.noun)} setup deleted.`);
      },
    },
  ];

  // Only joining gets a DM and auto roles; there is nobody to DM on leave.
  if (kind !== 'goodbye') {
    children.push({
      name: 'dm', module: 'Utility',
      description: 'Send the message privately instead of in a channel',
      usage: `${name} dm <text|off>`,
      execute: async (ctx) => {
        const text = ctx.rest();
        if (!text || text.toLowerCase() === 'off') {
          await save(ctx, kind, { dmEnabled: false, dmContent: null });
          return ctx.ok('DMs turned off.');
        }
        await save(ctx, kind, { dmEnabled: true, dmContent: text.slice(0, 1900) });
        return ctx.ok('Saved. People with closed DMs are skipped quietly.');
      },
    });
  }

  if (kind === 'welcome') {
    children.push({
      name: 'autorole', aliases: ['roles'], module: 'Utility',
      description: 'Give new members a role automatically',
      usage: 'welcome autorole <@role>',
      botPermissions: [PermissionFlagsBits.ManageRoles],
      execute: async (ctx) => {
        const role = await ctx.resolveRole(0);
        if (role.managed) throw new UsageError(`${role} belongs to an integration.`);
        if (ctx.me.roles.highest.comparePositionTo(role) <= 0) {
          throw new UsageError(`${role} sits above Bounty's highest role.`,
            'Drag the Bounty role above it in Server Settings → Roles.');
        }

        const config = await load(ctx, kind);
        const current = config?.autoRoleIds ?? [];
        const has = current.includes(role.id);
        const next = has ? current.filter((id) => id !== role.id) : [...current, role.id];

        if (next.length > 8) throw new UsageError('Eight auto roles is the limit.');
        await save(ctx, kind, { autoRoleIds: next });
        return ctx.ok(has ? `${role} removed from auto roles.` : `New members will get ${role}.`);
      },
    });
  }

  return {
    name,
    aliases,
    module: 'Utility',
    description: `Configure what happens when ${w.trigger}`,
    userPermissions: [PermissionFlagsBits.ManageGuild],
    subcommands: Object.fromEntries(children.map((c) => [c.name, c])),
  };
}

// Kept local so the tree builder above stays readable.
import { and, eq } from 'drizzle-orm';
const sqlAnd = (guildId: string, kind: GreetKind) => and(
  eq(schema.greetConfigs.guildId, guildId),
  eq(schema.greetConfigs.kind, kind),
);

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

export const welcome = defineCommand(buildTree('welcome', 'welcome', ['welcomer', 'greet']));
export const goodbye = defineCommand(buildTree('goodbye', 'goodbye', ['leave', 'farewell']));
export const boostmsg = defineCommand(buildTree('boost', 'boostmsg', ['boostmessage', 'boostchannel']));
