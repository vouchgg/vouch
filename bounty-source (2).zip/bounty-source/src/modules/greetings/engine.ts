/**
 * Welcome, goodbye and boost cards.
 *
 * All three are the same machine: a template, a set of variables, a channel,
 * and an optional embed. Keeping them one engine means a fix to variable
 * rendering or the delete-after timer lands in all three at once.
 */

import {
  EmbedBuilder, Events, PermissionFlagsBits,
  type Guild, type GuildMember, type GuildTextBasedChannel, type MessageCreateOptions,
} from 'discord.js';
import { and, eq } from 'drizzle-orm';
import { db, schema } from '../../db/index.js';
import { forget, remember, TTL } from '../../core/cache.js';
import { logger } from '../../core/logger.js';
import type { BountyClient } from '../../core/client.js';
import type { GreetConfig } from '../../db/schema.js';

export type GreetKind = 'welcome' | 'goodbye' | 'boost';

/** Documented in `,welcome variables` — keep the two lists in step. */
export const VARIABLES: Array<[string, string]> = [
  ['{user}', 'mention, like @cav'],
  ['{user.name}', 'username, no mention'],
  ['{user.tag}', 'username with discriminator'],
  ['{user.id}', 'their ID'],
  ['{user.avatar}', 'avatar URL, for an embed thumbnail'],
  ['{user.created}', 'when the account was made'],
  ['{guild.name}', 'server name'],
  ['{guild.count}', 'member count, e.g. 1,204'],
  ['{guild.count.ordinal}', 'member count with a suffix, e.g. 1,204th'],
  ['{guild.icon}', 'server icon URL'],
  ['{guild.boosts}', 'boost count'],
  ['{guild.tier}', 'boost tier'],
  ['{inviter}', 'who invited them, when known'],
  ['{invite.code}', 'the invite code used'],
];

export interface GreetContext {
  member: GuildMember;
  inviterId?: string | null;
  code?: string | null;
}

export class GreetingEngine {
  constructor(private readonly client: BountyClient) {}

  attach(): void {
    this.client.on(Events.GuildMemberAdd, (member) => {
      void (async () => {
        // Invite tracking is already resolving this join; wait briefly so the
        // card can name who invited them.
        const attribution = await this.client.inviteTracking
          ?.awaitAttribution(member.guild.id, member.id)
          .catch(() => null);

        await this.fire('welcome', {
          member,
          inviterId: attribution?.inviterId ?? null,
          code: attribution?.code ?? null,
        });
      })().catch((err) => logger.warn({ err, guildId: member.guild.id }, 'welcome failed'));

      void this.applyAutoRoles(member).catch(() => undefined);
    });

    this.client.on(Events.GuildMemberRemove, (member) => {
      if (member.partial) return;
      void this.fire('goodbye', { member: member as GuildMember }).catch(() => undefined);
    });

    this.client.on(Events.GuildMemberUpdate, (before, after) => {
      if (before.premiumSince || !after.premiumSince) return;
      void this.fire('boost', { member: after }).catch(() => undefined);
    });
  }

  /** Called by the invite engine so `{inviter}` can be filled in. */
  async fire(kind: GreetKind, context: GreetContext): Promise<void> {
    const config = await this.config(context.member.guild.id, kind);
    if (!config?.enabled) return;

    const payload = render(config, context);

    if (config.channelId) {
      const channel = context.member.guild.channels.cache.get(config.channelId) as GuildTextBasedChannel | undefined;
      const canSend = channel?.permissionsFor(context.member.guild.members.me!)
        ?.has(PermissionFlagsBits.SendMessages | PermissionFlagsBits.EmbedLinks);

      if (channel && canSend) {
        const sent = await channel.send(payload).catch(() => null);
        // A card that hangs around forever turns the channel into a wall.
        if (sent && config.deleteAfter > 0) {
          setTimeout(() => void sent.delete().catch(() => undefined), config.deleteAfter * 1000)
            .unref();
        }
      }
    }

    if (config.dmEnabled && config.dmContent && kind !== 'goodbye') {
      await context.member.send({
        content: substitute(config.dmContent, context),
      }).catch(() => undefined); // Closed DMs are normal, not an error.
    }
  }

  private async applyAutoRoles(member: GuildMember): Promise<void> {
    const config = await this.config(member.guild.id, 'welcome');
    if (!config?.autoRoleIds.length) return;

    const me = member.guild.members.me!;
    const assignable = config.autoRoleIds
      .map((id) => member.guild.roles.cache.get(id))
      .filter((role): role is NonNullable<typeof role> =>
        Boolean(role) && !role!.managed && me.roles.highest.comparePositionTo(role!) > 0);

    if (!assignable.length) return;
    await member.roles.add(assignable, 'Autorole on join').catch((err) =>
      logger.warn({ err, guildId: member.guild.id }, 'autorole failed'));
  }

  async config(guildId: string, kind: GreetKind): Promise<GreetConfig | null> {
    return remember(`bounty:greet:${guildId}:${kind}`, TTL.guildConfig, async () => {
      const [row] = await db.select().from(schema.greetConfigs).where(and(
        eq(schema.greetConfigs.guildId, guildId),
        eq(schema.greetConfigs.kind, kind),
      )).limit(1);
      return row ?? null;
    });
  }

  static invalidate(guildId: string, kind: GreetKind) {
    return forget(`bounty:greet:${guildId}:${kind}`);
  }
}

/* ---------------------------------------------------------- rendering */

export function render(config: GreetConfig, context: GreetContext): MessageCreateOptions {
  const payload: MessageCreateOptions = {};

  if (config.content) {
    payload.content = substitute(config.content, context);
    // Mentions in a greeting are the point, but only for the person joining.
    payload.allowedMentions = { users: [context.member.id], roles: [] };
  }

  if (config.embedJson) {
    const filled = substituteDeep(config.embedJson, context);
    try {
      payload.embeds = [EmbedBuilder.from(filled as never)];
    } catch {
      // A malformed embed should not swallow the greeting entirely.
      payload.content = payload.content ?? substitute(config.content ?? '', context);
    }
  }

  if (!payload.content && !payload.embeds?.length) {
    payload.content = `Welcome ${context.member}.`;
  }
  return payload;
}

export function substitute(template: string, { member, inviterId, code }: GreetContext): string {
  const guild = member.guild;
  const count = guild.memberCount;

  return template
    .replaceAll('{user.mention}', member.toString())
    .replaceAll('{user.name}', member.user.username)
    .replaceAll('{user.tag}', member.user.tag)
    .replaceAll('{user.id}', member.id)
    .replaceAll('{user.avatar}', member.displayAvatarURL({ size: 512 }))
    .replaceAll('{user.created}', `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`)
    .replaceAll('{user}', member.toString())
    .replaceAll('{guild.name}', guild.name)
    .replaceAll('{guild.count.ordinal}', ordinal(count))
    .replaceAll('{guild.count}', count.toLocaleString('en-GB'))
    .replaceAll('{guild.icon}', guild.iconURL({ size: 512 }) ?? '')
    .replaceAll('{guild.boosts}', String(guild.premiumSubscriptionCount ?? 0))
    .replaceAll('{guild.tier}', String(guild.premiumTier))
    .replaceAll('{inviter}', inviterId ? `<@${inviterId}>` : 'someone')
    .replaceAll('{invite.code}', code ?? 'unknown');
}

/** Walks an embed JSON tree replacing variables in every string leaf. */
function substituteDeep(value: unknown, context: GreetContext): unknown {
  if (typeof value === 'string') return substitute(value, context);
  if (Array.isArray(value)) return value.map((v) => substituteDeep(v, context));
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>)
        .map(([k, v]) => [k, substituteDeep(v, context)]),
    );
  }
  return value;
}

function ordinal(n: number): string {
  const s = n.toLocaleString('en-GB');
  const last2 = n % 100;
  if (last2 >= 11 && last2 <= 13) return `${s}th`;
  return `${s}${['th', 'st', 'nd', 'rd'][n % 10] ?? 'th'}`;
}

/** Used by `,welcome test` so the preview matches the real thing exactly. */
export function previewContext(member: GuildMember): GreetContext {
  return { member, inviterId: member.id, code: 'preview' };
}

export const guildOf = (member: GuildMember): Guild => member.guild;
