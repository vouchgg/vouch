/**
 * Lookups.
 *
 * All of these are read-only and get hammered, so every one of them goes
 * through the Redis read-through in `cache.ts`. History commands read the
 * archive tables rather than Discord, because Discord does not keep it.
 */

import { ActivityType, PermissionFlagsBits, UserFlags } from 'discord.js';
import { and, desc, eq } from 'drizzle-orm';
import { defineCommand } from '../../../core/command.js';
import { NotFoundError, UsageError } from '../../../core/errors.js';
import { db, schema } from '../../../db/index.js';
import { key, remember, TTL } from '../../../core/cache.js';
import { progressBar, ts } from '../../../core/branding.js';

const BADGES: Array<[number, string]> = [
  [UserFlags.Staff, 'Discord Staff'],
  [UserFlags.Partner, 'Partner'],
  [UserFlags.Hypesquad, 'HypeSquad Events'],
  [UserFlags.HypeSquadOnlineHouse1, 'House Bravery'],
  [UserFlags.HypeSquadOnlineHouse2, 'House Brilliance'],
  [UserFlags.HypeSquadOnlineHouse3, 'House Balance'],
  [UserFlags.BugHunterLevel1, 'Bug Hunter'],
  [UserFlags.BugHunterLevel2, 'Bug Hunter Gold'],
  [UserFlags.PremiumEarlySupporter, 'Early Supporter'],
  [UserFlags.VerifiedDeveloper, 'Early Verified Bot Developer'],
  [UserFlags.CertifiedModerator, 'Moderator Programmes Alumni'],
  [UserFlags.ActiveDeveloper, 'Active Developer'],
];

export const avatar = defineCommand({
  name: 'avatar',
  aliases: ['av', 'pfp'],
  module: 'Lookups',
  description: 'Show a full resolution avatar',
  usage: 'avatar [user]',
  cooldown: { uses: 5, windowMs: 10_000 },
  execute: async (ctx) => {
    const user = await ctx.resolveUser(0);
    const url = user.displayAvatarURL({ size: 4096, extension: user.avatar?.startsWith('a_') ? 'gif' : 'png' });
    return ctx.send({
      title: `${user.username}'s avatar`,
      url,
      image: url,
      description: `[png](${user.displayAvatarURL({ size: 4096, extension: 'png' })}) · ` +
        `[webp](${user.displayAvatarURL({ size: 4096, extension: 'webp' })})` +
        (user.avatar?.startsWith('a_') ? ` · [gif](${user.displayAvatarURL({ size: 4096, extension: 'gif' })})` : ''),
    });
  },
  subcommands: {
    server: {
      name: 'server', aliases: ['guild'], module: 'Lookups',
      description: 'Show their server specific avatar',
      execute: async (ctx) => {
        const member = await ctx.resolveMember(0, { fallbackToAuthor: true });
        if (!member!.avatar) throw new NotFoundError(`${member!.user.username} has no server avatar here.`);
        const url = member!.displayAvatarURL({ size: 4096 });
        return ctx.send({ title: `${member!.user.username}'s server avatar`, image: url, url });
      },
    },
  },
});

export const avatarhistory = defineCommand({
  name: 'avatarhistory',
  aliases: ['avh', 'pfph'],
  module: 'Lookups',
  description: 'Every avatar Bounty has seen someone wear',
  usage: 'avatarhistory [user]',
  cooldown: { uses: 3, windowMs: 15_000 },
  execute: async (ctx) => {
    const user = await ctx.resolveUser(0);

    const rows = await remember(key.avatarHistory(user.id), TTL.assetHistory, async () =>
      db.select().from(schema.assetHistory).where(and(
        eq(schema.assetHistory.userId, user.id),
        eq(schema.assetHistory.type, 'avatar'),
      )).orderBy(desc(schema.assetHistory.firstSeenAt)).limit(50));

    if (!rows.length) {
      return ctx.warn(
        `No avatar history for ${user.username} yet.`,
        { footer: 'History starts building the first time Bounty sees them change it' },
      );
    }

    return ctx.send({
      title: `${user.username}'s avatars`,
      description: `${rows.length} recorded, newest first.`,
      image: rows[0].storedUrl,
      fields: rows.slice(0, 10).map((row, i) => ({
        name: `${i + 1}. ${ts(row.firstSeenAt, 'D')}`,
        value: `[open](${row.storedUrl})${row.animated ? ' · animated' : ''}`,
        inline: true,
      })),
    });
  },
});

export const banner = defineCommand({
  name: 'banner',
  aliases: ['bn'],
  module: 'Lookups',
  description: 'Show a profile banner',
  usage: 'banner [user]',
  execute: async (ctx) => {
    const user = await (await ctx.resolveUser(0)).fetch(true);
    const url = user.bannerURL({ size: 4096 });
    if (!url) throw new NotFoundError(`${user.username} has no banner set.`);
    return ctx.send({ title: `${user.username}'s banner`, image: url, url });
  },
});

export const bannerhistory = defineCommand({
  name: 'bannerhistory',
  aliases: ['bnh'],
  module: 'Lookups',
  description: 'Every banner Bounty has recorded',
  usage: 'bannerhistory [user]',
  execute: async (ctx) => {
    const user = await ctx.resolveUser(0);
    const rows = await remember(key.bannerHistory(user.id), TTL.assetHistory, async () =>
      db.select().from(schema.assetHistory).where(and(
        eq(schema.assetHistory.userId, user.id),
        eq(schema.assetHistory.type, 'banner'),
      )).orderBy(desc(schema.assetHistory.firstSeenAt)).limit(25));

    if (!rows.length) return ctx.warn(`No banner history for ${user.username} yet.`);

    return ctx.send({
      title: `${user.username}'s banners`,
      description: `${rows.length} recorded.`,
      image: rows[0].storedUrl,
      fields: rows.slice(0, 8).map((row, i) => ({
        name: `${i + 1}. ${ts(row.firstSeenAt, 'D')}`,
        value: `[open](${row.storedUrl})`,
        inline: true,
      })),
    });
  },
});

export const pastnames = defineCommand({
  name: 'pastnames',
  aliases: ['names', 'usernames', 'nicks'],
  module: 'Lookups',
  description: 'Username, display name and nickname changes',
  usage: 'pastnames [user]',
  execute: async (ctx) => {
    const user = await ctx.resolveUser(0);
    const rows = await remember(key.names(user.id), TTL.assetHistory, async () =>
      db.select().from(schema.nameHistory)
        .where(eq(schema.nameHistory.userId, user.id))
        .orderBy(desc(schema.nameHistory.changedAt))
        .limit(25));

    if (!rows.length) return ctx.warn(`No name changes recorded for ${user.username}.`);

    return ctx.send({
      title: `${user.username}'s past names`,
      description: rows.map((row) =>
        `\`${row.type.replace('_', ' ')}\` ${row.previousValue ?? '*none*'} → ` +
        `**${row.newValue ?? '*none*'}** · ${ts(row.changedAt)}`).join('\n'),
      footer: `${rows.length} change${rows.length === 1 ? '' : 's'} recorded`,
    });
  },
  subcommands: {
    clear: {
      name: 'clear', aliases: ['wipe'], module: 'Lookups',
      description: 'Delete your own recorded name history',
      execute: async (ctx) => {
        const deleted = await db.delete(schema.nameHistory)
          .where(eq(schema.nameHistory.userId, ctx.author.id)).returning();
        return ctx.ok(`Deleted ${deleted.length} recorded name change${deleted.length === 1 ? '' : 's'}.`);
      },
    },
  },
});

export const userinfo = defineCommand({
  name: 'userinfo',
  aliases: ['ui', 'whois', 'user'],
  module: 'Lookups',
  description: 'Full profile report on someone',
  usage: 'userinfo [user]',
  cooldown: { uses: 4, windowMs: 10_000 },
  execute: async (ctx) => {
    const user = await (await ctx.resolveUser(0)).fetch(true);
    const member = await ctx.guild.members.fetch(user.id).catch(() => null);

    const roles = member?.roles.cache
      .filter((r) => r.id !== ctx.guild.id)
      .sort((a, b) => b.position - a.position);

    const keyPerms = member?.permissions.toArray()
      .filter((p) => ['Administrator', 'ManageGuild', 'ManageRoles', 'ManageChannels',
        'BanMembers', 'KickMembers', 'ManageMessages', 'MentionEveryone'].includes(p));

    return ctx.send({
      title: user.tag,
      url: `https://discord.com/users/${user.id}`,
      thumbnail: user.displayAvatarURL({ size: 256 }),
      image: user.bannerURL({ size: 1024 }) ?? undefined,
      color: user.accentColor ?? undefined,
      fields: [
        { name: 'ID', value: `\`${user.id}\``, inline: true },
        { name: 'Account made', value: ts(user.createdAt, 'D'), inline: true },
        ...(member?.joinedAt ? [{ name: 'Joined here', value: ts(member.joinedAt, 'D'), inline: true }] : []),
        ...(member?.premiumSince ? [{ name: 'Boosting since', value: ts(member.premiumSince, 'D'), inline: true }] : []),
        ...(roles?.size ? [{
          name: `Roles · ${roles.size}`,
          value: roles.first(12)!.map((r) => `<@&${r.id}>`).join(' ') + (roles.size > 12 ? ` +${roles.size - 12}` : ''),
        }] : []),
        ...(keyPerms?.length ? [{ name: 'Key permissions', value: keyPerms.join(', ') }] : []),
        ...(user.flags?.toArray().length
          ? [{ name: 'Badges', value: badgeList(Number(user.flags.bitfield)) || 'None' }] : []),
      ],
      footer: member ? undefined : 'Not a member of this server',
    });
  },
});

export const badges = defineCommand({
  name: 'badges',
  aliases: ['flags'],
  module: 'Lookups',
  description: 'Discord badges and nitro status',
  usage: 'badges [user]',
  execute: async (ctx) => {
    const user = await (await ctx.resolveUser(0)).fetch(true);
    const list = badgeList(Number(user.flags?.bitfield ?? 0));
    const member = await ctx.guild.members.fetch(user.id).catch(() => null);

    return ctx.send({
      title: `${user.username}'s badges`,
      thumbnail: user.displayAvatarURL({ size: 128 }),
      description: list || 'No public badges.',
      fields: [
        { name: 'Nitro', value: user.banner || user.avatar?.startsWith('a_') ? 'Likely' : 'Not detectable', inline: true },
        ...(member?.premiumSince ? [{ name: 'Boosting', value: `since ${ts(member.premiumSince, 'D')}`, inline: true }] : []),
      ],
      footer: 'Nitro is inferred from animated avatars and banners; Discord does not expose it',
    });
  },
});

export const spotify = defineCommand({
  name: 'spotify',
  aliases: ['sp'],
  module: 'Lookups',
  description: 'What someone is listening to right now',
  usage: 'spotify [user]',
  cooldown: { uses: 4, windowMs: 8000 },
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0, { fallbackToAuthor: true });
    const activity = member!.presence?.activities
      .find((a) => a.type === ActivityType.Listening && a.name === 'Spotify');

    if (!activity) {
      throw new NotFoundError(
        `${member!.user.username} is not listening to Spotify.`,
        'They need Spotify connected and the status shown on their profile.',
      );
    }

    const start = activity.timestamps?.start?.getTime() ?? Date.now();
    const end = activity.timestamps?.end?.getTime() ?? Date.now();
    const elapsed = Date.now() - start;
    const total = end - start;

    return ctx.send({
      color: 0x1db954,
      author: null,
      title: activity.details ?? 'Unknown track',
      url: activity.syncId ? `https://open.spotify.com/track/${activity.syncId}` : undefined,
      thumbnail: activity.assets?.largeImageURL() ?? undefined,
      description:
        `by **${activity.state?.split('; ').join(', ') ?? 'Unknown'}**\n` +
        `on *${activity.assets?.largeText ?? 'Unknown album'}*\n\n` +
        `\`${clock(elapsed)}\` ${progressBar(total ? elapsed / total : 0)} \`${clock(total)}\``,
      footer: `${member!.user.username} · Spotify`,
    });
  },
});

export const roleinfo = defineCommand({
  name: 'roleinfo',
  aliases: ['ri'],
  module: 'Lookups',
  description: 'Everything about a role',
  usage: 'roleinfo <role>',
  execute: async (ctx) => {
    const role = await ctx.resolveRole(0);
    return ctx.send({
      title: role.name,
      color: role.color || undefined,
      thumbnail: role.iconURL({ size: 128 }) ?? undefined,
      fields: [
        { name: 'ID', value: `\`${role.id}\``, inline: true },
        { name: 'Colour', value: role.hexColor, inline: true },
        { name: 'Members', value: String(role.members.size), inline: true },
        { name: 'Position', value: `${role.position} of ${ctx.guild.roles.cache.size - 1}`, inline: true },
        { name: 'Created', value: ts(role.createdAt, 'D'), inline: true },
        { name: 'Mentionable', value: role.mentionable ? 'Yes' : 'No', inline: true },
        { name: 'Managed by integration', value: role.managed ? 'Yes' : 'No', inline: true },
        {
          name: 'Notable permissions',
          value: role.permissions.toArray()
            .filter((p) => p.startsWith('Manage') || p === 'Administrator' || p.endsWith('Members'))
            .join(', ') || 'None',
        },
      ],
    });
  },
});

export const channelinfo = defineCommand({
  name: 'channelinfo',
  aliases: ['ci'],
  module: 'Lookups',
  description: 'Details about a channel',
  usage: 'channelinfo [#channel]',
  execute: async (ctx) => {
    const id = ctx.args[0]?.match(/\d{17,20}/)?.[0] ?? ctx.channel.id;
    const channel = ctx.guild.channels.cache.get(id);
    if (!channel) throw new NotFoundError('No channel with that ID here.');

    return ctx.send({
      title: `#${channel.name}`,
      fields: [
        { name: 'ID', value: `\`${channel.id}\``, inline: true },
        { name: 'Type', value: String(channel.type), inline: true },
        { name: 'Created', value: ts(channel.createdAt!, 'D'), inline: true },
        { name: 'Category', value: channel.parent?.name ?? 'None', inline: true },
        { name: 'Position', value: 'rawPosition' in channel ? String(channel.rawPosition) : 'n/a', inline: true },
        ...('topic' in channel && channel.topic ? [{ name: 'Topic', value: channel.topic.slice(0, 500) }] : []),
      ],
    });
  },
});

export const serveravatar = defineCommand({
  name: 'servericon',
  aliases: ['icon', 'guildicon'],
  module: 'Lookups',
  description: 'Show the server icon',
  execute: async (ctx) => {
    const url = ctx.guild.iconURL({ size: 4096 });
    if (!url) throw new NotFoundError('This server has no icon.');
    return ctx.send({ title: `${ctx.guild.name}'s icon`, image: url, url });
  },
  subcommands: {
    banner: {
      name: 'banner', module: 'Lookups',
      description: 'Show the server banner',
      execute: async (ctx) => {
        const url = ctx.guild.bannerURL({ size: 4096 });
        if (!url) throw new NotFoundError('This server has no banner.');
        return ctx.send({ title: `${ctx.guild.name}'s banner`, image: url, url });
      },
    },
    splash: {
      name: 'splash', module: 'Lookups',
      description: 'Show the invite splash image',
      execute: async (ctx) => {
        const url = ctx.guild.splashURL({ size: 4096 });
        if (!url) throw new NotFoundError('This server has no invite splash.');
        return ctx.send({ title: `${ctx.guild.name}'s splash`, image: url, url });
      },
    },
  },
});

export const emojiinfo = defineCommand({
  name: 'emoji',
  aliases: ['emote', 'e'],
  module: 'Lookups',
  description: 'Enlarge a custom emoji and show its details',
  usage: 'emoji <emoji>',
  execute: async (ctx) => {
    const match = ctx.args[0]?.match(/<(a)?:(\w+):(\d+)>/);
    if (!match) throw new UsageError('Give a custom emoji.');
    const [, animated, name, id] = match;
    const url = `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'png'}?size=1024`;

    return ctx.send({
      title: `:${name}:`,
      image: url,
      fields: [
        { name: 'ID', value: `\`${id}\``, inline: true },
        { name: 'Animated', value: animated ? 'Yes' : 'No', inline: true },
        { name: 'Link', value: `[open](${url})`, inline: true },
      ],
    });
  },
  subcommands: {
    steal: {
      name: 'steal', aliases: ['add', 'yoink'], module: 'Lookups',
      description: 'Add an emoji from another server to this one',
      usage: 'emoji steal <emoji> [name]',
      userPermissions: [PermissionFlagsBits.ManageGuildExpressions],
      botPermissions: [PermissionFlagsBits.ManageGuildExpressions],
      execute: async (ctx) => {
        const match = ctx.args[0]?.match(/<(a)?:(\w+):(\d+)>/);
        if (!match) throw new UsageError('Give a custom emoji to copy.');
        const [, animated, name, id] = match;
        const url = `https://cdn.discordapp.com/emojis/${id}.${animated ? 'gif' : 'png'}`;

        const created = await ctx.guild.emojis.create({
          attachment: url,
          name: ctx.args[1]?.replace(/\W/g, '') || name,
          reason: `Added by ${ctx.author.tag}`,
        });
        return ctx.ok(`Added ${created}.`);
      },
    },
  },
});

/* ------------------------------------------------------------ helpers */

function badgeList(flags: number): string {
  return BADGES.filter(([flag]) => (flags & flag) === flag).map(([, label]) => label).join('\n');
}

function clock(ms: number): string {
  const total = Math.max(Math.floor(ms / 1000), 0);
  const minutes = Math.floor(total / 60);
  return `${minutes}:${String(total % 60).padStart(2, '0')}`;
}
