/**
 * `,invites …` and `,inviterewards …`
 */

import { PermissionFlagsBits } from 'discord.js';
import { and, desc, eq, sql } from 'drizzle-orm';
import { defineCommand } from '../../../core/command.js';
import { UsageError } from '../../../core/errors.js';
import { db, schema } from '../../../db/index.js';
import { ts } from '../../../core/branding.js';

const MEDALS = ['🥇', '🥈', '🥉'];

export const invites = defineCommand({
  name: 'invites',
  aliases: ['inv', 'invitestats'],
  module: 'Utility',
  description: 'See how many people someone has invited',
  cooldown: { uses: 3, windowMs: 8000 },
  execute: async (ctx) => {
    const user = await ctx.resolveUser(0);
    const stats = await ctx.client.inviteTracking.statsFor(ctx.guild.id, user.id);
    const total = stats.valid + stats.bonus;

    const rank = await db
      .select({ inviterId: schema.inviteAttribution.inviterId })
      .from(schema.inviteAttribution)
      .where(and(
        eq(schema.inviteAttribution.guildId, ctx.guild.id),
        sql`${schema.inviteAttribution.inviterId} is not null`,
      ))
      .groupBy(schema.inviteAttribution.inviterId)
      .having(sql`count(*) filter (where ${schema.inviteAttribution.valid} and not ${schema.inviteAttribution.fake}) > ${stats.valid}`);

    return ctx.send({
      author: null,
      title: `${user.username}'s invites`,
      thumbnail: user.displayAvatarURL({ size: 128 }),
      description: total === 0
        ? 'No invites yet. Any invite link they make gets counted from now on.'
        : `**${total}** invite${total === 1 ? '' : 's'}, ranked **#${rank.length + 1}** in the server.`,
      fields: [
        { name: 'Still here', value: String(stats.valid), inline: true },
        { name: 'Left', value: String(stats.left), inline: true },
        { name: 'Fake', value: String(stats.fake), inline: true },
        ...(stats.bonus ? [{ name: 'Bonus', value: `${stats.bonus > 0 ? '+' : ''}${stats.bonus}`, inline: true }] : []),
      ],
      footer: 'Fake invites are accounts that were too new when they joined',
    });
  },
  subcommands: {
    leaderboard: {
      name: 'leaderboard', aliases: ['lb', 'top', 'list'], module: 'Utility',
      description: 'Rank everyone by invites',
      usage: 'invites leaderboard [page]',
      cooldown: { uses: 2, windowMs: 10_000 },
      execute: async (ctx) => {
        const page = Math.max(Number.parseInt(ctx.args[0] ?? '1', 10) || 1, 1);
        const rows = await ctx.client.inviteTracking.leaderboard(ctx.guild.id, 10, (page - 1) * 10);

        if (!rows.length) {
          return ctx.warn(page === 1
            ? 'Nobody has invited anyone yet.'
            : 'That page is empty.');
        }

        const lines = rows.map((row, i) => {
          const position = (page - 1) * 10 + i + 1;
          const badge = page === 1 && position <= 3 ? MEDALS[position - 1] : `\`${position}.\``;
          const extras = [
            row.left ? `${row.left} left` : null,
            row.fake ? `${row.fake} fake` : null,
          ].filter(Boolean).join(', ');
          return `${badge} <@${row.inviterId}> — **${row.valid}**${extras ? ` *(${extras})*` : ''}`;
        });

        return ctx.send({
          title: 'Invite leaderboard',
          description: lines.join('\n'),
          footer: `Page ${page} · ${ctx.guild.name}`,
        });
      },
    },

    codes: {
      name: 'codes', aliases: ['links'], module: 'Utility',
      description: 'List the invite links someone owns',
      execute: async (ctx) => {
        const user = await ctx.resolveUser(0);
        const rows = await db.select().from(schema.inviteCodes).where(and(
          eq(schema.inviteCodes.guildId, ctx.guild.id),
          eq(schema.inviteCodes.inviterId, user.id),
        )).orderBy(desc(schema.inviteCodes.uses)).limit(15);

        if (!rows.length) return ctx.warn(`${user.username} has no invite links here.`);

        return ctx.send({
          title: `${user.username}'s invite links`,
          description: rows.map((r) =>
            `\`${r.code}\` — ${r.uses} use${r.uses === 1 ? '' : 's'}` +
            `${r.channelId ? ` → <#${r.channelId}>` : ''}` +
            `${r.expiresAt ? ` · expires ${ts(r.expiresAt)}` : ''}`).join('\n'),
        });
      },
    },

    who: {
      name: 'who', aliases: ['invitedby', 'source'], module: 'Utility',
      description: 'Show who invited a member',
      usage: 'invites who <user>',
      execute: async (ctx) => {
        const user = await ctx.resolveUser(0, { fallbackToAuthor: true });
        const [row] = await db.select().from(schema.inviteAttribution).where(and(
          eq(schema.inviteAttribution.guildId, ctx.guild.id),
          eq(schema.inviteAttribution.userId, user.id),
        )).limit(1);

        if (!row) return ctx.warn(`No record of how ${user.username} joined. Tracking only covers joins since Bounty was added.`);

        return ctx.send({
          title: `How ${user.username} joined`,
          fields: [
            { name: 'Invited by', value: row.inviterId ? `<@${row.inviterId}>` : 'Unknown or a vanity link', inline: true },
            { name: 'Code', value: row.code ? `\`${row.code}\`` : 'Unknown', inline: true },
            { name: 'Joined', value: ts(row.joinedAt), inline: true },
            ...(row.rejoins ? [{ name: 'Rejoins', value: String(row.rejoins), inline: true }] : []),
            ...(row.fake ? [{ name: 'Flagged', value: 'Account was very new when it joined' }] : []),
          ],
        });
      },
    },

    add: {
      name: 'add', aliases: ['give'], module: 'Utility',
      description: 'Add bonus invites to someone',
      usage: 'invites add <user> <amount>',
      userPermissions: [PermissionFlagsBits.ManageGuild],
      execute: async (ctx) => adjust(ctx, 1),
    },

    remove: {
      name: 'remove', aliases: ['take'], module: 'Utility',
      description: 'Take bonus invites away',
      usage: 'invites remove <user> <amount>',
      userPermissions: [PermissionFlagsBits.ManageGuild],
      execute: async (ctx) => adjust(ctx, -1),
    },

    reset: {
      name: 'reset', aliases: ['clear'], module: 'Utility',
      description: 'Wipe invite counts for one person or everyone',
      usage: 'invites reset [user]',
      userPermissions: [PermissionFlagsBits.ManageGuild],
      execute: async (ctx) => {
        if (ctx.args[0]) {
          const user = await ctx.resolveUser(0, { fallbackToAuthor: false });
          await db.delete(schema.inviteAttribution).where(and(
            eq(schema.inviteAttribution.guildId, ctx.guild.id),
            eq(schema.inviteAttribution.inviterId, user.id),
          ));
          await db.delete(schema.inviteAdjustments).where(and(
            eq(schema.inviteAdjustments.guildId, ctx.guild.id),
            eq(schema.inviteAdjustments.userId, user.id),
          ));
          return ctx.ok(`${user.username}'s invites are back to zero.`);
        }

        await db.delete(schema.inviteAttribution)
          .where(eq(schema.inviteAttribution.guildId, ctx.guild.id));
        await db.delete(schema.inviteAdjustments)
          .where(eq(schema.inviteAdjustments.guildId, ctx.guild.id));
        return ctx.ok('Every invite count in the server was reset.');
      },
    },
  },
});

export const inviterewards = defineCommand({
  name: 'inviterewards',
  aliases: ['invrewards', 'invrole'],
  module: 'Utility',
  description: 'Give roles out at invite milestones',
  userPermissions: [PermissionFlagsBits.ManageGuild],
  botPermissions: [PermissionFlagsBits.ManageRoles],
  subcommands: {
    add: {
      name: 'add', module: 'Utility',
      description: 'Award a role at a number of invites',
      usage: 'inviterewards add <amount> <@role>',
      execute: async (ctx) => {
        const threshold = Number.parseInt(ctx.args[0] ?? '', 10);
        if (Number.isNaN(threshold) || threshold < 1) throw new UsageError('Give the invite count first, then the role.');

        ctx.args.shift();
        const role = await ctx.resolveRole(0);
        if (role.managed) throw new UsageError(`${role} belongs to an integration.`);
        if (ctx.me.roles.highest.comparePositionTo(role) <= 0) {
          throw new UsageError(`${role} sits above Bounty's highest role.`);
        }

        await db.insert(schema.inviteRewards).values({
          guildId: ctx.guild.id, threshold, roleId: role.id,
        });
        return ctx.ok(`${role} is awarded at ${threshold} invites.`);
      },
    },
    remove: {
      name: 'remove', module: 'Utility',
      description: 'Stop awarding a role',
      usage: 'inviterewards remove <@role>',
      execute: async (ctx) => {
        const role = await ctx.resolveRole(0);
        const deleted = await db.delete(schema.inviteRewards).where(and(
          eq(schema.inviteRewards.guildId, ctx.guild.id),
          eq(schema.inviteRewards.roleId, role.id),
        )).returning();
        if (!deleted.length) throw new UsageError(`${role} was not an invite reward.`);
        return ctx.ok(`${role} is no longer awarded.`);
      },
    },
    list: {
      name: 'list', aliases: ['show'], module: 'Utility',
      description: 'Show every invite reward',
      execute: async (ctx) => {
        const rows = await db.select().from(schema.inviteRewards)
          .where(eq(schema.inviteRewards.guildId, ctx.guild.id))
          .orderBy(schema.inviteRewards.threshold);
        if (!rows.length) return ctx.warn('No invite rewards set up.');
        return ctx.send({
          title: 'Invite rewards',
          description: rows.map((r) => `**${r.threshold}** invites → <@&${r.roleId}>`).join('\n'),
        });
      },
    },
  },
});

async function adjust(ctx: import('../../../core/command.js').Context, sign: 1 | -1) {
  const user = await ctx.resolveUser(0, { fallbackToAuthor: false });
  const amount = Number.parseInt(ctx.args[1] ?? '', 10);
  if (Number.isNaN(amount) || amount < 1) throw new UsageError('Give a positive number of invites.');

  const delta = amount * sign;
  await db.insert(schema.inviteAdjustments)
    .values({ guildId: ctx.guild.id, userId: user.id, bonus: delta })
    .onConflictDoUpdate({
      target: [schema.inviteAdjustments.guildId, schema.inviteAdjustments.userId],
      set: { bonus: sql`${schema.inviteAdjustments.bonus} + ${delta}` },
    });

  const total = await ctx.client.inviteTracking.countFor(ctx.guild.id, user.id);
  return ctx.ok(`${sign > 0 ? 'Added' : 'Removed'} ${amount} invite${amount === 1 ? '' : 's'}. ${user.username} is on ${total}.`);
}
