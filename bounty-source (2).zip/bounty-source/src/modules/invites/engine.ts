/**
 * Invite tracking.
 *
 * Discord never says which invite someone used. The only way to know is to
 * hold a snapshot of every invite's use count, and when a member joins, find
 * the one that went up by one. That makes this engine a cache-correctness
 * problem more than anything else:
 *
 *  - The snapshot must be refreshed on boot, on every invite create/delete,
 *    and after every join, or the next join attributes to the wrong person.
 *  - Two people joining in the same second race the snapshot, so the diff and
 *    the refresh happen under a per-guild lock.
 *  - Vanity URLs have their own counter, and single-use invites vanish on use,
 *    so both are handled as their own case rather than falling through.
 */

import { Events, PermissionFlagsBits, type Collection, type Guild, type GuildMember, type Invite } from 'discord.js';
import { and, desc, eq, sql } from 'drizzle-orm';
import { db, schema } from '../../db/index.js';
import { withLock } from '../../core/cache.js';
import { logger } from '../../core/logger.js';
import type { BountyClient } from '../../core/client.js';

interface Snapshot { uses: number; inviterId: string | null; channelId: string | null }

export interface Attribution {
  inviterId: string | null;
  code: string | null;
  /** Why we could not attribute, when we could not. */
  reason?: 'vanity' | 'unknown' | 'no_permission';
}

export class InviteEngine {
  /** guildId → code → snapshot. Memory only; rebuilt on boot. */
  private readonly snapshots = new Map<string, Map<string, Snapshot>>();
  /**
   * In-flight attributions, so the greeting engine can wait for `{inviter}`
   * instead of racing it. Set synchronously when the join event arrives.
   */
  private readonly pending = new Map<string, Promise<Attribution>>();

  constructor(private readonly client: BountyClient) {}

  attach(): void {
    this.client.once('ready', () => void this.primeAll());

    this.client.on(Events.GuildCreate, (guild) => void this.prime(guild).catch(() => undefined));

    this.client.on(Events.InviteCreate, (invite) => {
      const guildId = invite.guild && 'id' in invite.guild ? invite.guild.id : null;
      if (!guildId) return;
      this.map(guildId).set(invite.code, {
        uses: invite.uses ?? 0,
        inviterId: invite.inviterId ?? null,
        channelId: invite.channelId ?? null,
      });
      void this.persist(guildId, invite);
    });

    this.client.on(Events.InviteDelete, (invite) => {
      const guildId = invite.guild && 'id' in invite.guild ? invite.guild.id : null;
      if (guildId) this.map(guildId).delete(invite.code);
    });

    this.client.on(Events.GuildMemberAdd, (member) => {
      // Registered before the greeting engine's listener, and the map is
      // populated synchronously here, so the greeting always finds it.
      const slot = `${member.guild.id}:${member.id}`;
      const work = this.onJoin(member).catch((err) => {
        logger.warn({ err, guildId: member.guild.id }, 'invite attribution failed');
        return { inviterId: null, code: null, reason: 'unknown' as const };
      });
      this.pending.set(slot, work);
      void work.finally(() => {
        setTimeout(() => this.pending.delete(slot), 30_000).unref();
      });
    });

    this.client.on(Events.GuildMemberRemove, (member) => {
      if (!member.guild) return;
      void this.onLeave(member.guild.id, member.id).catch(() => undefined);
    });
  }

  /* -------------------------------------------------------- snapshots */

  private map(guildId: string): Map<string, Snapshot> {
    let existing = this.snapshots.get(guildId);
    if (!existing) { existing = new Map(); this.snapshots.set(guildId, existing); }
    return existing;
  }

  private async primeAll(): Promise<void> {
    const guilds = [...this.client.guilds.cache.values()];
    // Sequential on purpose: priming 500 guilds in parallel is a self-inflicted 429.
    for (const guild of guilds) await this.prime(guild).catch(() => undefined);
    logger.info({ guilds: guilds.length }, 'invite snapshots primed');
  }

  private async prime(guild: Guild): Promise<void> {
    if (!guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuild)) return;

    const invites = await guild.invites.fetch().catch(() => null);
    if (!invites) return;

    const map = this.map(guild.id);
    map.clear();
    for (const invite of invites.values()) {
      map.set(invite.code, {
        uses: invite.uses ?? 0,
        inviterId: invite.inviterId ?? null,
        channelId: invite.channelId ?? null,
      });
    }

    if (guild.vanityURLCode) {
      const vanity = await guild.fetchVanityData().catch(() => null);
      if (vanity) {
        map.set(guild.vanityURLCode, { uses: vanity.uses, inviterId: null, channelId: null });
      }
    }

    await this.persistAll(guild.id, invites);
  }

  /* --------------------------------------------------------- the join */

  /**
   * Waits for this join's attribution, giving up quickly — a welcome card that
   * arrives thirty seconds late is worse than one that says "someone".
   */
  async awaitAttribution(guildId: string, userId: string, timeoutMs = 4000): Promise<Attribution | null> {
    const inFlight = this.pending.get(`${guildId}:${userId}`);
    if (!inFlight) return null;
    return Promise.race([
      inFlight,
      new Promise<null>((resolve) => setTimeout(() => resolve(null), timeoutMs).unref()),
    ]);
  }

  private async onJoin(member: GuildMember): Promise<Attribution> {
    const attribution = await withLock(`invites:${member.guild.id}`, 10_000, () =>
      this.attribute(member.guild)) ?? { inviterId: null, code: null, reason: 'unknown' as const };

    const config = await db.select().from(schema.guildModeration)
      .where(eq(schema.guildModeration.guildId, member.guild.id)).limit(1);
    const minAgeDays = config[0]?.minAccountAgeDays ?? 7;
    const fake = Date.now() - member.user.createdTimestamp < minAgeDays * 86_400_000;

    await db.insert(schema.inviteAttribution)
      .values({
        guildId: member.guild.id,
        userId: member.id,
        inviterId: attribution.inviterId,
        code: attribution.code,
        fake,
        valid: true,
      })
      .onConflictDoUpdate({
        target: [schema.inviteAttribution.guildId, schema.inviteAttribution.userId],
        set: {
          inviterId: attribution.inviterId,
          code: attribution.code,
          valid: true,
          leftAt: null,
          // A rejoin should not pay the inviter twice.
          rejoins: sql`${schema.inviteAttribution.rejoins} + 1`,
        },
      });

    await db.insert(schema.memberEvents).values({
      guildId: member.guild.id,
      userId: member.id,
      kind: 'join',
      memberCount: member.guild.memberCount,
    }).catch(() => undefined);

    if (attribution.inviterId && !fake) {
      await this.grantRewards(member.guild, attribution.inviterId).catch(() => undefined);
    }

    return attribution;
  }

  /** Finds the invite whose use count moved, then refreshes the snapshot. */
  private async attribute(guild: Guild): Promise<Attribution> {
    if (!guild.members.me?.permissions.has(PermissionFlagsBits.ManageGuild)) {
      return { inviterId: null, code: null, reason: 'no_permission' };
    }

    const before = this.map(guild.id);
    const invites = await guild.invites.fetch().catch(() => null);
    if (!invites) return { inviterId: null, code: null, reason: 'unknown' };

    let found: Attribution | null = null;

    for (const invite of invites.values()) {
      const previous = before.get(invite.code);
      if (previous && (invite.uses ?? 0) > previous.uses) {
        found = { inviterId: invite.inviterId ?? previous.inviterId, code: invite.code };
        break;
      }
    }

    // A single-use invite is deleted the moment it is used, so it is missing
    // from the new list rather than incremented.
    if (!found) {
      for (const [code, previous] of before) {
        if (code === guild.vanityURLCode) continue;
        if (!invites.has(code)) {
          found = { inviterId: previous.inviterId, code };
          break;
        }
      }
    }

    if (!found && guild.vanityURLCode) {
      const vanity = await guild.fetchVanityData().catch(() => null);
      const previous = before.get(guild.vanityURLCode);
      if (vanity && previous && vanity.uses > previous.uses) {
        found = { inviterId: null, code: guild.vanityURLCode, reason: 'vanity' };
      }
    }

    // Refresh before returning, so the next join diffs against current truth.
    const map = this.map(guild.id);
    map.clear();
    for (const invite of invites.values()) {
      map.set(invite.code, {
        uses: invite.uses ?? 0,
        inviterId: invite.inviterId ?? null,
        channelId: invite.channelId ?? null,
      });
    }
    if (guild.vanityURLCode) {
      const vanity = await guild.fetchVanityData().catch(() => null);
      if (vanity) map.set(guild.vanityURLCode, { uses: vanity.uses, inviterId: null, channelId: null });
    }

    await this.persistAll(guild.id, invites);
    return found ?? { inviterId: null, code: null, reason: 'unknown' };
  }

  private async onLeave(guildId: string, userId: string): Promise<void> {
    await db.update(schema.inviteAttribution)
      .set({ valid: false, leftAt: new Date() })
      .where(and(
        eq(schema.inviteAttribution.guildId, guildId),
        eq(schema.inviteAttribution.userId, userId),
      ));

    const guild = this.client.guilds.cache.get(guildId);
    await db.insert(schema.memberEvents).values({
      guildId, userId, kind: 'leave', memberCount: guild?.memberCount ?? null,
    }).catch(() => undefined);
  }

  /* ---------------------------------------------------------- rewards */

  private async grantRewards(guild: Guild, inviterId: string): Promise<void> {
    const rewards = await db.select().from(schema.inviteRewards)
      .where(eq(schema.inviteRewards.guildId, guild.id));
    if (!rewards.length) return;

    const total = await this.countFor(guild.id, inviterId);
    const member = await guild.members.fetch(inviterId).catch(() => null);
    if (!member) return;

    const me = guild.members.me!;
    const earned = rewards
      .filter((r) => total >= r.threshold)
      .map((r) => guild.roles.cache.get(r.roleId))
      .filter((role): role is NonNullable<typeof role> =>
        Boolean(role) && !member.roles.cache.has(role!.id) &&
        me.roles.highest.comparePositionTo(role!) > 0);

    if (earned.length) {
      await member.roles.add(earned, `Invite rewards at ${total} invites`).catch(() => undefined);
    }
  }

  /** Valid invites minus fakes, plus any manual adjustment. */
  async countFor(guildId: string, userId: string): Promise<number> {
    const [row] = await db
      .select({
        valid: sql<number>`count(*) filter (where ${schema.inviteAttribution.valid} and not ${schema.inviteAttribution.fake})`,
      })
      .from(schema.inviteAttribution)
      .where(and(
        eq(schema.inviteAttribution.guildId, guildId),
        eq(schema.inviteAttribution.inviterId, userId),
      ));

    const [adjustment] = await db.select().from(schema.inviteAdjustments).where(and(
      eq(schema.inviteAdjustments.guildId, guildId),
      eq(schema.inviteAdjustments.userId, userId),
    )).limit(1);

    return Number(row?.valid ?? 0) + (adjustment?.bonus ?? 0);
  }

  /** Full breakdown for `,invites`. */
  async statsFor(guildId: string, userId: string) {
    const [row] = await db
      .select({
        total: sql<number>`count(*)`,
        valid: sql<number>`count(*) filter (where ${schema.inviteAttribution.valid} and not ${schema.inviteAttribution.fake})`,
        left: sql<number>`count(*) filter (where not ${schema.inviteAttribution.valid})`,
        fake: sql<number>`count(*) filter (where ${schema.inviteAttribution.fake})`,
      })
      .from(schema.inviteAttribution)
      .where(and(
        eq(schema.inviteAttribution.guildId, guildId),
        eq(schema.inviteAttribution.inviterId, userId),
      ));

    const [adjustment] = await db.select().from(schema.inviteAdjustments).where(and(
      eq(schema.inviteAdjustments.guildId, guildId),
      eq(schema.inviteAdjustments.userId, userId),
    )).limit(1);

    return {
      total: Number(row?.total ?? 0),
      valid: Number(row?.valid ?? 0),
      left: Number(row?.left ?? 0),
      fake: Number(row?.fake ?? 0),
      bonus: adjustment?.bonus ?? 0,
    };
  }

  /** The leaderboard, computed in Postgres rather than in memory. */
  async leaderboard(guildId: string, limit = 10, offset = 0) {
    return db
      .select({
        inviterId: schema.inviteAttribution.inviterId,
        valid: sql<number>`count(*) filter (where ${schema.inviteAttribution.valid} and not ${schema.inviteAttribution.fake})`,
        left: sql<number>`count(*) filter (where not ${schema.inviteAttribution.valid})`,
        fake: sql<number>`count(*) filter (where ${schema.inviteAttribution.fake})`,
      })
      .from(schema.inviteAttribution)
      .where(and(
        eq(schema.inviteAttribution.guildId, guildId),
        sql`${schema.inviteAttribution.inviterId} is not null`,
      ))
      .groupBy(schema.inviteAttribution.inviterId)
      .orderBy(desc(sql`count(*) filter (where ${schema.inviteAttribution.valid} and not ${schema.inviteAttribution.fake})`))
      .limit(limit)
      .offset(offset);
  }

  /* -------------------------------------------------------- persistence */

  private async persist(guildId: string, invite: Invite): Promise<void> {
    await db.insert(schema.inviteCodes)
      .values({
        code: invite.code,
        guildId,
        inviterId: invite.inviterId ?? null,
        channelId: invite.channelId ?? null,
        uses: invite.uses ?? 0,
        maxUses: invite.maxUses ?? 0,
        expiresAt: invite.expiresAt ?? null,
      })
      .onConflictDoUpdate({
        target: schema.inviteCodes.code,
        set: { uses: invite.uses ?? 0 },
      })
      .catch(() => undefined);
  }

  private async persistAll(guildId: string, invites: Collection<string, Invite>): Promise<void> {
    if (!invites.size) return;
    await db.insert(schema.inviteCodes)
      .values(invites.map((invite) => ({
        code: invite.code,
        guildId,
        inviterId: invite.inviterId ?? null,
        channelId: invite.channelId ?? null,
        uses: invite.uses ?? 0,
        maxUses: invite.maxUses ?? 0,
        expiresAt: invite.expiresAt ?? null,
      })))
      .onConflictDoUpdate({
        target: schema.inviteCodes.code,
        set: { uses: sql`excluded.uses` },
      })
      .catch(() => undefined);
  }
}
