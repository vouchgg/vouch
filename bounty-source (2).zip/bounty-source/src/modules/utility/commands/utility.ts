/**
 * Roles and general utility.
 *
 * Snipes live in Redis with a TTL rather than a table — nobody needs the
 * message someone deleted last Tuesday, and a table would grow forever.
 */

import { PermissionFlagsBits, version as djsVersion } from 'discord.js';
import { eq } from 'drizzle-orm';
import { defineCommand, parseHex, parseDuration, type Command, type Context } from '../../../core/command.js';
import { assertRoleEditable } from '../../../core/middleware.js';
import { UsageError } from '../../../core/errors.js';
import { db, invalidateGuild, invalidateUser, schema } from '../../../db/index.js';
import { key, redis } from '../../../core/cache.js';
import { humanDuration, ts } from '../../../core/branding.js';

/* --------------------------------------------------------------- roles */

export const role = defineCommand({
  name: 'role',
  aliases: ['r'],
  module: 'Aesthetic',
  description: 'Give, take and edit roles',
  usage: 'role <user> <role>',
  userPermissions: [PermissionFlagsBits.ManageRoles],
  botPermissions: [PermissionFlagsBits.ManageRoles],
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);
    ctx.args.shift();
    const target = await ctx.resolveRole(0);
    assertRoleEditable(ctx.member, target.id);

    const had = member!.roles.cache.has(target.id);
    await member!.roles[had ? 'remove' : 'add'](target, `By ${ctx.author.tag}`);
    return ctx.ok(had ? `Took ${target} from ${member}.` : `Gave ${target} to ${member}.`);
  },
  subcommands: {
    create: {
      name: 'create', aliases: ['make', 'new'], module: 'Aesthetic',
      description: 'Create a role',
      usage: 'role create <name>',
      execute: async (ctx) => {
        const name = ctx.rest();
        if (!name) throw new UsageError('Give the role a name.');
        const created = await ctx.guild.roles.create({ name: name.slice(0, 100), reason: `By ${ctx.author.tag}` });
        return ctx.ok(`Created ${created}.`);
      },
    },
    delete: {
      name: 'delete', aliases: ['remove'], module: 'Aesthetic',
      description: 'Delete a role',
      usage: 'role delete <role>',
      execute: async (ctx) => {
        const target = await ctx.resolveRole(0);
        assertRoleEditable(ctx.member, target.id);
        const name = target.name;
        await target.delete(`By ${ctx.author.tag}`);
        return ctx.ok(`Deleted **${name}**.`);
      },
    },
    color: {
      name: 'color', aliases: ['colour', 'rcolor'], module: 'Aesthetic',
      description: 'Recolour a role',
      usage: 'role color <role> <hex>',
      examples: ['role color @VIP #ff0055'],
      execute: async (ctx) => {
        const target = await ctx.resolveRole(0);
        assertRoleEditable(ctx.member, target.id);
        const colour = parseHex(ctx.args[1] ?? '');
        if (colour === null) throw new UsageError('Give a hex colour like `#ff0055`.');
        await target.setColor(colour, `By ${ctx.author.tag}`);
        return ctx.ok(`${target} is now \`${target.hexColor}\`.`);
      },
    },
    icon: {
      name: 'icon', aliases: ['ricon'], module: 'Aesthetic',
      description: 'Set a role icon from an emoji or image link',
      usage: 'role icon <role> <emoji|url>',
      premium: true,
      execute: async (ctx) => {
        const target = await ctx.resolveRole(0);
        assertRoleEditable(ctx.member, target.id);
        if (ctx.guild.premiumTier < 2) {
          throw new UsageError('Role icons need boost level 2.');
        }

        const raw = ctx.args[1];
        if (!raw) throw new UsageError('Give an emoji or an image link.');
        const custom = raw.match(/<(a)?:\w+:(\d+)>/);
        const icon = custom
          ? `https://cdn.discordapp.com/emojis/${custom[2]}.${custom[1] ? 'gif' : 'png'}`
          : raw;

        await target.setIcon(icon, `By ${ctx.author.tag}`);
        return ctx.ok(`Updated ${target}'s icon.`);
      },
    },
    rename: {
      name: 'rename', aliases: ['name'], module: 'Aesthetic',
      description: 'Rename a role',
      usage: 'role rename <role> <name>',
      execute: async (ctx) => {
        const target = await ctx.resolveRole(0);
        assertRoleEditable(ctx.member, target.id);
        const name = ctx.rest(1);
        if (!name) throw new UsageError('Give the new name.');
        await target.setName(name.slice(0, 100), `By ${ctx.author.tag}`);
        return ctx.ok(`Renamed to **${target.name}**.`);
      },
    },
    hoist: {
      name: 'hoist', aliases: ['display'], module: 'Aesthetic',
      description: 'Show or hide a role separately in the member list',
      usage: 'role hoist <role>',
      execute: async (ctx) => {
        const target = await ctx.resolveRole(0);
        assertRoleEditable(ctx.member, target.id);
        await target.setHoist(!target.hoist);
        return ctx.ok(`${target} is ${target.hoist ? 'shown separately' : 'no longer separated'}.`);
      },
    },
    mentionable: {
      name: 'mentionable', aliases: ['mention'], module: 'Aesthetic',
      description: 'Let anyone ping a role, or stop them',
      usage: 'role mentionable <role>',
      execute: async (ctx) => {
        const target = await ctx.resolveRole(0);
        assertRoleEditable(ctx.member, target.id);
        await target.setMentionable(!target.mentionable);
        return ctx.ok(`${target} is ${target.mentionable ? 'now' : 'no longer'} mentionable.`);
      },
    },
    all: {
      name: 'all', aliases: ['everyone'], module: 'Aesthetic',
      description: 'Give a role to every member',
      usage: 'role all <role>',
      userPermissions: [PermissionFlagsBits.Administrator],
      cooldown: { uses: 1, windowMs: 300_000, scope: 'guild' },
      execute: async (ctx) => roleMany(ctx, () => true, 'everyone'),
    },
    humans: {
      name: 'humans', module: 'Aesthetic',
      description: 'Give a role to every person, skipping bots',
      usage: 'role humans <role>',
      userPermissions: [PermissionFlagsBits.Administrator],
      cooldown: { uses: 1, windowMs: 300_000, scope: 'guild' },
      execute: async (ctx) => roleMany(ctx, (m) => !m.user.bot, 'every person'),
    },
    bots: {
      name: 'bots', module: 'Aesthetic',
      description: 'Give a role to every bot',
      usage: 'role bots <role>',
      userPermissions: [PermissionFlagsBits.Administrator],
      cooldown: { uses: 1, windowMs: 300_000, scope: 'guild' },
      execute: async (ctx) => roleMany(ctx, (m) => m.user.bot, 'every bot'),
    },
  },
});

async function roleMany(
  ctx: Context,
  predicate: (m: import('discord.js').GuildMember) => boolean,
  label: string,
) {
  const target = await ctx.resolveRole(0);
  assertRoleEditable(ctx.member, target.id);

  const members = await ctx.guild.members.fetch();
  const todo = members.filter((m) => predicate(m) && !m.roles.cache.has(target.id));
  if (!todo.size) return ctx.ok(`${label} already has ${target}.`);

  const notice = await ctx.warn(`Adding ${target} to ${todo.size} members. This takes about ${humanDuration(todo.size * 400)}.`);

  let done = 0;
  for (const member of todo.values()) {
    const ok = await member.roles.add(target, `Mass role by ${ctx.author.tag}`)
      .then(() => true).catch(() => false);
    if (ok) done += 1;
  }

  await notice.edit({ embeds: [ctx.embed({ tone: 'success', description: `Gave ${target} to ${done} members.` })] });
  return notice;
}

/* ------------------------------------------------------------- snipes */

interface Snipe {
  content: string; authorId: string; at: number;
  attachments: string[]; edited?: string;
}

export const snipe = defineCommand({
  name: 'snipe',
  aliases: ['s'],
  module: 'Utility',
  description: 'Show the last deleted message here',
  usage: 'snipe [index]',
  cooldown: { uses: 4, windowMs: 8000 },
  execute: async (ctx) => {
    const index = Math.max(Number.parseInt(ctx.args[0] ?? '1', 10) || 1, 1);
    const raw = await redis.lindex(key.snipe(ctx.channel.id), index - 1).catch(() => null);
    if (!raw) throw new UsageError('Nothing to snipe here.');

    const snipe = JSON.parse(raw) as Snipe;
    return ctx.send({
      author: null,
      description: snipe.content || '*no text*',
      image: snipe.attachments[0],
      fields: snipe.attachments.length > 1
        ? [{ name: 'Attachments', value: `${snipe.attachments.length} files` }] : [],
      footer: `Deleted message ${index}`,
      timestamp: true,
    });
  },
  subcommands: {
    clear: {
      name: 'clear', module: 'Utility',
      description: 'Clear this channel\'s snipes',
      userPermissions: [PermissionFlagsBits.ManageMessages],
      execute: async (ctx) => {
        await redis.del(key.snipe(ctx.channel.id)).catch(() => undefined);
        return ctx.ok('Snipes cleared for this channel.');
      },
    },
  },
});

export const editsnipe = defineCommand({
  name: 'editsnipe',
  aliases: ['es'],
  module: 'Utility',
  description: 'Show the original text of an edited message',
  execute: async (ctx) => {
    const raw = await redis.lindex(`bounty:editsnipe:${ctx.channel.id}`, 0).catch(() => null);
    if (!raw) throw new UsageError('No recent edits here.');
    const snipe = JSON.parse(raw) as Snipe;
    return ctx.send({
      author: null,
      fields: [
        { name: 'Before', value: snipe.content || '*empty*' },
        { name: 'After', value: snipe.edited || '*empty*' },
      ],
      footer: 'Edited message',
    });
  },
});

/* ---------------------------------------------------------------- afk */

export const afk = defineCommand({
  name: 'afk',
  module: 'Utility',
  description: 'Tell people you are away',
  usage: 'afk [reason]',
  execute: async (ctx) => {
    const reason = ctx.rest().slice(0, 200) || 'Away';
    await redis.set(`bounty:afk:${ctx.guild.id}:${ctx.author.id}`,
      JSON.stringify({ reason, since: Date.now() }), 'EX', 604_800).catch(() => undefined);
    return ctx.ok(`You are AFK: ${reason}`);
  },
});

/* -------------------------------------------------------- server config */

export const prefix = defineCommand({
  name: 'prefix',
  aliases: ['setprefix'],
  module: 'Utility',
  description: 'Change the command prefix here',
  usage: 'prefix <new>',
  userPermissions: [PermissionFlagsBits.ManageGuild],
  execute: async (ctx) => {
    const wanted = ctx.args[0];
    if (!wanted) return ctx.send({ description: `The prefix here is \`${ctx.guildConfig.prefix}\`.` });
    if (wanted.length > 5) throw new UsageError('Keep the prefix to five characters or fewer.');

    await db.update(schema.guilds).set({ prefix: wanted, updatedAt: new Date() })
      .where(eq(schema.guilds.id, ctx.guild.id));
    await invalidateGuild(ctx.guild.id);
    return ctx.ok(`Prefix is now \`${wanted}\`. Pinging Bounty always works too.`);
  },
});

export const embedcolor = defineCommand({
  name: 'embedcolor',
  aliases: ['color', 'colour', 'accent'],
  module: 'Utility',
  description: 'Set the accent colour on Bounty embeds',
  usage: 'embedcolor <hex>',
  userPermissions: [PermissionFlagsBits.ManageGuild],
  execute: async (ctx) => {
    const colour = parseHex(ctx.args[0] ?? '');
    if (colour === null) throw new UsageError('Give a hex colour like `#5B2E9D`.');
    const hex = colour.toString(16).padStart(6, '0').toUpperCase();

    await db.update(schema.guilds).set({ embedColor: hex, updatedAt: new Date() })
      .where(eq(schema.guilds.id, ctx.guild.id));
    await invalidateGuild(ctx.guild.id);
    return ctx.ok(`Embeds are now \`#${hex}\`.`, { color: colour });
  },
  subcommands: {
    me: {
      name: 'me', aliases: ['personal'], module: 'Utility',
      description: 'Set your own accent, used wherever you run commands',
      userPermissions: [],
      execute: async (ctx) => {
        const raw = ctx.args[0];
        if (!raw || raw === 'none') {
          await db.update(schema.users).set({ embedColor: null }).where(eq(schema.users.id, ctx.author.id));
          await invalidateUser(ctx.author.id);
          return ctx.ok('Your personal colour is cleared.');
        }
        const colour = parseHex(raw);
        if (colour === null) throw new UsageError('Give a hex colour.');
        const hex = colour.toString(16).padStart(6, '0').toUpperCase();
        await db.update(schema.users).set({ embedColor: hex }).where(eq(schema.users.id, ctx.author.id));
        await invalidateUser(ctx.author.id);
        return ctx.ok(`Your embeds are now \`#${hex}\`.`, { color: colour });
      },
    },
  },
});

export const alias = defineCommand({
  name: 'alias',
  aliases: ['cmdalias'],
  module: 'Utility',
  description: 'Make your own command shortcuts',
  userPermissions: [PermissionFlagsBits.ManageGuild],
  subcommands: {
    add: {
      name: 'add', aliases: ['create'], module: 'Utility',
      description: 'Point a shortcut at a command',
      usage: 'alias add <shortcut> <command>',
      examples: ['alias add avh avatarhistory', 'alias add cleanup purge bots 50'],
      execute: async (ctx) => {
        const shortcut = ctx.args[0]?.toLowerCase();
        const target = ctx.rest(1);
        if (!shortcut || !target) throw new UsageError('Give the shortcut, then the command it runs.');
        if (ctx.client.commands.commands.has(shortcut)) {
          throw new UsageError(`\`${shortcut}\` is already a real command.`);
        }

        await db.insert(schema.commandAliases)
          .values({ guildId: ctx.guild.id, alias: shortcut, target, createdBy: ctx.author.id })
          .onConflictDoUpdate({
            target: [schema.commandAliases.guildId, schema.commandAliases.alias],
            set: { target },
          });
        await invalidateGuild(ctx.guild.id);
        return ctx.ok(`\`${ctx.guildConfig.prefix}${shortcut}\` now runs \`${ctx.guildConfig.prefix}${target}\`.`);
      },
    },
    remove: {
      name: 'remove', aliases: ['delete'], module: 'Utility',
      description: 'Delete a shortcut',
      usage: 'alias remove <shortcut>',
      execute: async (ctx) => {
        const shortcut = ctx.args[0]?.toLowerCase();
        if (!shortcut) throw new UsageError('Name the shortcut.');
        const deleted = await db.delete(schema.commandAliases)
          .where(eq(schema.commandAliases.alias, shortcut)).returning();
        if (!deleted.length) throw new UsageError(`No shortcut called \`${shortcut}\`.`);
        await invalidateGuild(ctx.guild.id);
        return ctx.ok(`Removed \`${shortcut}\`.`);
      },
    },
    list: {
      name: 'list', module: 'Utility',
      description: 'Show every shortcut in this server',
      execute: async (ctx) => {
        const rows = await db.select().from(schema.commandAliases)
          .where(eq(schema.commandAliases.guildId, ctx.guild.id));
        if (!rows.length) return ctx.warn('No shortcuts yet.');
        return ctx.send({
          title: 'Command shortcuts',
          description: rows.map((r) => `\`${ctx.guildConfig.prefix}${r.alias}\` → \`${r.target}\``).join('\n'),
        });
      },
    },
  },
});

/* --------------------------------------------------------------- meta */

export const ping = defineCommand({
  name: 'ping',
  aliases: ['latency'],
  module: 'Utility',
  description: 'Check how fast Bounty is responding',
  execute: async (ctx) => {
    const started = Date.now();
    const reply = await ctx.send({ description: 'Measuring…' });
    return reply.edit({
      embeds: [ctx.embed({
        title: 'Pong',
        fields: [
          { name: 'Round trip', value: `${Date.now() - started}ms`, inline: true },
          { name: 'Gateway', value: `${Math.round(ctx.client.ws.ping)}ms`, inline: true },
          { name: 'Uptime', value: humanDuration(ctx.client.uptime ?? 0), inline: true },
        ],
      })],
    });
  },
});

export const botinfo = defineCommand({
  name: 'botinfo',
  aliases: ['about', 'stats'],
  module: 'Utility',
  description: 'About Bounty',
  execute: async (ctx) => {
    const memory = process.memoryUsage().heapUsed / 1024 / 1024;
    return ctx.send({
      title: 'Bounty',
      thumbnail: ctx.client.user!.displayAvatarURL({ size: 128 }),
      fields: [
        { name: 'Servers', value: ctx.client.guilds.cache.size.toLocaleString('en-GB'), inline: true },
        { name: 'Members', value: ctx.client.guilds.cache
          .reduce((n, g) => n + g.memberCount, 0).toLocaleString('en-GB'), inline: true },
        { name: 'Commands', value: String(ctx.client.commands.commands.size), inline: true },
        { name: 'Uptime', value: humanDuration(ctx.client.uptime ?? 0), inline: true },
        { name: 'Memory', value: `${memory.toFixed(0)} MB`, inline: true },
        { name: 'Library', value: `discord.js ${djsVersion}`, inline: true },
      ],
    });
  },
});

export const remind = defineCommand({
  name: 'remind',
  aliases: ['reminder', 'rm'],
  module: 'Utility',
  description: 'Get a reminder later',
  usage: 'remind <duration> <what>',
  examples: ['remind 2h check the giveaway'],
  execute: async (ctx) => {
    const duration = parseDuration(ctx.args[0] ?? '');
    const what = ctx.rest(1);
    if (!duration || !what) throw new UsageError('Give a duration then what to remind you about.');
    if (duration > 30 * 86_400_000) throw new UsageError('Thirty days is the longest reminder.');

    const at = Date.now() + duration;
    await redis.zadd('bounty:reminders', at, JSON.stringify({
      userId: ctx.author.id, channelId: ctx.channel.id, text: what.slice(0, 500), at,
    })).catch(() => undefined);

    return ctx.ok(`Reminder set for ${ts(at)}.`);
  },
});

const helpModules: Command['module'][] = [
  'Lookups', 'VoiceMaster', 'Giveaways', 'Tickets',
  'Aesthetic', 'Moderation', 'CustomInstanceHost', 'Utility', 'LastFM', 'Bio',
];

export const help = defineCommand({
  name: 'help',
  aliases: ['commands', 'h'],
  module: 'Utility',
  description: 'List commands, or explain one',
  usage: 'help [command]',
  execute: async (ctx) => {
    const query = ctx.args.join(' ').toLowerCase();

    if (query) {
      const resolved = ctx.client.commands.resolve(query);
      if (!resolved) throw new UsageError(`No command called \`${query}\`.`);
      const { command, path } = resolved;

      return ctx.send({
        title: `${ctx.guildConfig.prefix}${path.replace(/\./g, ' ')}`,
        description: command.description,
        fields: [
          ...(command.usage ? [{ name: 'Usage', value: `\`${ctx.guildConfig.prefix}${command.usage}\`` }] : []),
          ...(command.examples?.length
            ? [{ name: 'Examples', value: command.examples.map((e) => `\`${ctx.guildConfig.prefix}${e}\``).join('\n') }]
            : []),
          ...(command.aliases?.length
            ? [{ name: 'Aliases', value: command.aliases.map((a) => `\`${a}\``).join(' ') }] : []),
          ...(command.subcommands
            ? [{
              name: 'Subcommands',
              value: Object.values(command.subcommands)
                .map((s) => `\`${s.name}\` — ${s.description}`).join('\n').slice(0, 1000),
            }] : []),
          ...(command.userPermissions?.length
            ? [{ name: 'You need', value: command.userPermissions.map(String).join(', ') }] : []),
        ],
      });
    }

    return ctx.send({
      title: 'Bounty commands',
      description:
        `Prefix here is \`${ctx.guildConfig.prefix}\`. ` +
        `Run \`${ctx.guildConfig.prefix}help <command>\` for details on any one.`,
      fields: helpModules.map((module) => {
        const commands = ctx.client.commands.byModule(module);
        return commands.length ? {
          name: `${module} · ${commands.length}`,
          value: commands.map((c) => `\`${c.name}\``).join(' ').slice(0, 1000),
        } : null;
      }).filter((f): f is NonNullable<typeof f> => f !== null),
    });
  },
});
