/**
 * VoiceMaster engine.
 *
 * Everything that mutates a temporary channel lives here, so `,vc lock` and
 * the Lock button on the control panel run the same code path — there is no
 * second implementation to drift.
 *
 * Failure modes this engine is built around:
 *  - voiceStateUpdate fires out of order during a channel move
 *  - a user rejoining 200ms after leaving must not lose their channel
 *  - two joins from one user (desktop + phone) must not spawn two channels
 *  - Discord rate limits channel renames to 2 per 10 minutes, per channel
 *  - the bot restarts leaving orphaned channels behind
 *  - a moderator deletes a temp channel by hand
 */

import {
  ChannelType, DiscordAPIError, PermissionFlagsBits, RESTJSONErrorCodes,
  type CategoryChannel, type Guild, type GuildMember, type OverwriteResolvable,
  type VoiceBasedChannel, type VoiceState,
} from 'discord.js';
import { and, eq } from 'drizzle-orm';
import { db, schema } from '../../db/index.js';
import { consume, forget, key, redis, remember, TTL, withLock } from '../../core/cache.js';
import {
  BotPermissionError, NotFoundError, PermissionError, UpstreamError, UsageError,
} from '../../core/errors.js';
import { logger } from '../../core/logger.js';
import type { BountyClient } from '../../core/client.js';
import type { VmChannel, VmConfig, VmUserSettings } from '../../db/schema.js';

const VOICE_PERMS = [
  PermissionFlagsBits.ManageChannels,
  PermissionFlagsBits.MoveMembers,
  PermissionFlagsBits.ViewChannel,
  PermissionFlagsBits.Connect,
] as const;

/** Discord's own limit on channel edits. Exceeding it stalls for minutes. */
const RENAME_LIMIT = { uses: 2, windowMs: 10 * 60_000 };
/** Stops one person cycling the generator to spam channel creation. */
const CREATE_COOLDOWN = { uses: 2, windowMs: 30_000 };

export class VoiceMasterEngine {
  /** Pending deletions, keyed by channel id. Cancelled if someone rejoins. */
  private readonly reaper = new Map<string, NodeJS.Timeout>();

  constructor(private readonly client: BountyClient) {}

  attach(): void {
    this.client.on('voiceStateUpdate', (oldState, newState) => {
      void this.onVoiceStateUpdate(oldState, newState).catch((err) => {
        logger.error({ err, guildId: newState.guild.id }, 'voiceStateUpdate failed');
      });
    });

    // A human deleting the channel is a legitimate way to end it.
    this.client.on('channelDelete', (channel) => {
      if (channel.isVoiceBased()) void this.forgetChannel(channel.id);
    });

    this.client.once('ready', () => void this.sweepOrphans());
  }

  /* ------------------------------------------------------- event router */

  private async onVoiceStateUpdate(oldState: VoiceState, newState: VoiceState): Promise<void> {
    const left = oldState.channelId && oldState.channelId !== newState.channelId ? oldState.channelId : null;
    const joined = newState.channelId && oldState.channelId !== newState.channelId ? newState.channelId : null;

    // Mute/deafen/stream toggles fire this event with no channel change.
    if (!left && !joined) return;

    const config = await this.getConfig(newState.guild.id);
    if (!config?.enabled) {
      // Still clean up channels from a setup that was disabled mid-session.
      if (left) await this.handleLeave(oldState, left);
      return;
    }

    // Handle the departure first: a move out of a temp channel into the
    // generator must free the old channel before the new one is created.
    if (left) await this.handleLeave(oldState, left);

    if (joined === config.generatorChannelId && newState.member) {
      await this.handleGeneratorJoin(newState.member, config);
      return;
    }

    if (joined) this.cancelReap(joined);
  }

  /* ----------------------------------------------------- channel spawn */

  private async handleGeneratorJoin(member: GuildMember, config: VmConfig): Promise<void> {
    // One creation at a time per user: a phone and desktop client joining
    // together produce two events milliseconds apart.
    const result = await withLock(`vm:create:${member.guild.id}:${member.id}`, 15_000, async () => {
      // Still in the generator? If they already bailed, do nothing.
      if (member.voice.channelId !== config.generatorChannelId) return null;

      const cooldown = await consume(
        key.vmCooldown(member.guild.id, member.id),
        CREATE_COOLDOWN.uses, CREATE_COOLDOWN.windowMs,
      );
      if (cooldown.limited) {
        await this.nudge(member, 'You are creating channels too quickly. Wait a moment and rejoin.');
        return null;
      }

      // Reuse an existing owned channel instead of stacking duplicates.
      const [existing] = await db.select().from(schema.vmChannels)
        .where(and(
          eq(schema.vmChannels.guildId, member.guild.id),
          eq(schema.vmChannels.ownerId, member.id),
        )).limit(1);

      if (existing && member.guild.channels.cache.has(existing.channelId)) {
        await member.voice.setChannel(existing.channelId).catch(() => undefined);
        return null;
      }
      if (existing) await this.forgetChannel(existing.channelId);

      return this.createChannel(member, config);
    });

    if (result === null) return;
  }

  private async createChannel(member: GuildMember, config: VmConfig): Promise<VoiceBasedChannel | null> {
    const guild = member.guild;
    const me = guild.members.me!;

    const missing = me.permissions.missing(VOICE_PERMS as unknown as bigint[]);
    if (missing.length) {
      await this.nudge(member, 'Bounty is missing Manage Channels or Move Members, so it cannot build your channel.');
      throw new BotPermissionError(missing);
    }

    const category = guild.channels.cache.get(config.categoryId) as CategoryChannel | undefined;
    const settings = config.persistUserSettings ? await this.getUserSettings(guild.id, member.id) : null;

    try {
      const channel = await guild.channels.create({
        name: renderName(settings?.name ?? config.nameTemplate, member),
        type: ChannelType.GuildVoice,
        parent: category ?? null,
        userLimit: clampLimit(settings?.userLimit ?? config.defaultLimit),
        bitrate: clampBitrate(settings?.bitrate ?? config.defaultBitrate, guild),
        rtcRegion: settings?.region ?? config.defaultRegion ?? undefined,
        permissionOverwrites: buildOverwrites(guild, member.id, settings),
        reason: `VoiceMaster: temporary channel for ${member.user.tag}`,
      });

      await db.insert(schema.vmChannels).values({
        channelId: channel.id,
        guildId: guild.id,
        ownerId: member.id,
        locked: settings?.locked ?? false,
        hidden: settings?.hidden ?? false,
      });

      // Owner lookups happen on every button press; keep them off Postgres.
      await redis.set(key.vmOwner(channel.id), member.id, 'EX', 86_400).catch(() => undefined);

      // Move last: if the move fails the channel is still tracked and reaped.
      await member.voice.setChannel(channel).catch(async (err) => {
        if (err instanceof DiscordAPIError && err.code === RESTJSONErrorCodes.UnknownMember) {
          // They disconnected between creation and the move.
          await this.destroy(channel.id, 'owner left before move');
          return;
        }
        throw err;
      });

      logger.debug({ channelId: channel.id, ownerId: member.id }, 'temp channel created');
      return channel;
    } catch (err) {
      if (err instanceof DiscordAPIError &&
          err.code === RESTJSONErrorCodes.MaximumNumberOfGuildChannelsReached) {
        await this.nudge(member, 'This server has hit the 500 channel limit, so no channel could be created.');
        return null;
      }
      if (err instanceof DiscordAPIError && err.status === 429) {
        await this.nudge(member, 'Discord is rate limiting channel creation. Try again in a few seconds.');
        throw new UpstreamError('Channel creation is rate limited.');
      }
      throw err;
    }
  }

  /* ---------------------------------------------------- channel teardown */

  private async handleLeave(state: VoiceState, channelId: string): Promise<void> {
    const record = await this.getRecord(channelId);
    if (!record) return;

    const channel = state.guild.channels.cache.get(channelId) as VoiceBasedChannel | undefined;
    if (!channel) { await this.forgetChannel(channelId); return; }

    const humans = channel.members.filter((m) => !m.user.bot);

    if (humans.size === 0) {
      const config = await this.getConfig(state.guild.id);
      this.scheduleReap(channelId, (config?.emptyGraceSeconds ?? 5) * 1000);
      return;
    }

    if (record.ownerId !== state.id) return;

    // The owner left a populated channel.
    const config = await this.getConfig(state.guild.id);
    if (config?.autoTransferOwner) {
      const heir = pickHeir(channel, record);
      if (heir) { await this.transferTo(channelId, heir.id, 'owner left'); return; }
    }

    await db.update(schema.vmChannels)
      .set({ claimable: true, lastEmptyAt: new Date() })
      .where(eq(schema.vmChannels.channelId, channelId));
  }

  /**
   * Grace period before deletion. Someone reconnecting after a crash, or
   * being dragged between channels, would otherwise lose the channel between
   * two events that arrive milliseconds apart.
   */
  private scheduleReap(channelId: string, delayMs: number): void {
    this.cancelReap(channelId);
    const timer = setTimeout(() => {
      this.reaper.delete(channelId);
      void this.destroy(channelId, 'empty').catch((err) =>
        logger.warn({ err, channelId }, 'reap failed'));
    }, delayMs);
    timer.unref();
    this.reaper.set(channelId, timer);
  }

  private cancelReap(channelId: string): void {
    const timer = this.reaper.get(channelId);
    if (timer) { clearTimeout(timer); this.reaper.delete(channelId); }
  }

  private async destroy(channelId: string, reason: string): Promise<void> {
    const channel = this.client.channels.cache.get(channelId) as VoiceBasedChannel | undefined;

    // Re-check occupancy: the grace window may have been repopulated.
    if (channel?.members.some((m) => !m.user.bot)) return;

    if (channel) {
      await channel.delete(`VoiceMaster: ${reason}`).catch((err) => {
        if (err instanceof DiscordAPIError && err.code === RESTJSONErrorCodes.UnknownChannel) return;
        logger.warn({ err, channelId }, 'could not delete temp channel');
      });
    }
    await this.forgetChannel(channelId);
  }

  private async forgetChannel(channelId: string): Promise<void> {
    this.cancelReap(channelId);
    await Promise.all([
      db.delete(schema.vmChannels).where(eq(schema.vmChannels.channelId, channelId)).catch(() => undefined),
      forget(key.vmOwner(channelId)),
    ]);
  }

  /** On boot, delete channels the previous process left behind. */
  private async sweepOrphans(): Promise<void> {
    const rows = await db.select().from(schema.vmChannels).catch(() => [] as VmChannel[]);
    let removed = 0;

    for (const row of rows) {
      const channel = this.client.channels.cache.get(row.channelId) as VoiceBasedChannel | undefined;
      if (!channel) { await this.forgetChannel(row.channelId); removed += 1; continue; }
      if (!channel.members.some((m) => !m.user.bot)) {
        await this.destroy(row.channelId, 'orphaned across restart');
        removed += 1;
      }
    }
    if (removed) logger.info({ removed }, 'voicemaster orphans swept');
  }

  /* ------------------------------------------------------- state access */

  async getConfig(guildId: string): Promise<VmConfig | null> {
    return remember(key.vmConfig(guildId), TTL.guildConfig, async () => {
      const [row] = await db.select().from(schema.vmConfigs)
        .where(eq(schema.vmConfigs.guildId, guildId)).limit(1);
      return row ?? null;
    });
  }

  async getRecord(channelId: string): Promise<VmChannel | null> {
    const [row] = await db.select().from(schema.vmChannels)
      .where(eq(schema.vmChannels.channelId, channelId)).limit(1);
    return row ?? null;
  }

  private async getUserSettings(guildId: string, userId: string): Promise<VmUserSettings | null> {
    const [row] = await db.select().from(schema.vmUserSettings)
      .where(and(eq(schema.vmUserSettings.guildId, guildId), eq(schema.vmUserSettings.userId, userId)))
      .limit(1);
    return row ?? null;
  }

  private async saveUserSettings(guildId: string, userId: string, patch: Partial<VmUserSettings>): Promise<void> {
    await db.insert(schema.vmUserSettings)
      .values({ guildId, userId, ...patch })
      .onConflictDoUpdate({
        target: [schema.vmUserSettings.guildId, schema.vmUserSettings.userId],
        set: { ...patch, updatedAt: new Date() },
      });
  }

  /**
   * Resolves the caller's channel and confirms they may control it. Owner,
   * trusted co-owner, or a staff member with Manage Channels.
   */
  async requireControl(member: GuildMember): Promise<{ channel: VoiceBasedChannel; record: VmChannel }> {
    const channel = member.voice.channel;
    if (!channel) throw new UsageError('Join your temporary voice channel first.');

    const record = await this.getRecord(channel.id);
    if (!record) throw new UsageError('That is not a Bounty temporary channel.');

    const allowed = record.ownerId === member.id
      || record.trustedIds.includes(member.id)
      || member.permissions.has(PermissionFlagsBits.ManageChannels);

    if (!allowed) {
      throw new PermissionError(
        `<@${record.ownerId}> owns this channel.`,
        'Ask them for co-owner access with `,vc trust @you`.',
      );
    }
    return { channel, record };
  }

  /* ---------------------------------------------------------- mutations */

  async setLock(member: GuildMember, locked: boolean): Promise<VoiceBasedChannel> {
    const { channel, record } = await this.requireControl(member);

    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, { Connect: locked ? false : null });
    await db.update(schema.vmChannels).set({ locked }).where(eq(schema.vmChannels.channelId, channel.id));
    await this.saveUserSettings(channel.guild.id, record.ownerId, { locked });
    return channel;
  }

  async setHidden(member: GuildMember, hidden: boolean): Promise<VoiceBasedChannel> {
    const { channel, record } = await this.requireControl(member);

    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, { ViewChannel: hidden ? false : null });
    await db.update(schema.vmChannels).set({ hidden }).where(eq(schema.vmChannels.channelId, channel.id));
    await this.saveUserSettings(channel.guild.id, record.ownerId, { hidden });
    return channel;
  }

  /** `,vc ghost` — lock and hide in one write instead of two API calls. */
  async setGhost(member: GuildMember, ghost: boolean): Promise<VoiceBasedChannel> {
    const { channel, record } = await this.requireControl(member);

    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
      Connect: ghost ? false : null,
      ViewChannel: ghost ? false : null,
    });
    await db.update(schema.vmChannels)
      .set({ locked: ghost, hidden: ghost })
      .where(eq(schema.vmChannels.channelId, channel.id));
    await this.saveUserSettings(channel.guild.id, record.ownerId, { locked: ghost, hidden: ghost });
    return channel;
  }

  async permit(member: GuildMember, target: GuildMember): Promise<void> {
    const { channel, record } = await this.requireControl(member);

    await channel.permissionOverwrites.edit(target.id, {
      Connect: true, ViewChannel: true,
    }, { reason: `VoiceMaster: permitted by ${member.user.tag}` });

    const settings = await this.getUserSettings(channel.guild.id, record.ownerId);
    await this.saveUserSettings(channel.guild.id, record.ownerId, {
      permittedIds: unique([...(settings?.permittedIds ?? []), target.id]),
      rejectedIds: (settings?.rejectedIds ?? []).filter((id) => id !== target.id),
    });
  }

  async reject(member: GuildMember, target: GuildMember): Promise<void> {
    const { channel, record } = await this.requireControl(member);

    if (target.id === record.ownerId) {
      throw new UsageError('The owner cannot be rejected from their own channel.');
    }
    if (target.permissions.has(PermissionFlagsBits.Administrator)) {
      throw new PermissionError('Administrators cannot be removed from a channel.');
    }

    await channel.permissionOverwrites.edit(target.id, { Connect: false, ViewChannel: false });
    if (target.voice.channelId === channel.id) {
      await target.voice.disconnect(`VoiceMaster: rejected by ${member.user.tag}`).catch(() => undefined);
    }

    const settings = await this.getUserSettings(channel.guild.id, record.ownerId);
    await this.saveUserSettings(channel.guild.id, record.ownerId, {
      rejectedIds: unique([...(settings?.rejectedIds ?? []), target.id]),
      permittedIds: (settings?.permittedIds ?? []).filter((id) => id !== target.id),
    });
  }

  async setTrust(member: GuildMember, target: GuildMember, trusted: boolean): Promise<void> {
    const { channel, record } = await this.requireControl(member);
    if (record.ownerId !== member.id) {
      throw new PermissionError('Only the channel owner can change co-owners.');
    }

    const next = trusted
      ? unique([...record.trustedIds, target.id])
      : record.trustedIds.filter((id) => id !== target.id);

    await db.update(schema.vmChannels).set({ trustedIds: next })
      .where(eq(schema.vmChannels.channelId, channel.id));

    if (trusted) {
      await channel.permissionOverwrites.edit(target.id, { Connect: true, ViewChannel: true });
    }
  }

  /**
   * Renames are the one operation Discord throttles hard: 2 edits per 10
   * minutes per channel. We check our own counter first so the user gets an
   * explanation instead of a request that silently hangs for minutes.
   */
  async rename(member: GuildMember, name: string): Promise<VoiceBasedChannel> {
    const { channel, record } = await this.requireControl(member);

    const clean = sanitizeName(name);
    if (!clean) throw new UsageError('Give the channel a name of 1 to 100 characters.');

    const bucket = await consume(`bounty:vm:rename:${channel.id}`, RENAME_LIMIT.uses, RENAME_LIMIT.windowMs);
    if (bucket.limited) {
      throw new UpstreamError(
        'Discord only allows two channel renames every 10 minutes.',
        `Try again in ${Math.ceil(bucket.retryAfterMs / 60_000)} minutes.`,
      );
    }

    await channel.setName(clean, `VoiceMaster: renamed by ${member.user.tag}`);
    await this.saveUserSettings(channel.guild.id, record.ownerId, { name: clean });
    return channel;
  }

  async setLimit(member: GuildMember, limit: number): Promise<VoiceBasedChannel> {
    const { channel, record } = await this.requireControl(member);
    if (!Number.isInteger(limit) || limit < 0 || limit > 99) {
      throw new UsageError('Pick a limit between 0 and 99. Zero means unlimited.');
    }
    await channel.setUserLimit(limit);
    await this.saveUserSettings(channel.guild.id, record.ownerId, { userLimit: limit });
    return channel;
  }

  async setBitrate(member: GuildMember, kbps: number): Promise<VoiceBasedChannel> {
    const { channel, record } = await this.requireControl(member);
    const max = maxBitrate(channel.guild) / 1000;
    if (kbps < 8 || kbps > max) {
      throw new UsageError(`Bitrate must be between 8 and ${max} kbps at this server's boost level.`);
    }
    await channel.setBitrate(kbps * 1000);
    await this.saveUserSettings(channel.guild.id, record.ownerId, { bitrate: kbps * 1000 });
    return channel;
  }

  async setRegion(member: GuildMember, region: string | null): Promise<VoiceBasedChannel> {
    const { channel, record } = await this.requireControl(member);
    await channel.setRTCRegion(region, 'VoiceMaster: region change');
    await this.saveUserSettings(channel.guild.id, record.ownerId, { region: region ?? null });
    return channel;
  }

  /** `,vc claim` — only valid once the owner has actually left the channel. */
  async claim(member: GuildMember): Promise<VoiceBasedChannel> {
    const channel = member.voice.channel;
    if (!channel) throw new UsageError('Join the channel you want to claim.');

    const record = await this.getRecord(channel.id);
    if (!record) throw new UsageError('That is not a Bounty temporary channel.');
    if (record.ownerId === member.id) throw new UsageError('You already own this channel.');

    const ownerPresent = channel.members.has(record.ownerId);
    if (ownerPresent) {
      throw new PermissionError(
        `<@${record.ownerId}> is still in this channel.`,
        'A channel can only be claimed once its owner leaves.',
      );
    }

    await this.transferTo(channel.id, member.id, `claimed by ${member.user.tag}`);
    return channel;
  }

  /** `,vc transfer @user` — deliberate handover while the owner is present. */
  async transfer(member: GuildMember, target: GuildMember): Promise<void> {
    const { channel, record } = await this.requireControl(member);
    if (record.ownerId !== member.id) throw new PermissionError('Only the owner can transfer the channel.');
    if (target.id === member.id) throw new UsageError('You already own this channel.');
    if (target.voice.channelId !== channel.id) {
      throw new UsageError(`${target} has to be in the channel to receive it.`);
    }
    if (target.user.bot) throw new UsageError('Bots cannot own channels.');

    await this.transferTo(channel.id, target.id, `transferred by ${member.user.tag}`);
  }

  private async transferTo(channelId: string, newOwnerId: string, reason: string): Promise<void> {
    const channel = this.client.channels.cache.get(channelId) as VoiceBasedChannel | undefined;
    if (!channel) throw new NotFoundError('That channel no longer exists.');

    const record = await this.getRecord(channelId);
    if (!record) throw new NotFoundError('That channel is no longer managed by Bounty.');

    await db.update(schema.vmChannels)
      .set({ ownerId: newOwnerId, claimable: false, trustedIds: record.trustedIds.filter((id) => id !== newOwnerId) })
      .where(eq(schema.vmChannels.channelId, channelId));

    await redis.set(key.vmOwner(channelId), newOwnerId, 'EX', 86_400).catch(() => undefined);

    // Move the owner overwrite across, leaving the old owner as a normal member.
    await channel.permissionOverwrites.edit(newOwnerId, {
      Connect: true, ViewChannel: true, ManageChannels: true, MoveMembers: true,
    }, { reason: `VoiceMaster: ${reason}` });

    await channel.permissionOverwrites.edit(record.ownerId, {
      ManageChannels: null, MoveMembers: null,
    }).catch(() => undefined);

    logger.debug({ channelId, from: record.ownerId, to: newOwnerId, reason }, 'ownership moved');
  }

  /** Tears down an entire guild's setup. Backs `,voicemaster reset`. */
  async resetGuild(guild: Guild): Promise<number> {
    const rows = await db.select().from(schema.vmChannels)
      .where(eq(schema.vmChannels.guildId, guild.id));

    for (const row of rows) await this.destroy(row.channelId, 'setup reset');

    const config = await this.getConfig(guild.id);
    if (config) {
      await guild.channels.cache.get(config.generatorChannelId)
        ?.delete('VoiceMaster: setup reset').catch(() => undefined);
      await db.delete(schema.vmConfigs).where(eq(schema.vmConfigs.guildId, guild.id));
      await forget(key.vmConfig(guild.id));
    }
    return rows.length;
  }

  /** Best-effort notice into the channel the member is in. Never throws. */
  private async nudge(member: GuildMember, message: string): Promise<void> {
    await member.send(message).catch(() => undefined);
  }
}

/* ------------------------------------------------------------- helpers */

function buildOverwrites(
  guild: Guild,
  ownerId: string,
  settings: VmUserSettings | null,
): OverwriteResolvable[] {
  const overwrites: OverwriteResolvable[] = [
    {
      id: guild.roles.everyone.id,
      deny: [
        ...(settings?.locked ? [PermissionFlagsBits.Connect] : []),
        ...(settings?.hidden ? [PermissionFlagsBits.ViewChannel] : []),
      ],
    },
    {
      id: ownerId,
      allow: [
        PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect,
        PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers,
        PermissionFlagsBits.Speak, PermissionFlagsBits.Stream,
      ],
    },
    {
      // Without this the bot can lose access to a channel it just hid.
      id: guild.members.me!.id,
      allow: [
        PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect,
        PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers,
      ],
    },
  ];

  for (const id of settings?.permittedIds ?? []) {
    overwrites.push({ id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect] });
  }
  for (const id of settings?.rejectedIds ?? []) {
    overwrites.push({ id, deny: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect] });
  }
  return overwrites;
}

/** Longest-present non-bot member, preferring anyone already trusted. */
function pickHeir(channel: VoiceBasedChannel, record: VmChannel): GuildMember | null {
  const candidates = [...channel.members.values()].filter((m) => !m.user.bot && m.id !== record.ownerId);
  if (!candidates.length) return null;
  return candidates.find((m) => record.trustedIds.includes(m.id)) ?? candidates[0];
}

function renderName(template: string, member: GuildMember): string {
  const filled = template
    .replaceAll('{user}', member.displayName)
    .replaceAll('{user.name}', member.user.username)
    .replaceAll('{count}', String(member.guild.channels.cache.size))
    .replaceAll('{game}', member.presence?.activities.find((a) => a.type === 0)?.name ?? 'Voice');
  return sanitizeName(filled) || `${member.displayName}'s channel`.slice(0, 100);
}

/** Strips mentions and control characters — a channel name is not a message. */
function sanitizeName(input: string): string {
  return input
    .replace(/@(everyone|here)/gi, '$1')
    .replace(/[\u0000-\u001F\u007F]/g, '')
    .trim()
    .slice(0, 100);
}

const clampLimit = (limit: number | null | undefined) => Math.min(Math.max(limit ?? 0, 0), 99);

function maxBitrate(guild: Guild): number {
  return [96_000, 128_000, 256_000, 384_000][guild.premiumTier] ?? 96_000;
}

const clampBitrate = (bitrate: number, guild: Guild) =>
  Math.min(Math.max(bitrate, 8000), maxBitrate(guild));

const unique = (values: string[]) => [...new Set(values)];
