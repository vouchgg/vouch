/**
 * `,vc …` and `,voicemaster …`
 *
 * Note what is not here: no `switch (args[0])`, no argument index juggling.
 * The resolver hands each leaf exactly the arguments that follow it, and
 * every leaf delegates straight to the engine, which is also what the panel
 * buttons call.
 */

import { ChannelType, PermissionFlagsBits } from 'discord.js';
import { defineCommand, type Context } from '../../../core/command.js';
import { UsageError } from '../../../core/errors.js';
import { buildInterface } from '../interface.js';
import { db, invalidateGuild, schema } from '../../../db/index.js';
import { forget, key } from '../../../core/cache.js';

const engine = (ctx: Context) => ctx.client.voicemaster;

/* --------------------------------------------------------------- ,vc … */

export const voice = defineCommand({
  name: 'voice',
  aliases: ['vc'],
  module: 'VoiceMaster',
  description: 'Control your temporary voice channel',
  botPermissions: [PermissionFlagsBits.ManageChannels, PermissionFlagsBits.MoveMembers],
  cooldown: { uses: 5, windowMs: 10_000 },
  subcommands: {
    lock: {
      name: 'lock', aliases: ['vclock'], module: 'VoiceMaster',
      description: 'Stop anyone new joining your channel',
      execute: async (ctx) => {
        const channel = await engine(ctx).setLock(ctx.member, true);
        return ctx.ok(`${channel} is locked.`);
      },
    },
    unlock: {
      name: 'unlock', aliases: ['vcunlock'], module: 'VoiceMaster',
      description: 'Let everyone join again',
      execute: async (ctx) => {
        const channel = await engine(ctx).setLock(ctx.member, false);
        return ctx.ok(`${channel} is open.`);
      },
    },
    hide: {
      name: 'hide', module: 'VoiceMaster',
      description: 'Remove your channel from the channel list',
      execute: async (ctx) => {
        await engine(ctx).setHidden(ctx.member, true);
        return ctx.ok('Your channel is hidden.');
      },
    },
    unhide: {
      name: 'unhide', module: 'VoiceMaster',
      description: 'Show your channel in the list again',
      execute: async (ctx) => {
        await engine(ctx).setHidden(ctx.member, false);
        return ctx.ok('Your channel is visible.');
      },
    },
    ghost: {
      name: 'ghost', aliases: ['vcg'], module: 'VoiceMaster',
      description: 'Lock and hide in one step',
      execute: async (ctx) => {
        await engine(ctx).setGhost(ctx.member, true);
        return ctx.ok('Your channel is locked and hidden.');
      },
    },
    unghost: {
      name: 'unghost', module: 'VoiceMaster',
      description: 'Undo ghost mode',
      execute: async (ctx) => {
        await engine(ctx).setGhost(ctx.member, false);
        return ctx.ok('Your channel is open and visible.');
      },
    },
    permit: {
      name: 'permit', aliases: ['allow', 'p'], module: 'VoiceMaster',
      description: 'Let one person into your locked channel',
      usage: 'permit <user>',
      execute: async (ctx) => {
        const target = (await ctx.resolveMember(0))!;
        await engine(ctx).permit(ctx.member, target);
        return ctx.ok(`${target} can join your channel.`);
      },
    },
    reject: {
      name: 'reject', aliases: ['deny', 'r'], module: 'VoiceMaster',
      description: 'Remove someone and block them from rejoining',
      usage: 'reject <user>',
      execute: async (ctx) => {
        const target = (await ctx.resolveMember(0))!;
        await engine(ctx).reject(ctx.member, target);
        return ctx.ok(`${target} was removed and blocked.`);
      },
    },
    trust: {
      name: 'trust', module: 'VoiceMaster',
      description: 'Give someone co-owner rights',
      usage: 'trust <user>',
      execute: async (ctx) => {
        const target = (await ctx.resolveMember(0))!;
        await engine(ctx).setTrust(ctx.member, target, true);
        return ctx.ok(`${target} can now manage your channel.`);
      },
    },
    untrust: {
      name: 'untrust', module: 'VoiceMaster',
      description: 'Take back co-owner rights',
      usage: 'untrust <user>',
      execute: async (ctx) => {
        const target = (await ctx.resolveMember(0))!;
        await engine(ctx).setTrust(ctx.member, target, false);
        return ctx.ok(`${target} can no longer manage your channel.`);
      },
    },
    name: {
      name: 'name', aliases: ['rename', 'n'], module: 'VoiceMaster',
      description: 'Rename your channel',
      usage: 'name <text>',
      execute: async (ctx) => {
        const wanted = ctx.rest();
        if (!wanted) throw new UsageError('Give the channel a new name.');
        const channel = await engine(ctx).rename(ctx.member, wanted);
        return ctx.ok(`Renamed to **${channel.name}**.`);
      },
    },
    limit: {
      name: 'limit', aliases: ['l'], module: 'VoiceMaster',
      description: 'Set how many people can be in the channel',
      usage: 'limit <0-99>',
      execute: async (ctx) => {
        const limit = Number.parseInt(ctx.args[0] ?? '', 10);
        if (Number.isNaN(limit)) throw new UsageError('Give a number between 0 and 99.');
        await engine(ctx).setLimit(ctx.member, limit);
        return ctx.ok(limit === 0 ? 'User limit removed.' : `User limit set to ${limit}.`);
      },
    },
    bitrate: {
      name: 'bitrate', module: 'VoiceMaster',
      description: 'Change audio quality',
      usage: 'bitrate <kbps>',
      execute: async (ctx) => {
        const kbps = Number.parseInt(ctx.args[0] ?? '', 10);
        if (Number.isNaN(kbps)) throw new UsageError('Give a bitrate in kbps, such as 96.');
        await engine(ctx).setBitrate(ctx.member, kbps);
        return ctx.ok(`Bitrate set to ${kbps} kbps.`);
      },
    },
    region: {
      name: 'region', module: 'VoiceMaster',
      description: 'Move the channel to another voice region',
      usage: 'region <region|auto>',
      execute: async (ctx) => {
        const wanted = ctx.args[0]?.toLowerCase();
        const region = !wanted || wanted === 'auto' ? null : wanted;
        await engine(ctx).setRegion(ctx.member, region);
        return ctx.ok(region ? `Region set to \`${region}\`.` : 'Region set back to automatic.');
      },
    },
    claim: {
      name: 'claim', module: 'VoiceMaster',
      description: 'Take over a channel whose owner left',
      execute: async (ctx) => {
        const channel = await engine(ctx).claim(ctx.member);
        return ctx.ok(`You own ${channel} now.`);
      },
    },
    transfer: {
      name: 'transfer', module: 'VoiceMaster',
      description: 'Hand your channel to someone in it',
      usage: 'transfer <user>',
      execute: async (ctx) => {
        const target = (await ctx.resolveMember(0))!;
        await engine(ctx).transfer(ctx.member, target);
        return ctx.ok(`${target} now owns the channel.`);
      },
    },
    info: {
      name: 'info', module: 'VoiceMaster',
      description: 'Show who owns the channel and how it is configured',
      execute: async (ctx) => {
        const { channel, record } = await engine(ctx).requireControl(ctx.member);
        return ctx.send({
          title: channel.name,
          fields: [
            { name: 'Owner', value: `<@${record.ownerId}>`, inline: true },
            { name: 'Members', value: `${channel.members.size}`, inline: true },
            { name: 'Bitrate', value: `${channel.bitrate / 1000} kbps`, inline: true },
          ],
        });
      },
    },
  },
});

/* ------------------------------------------------------- ,voicemaster … */

export const voicemaster = defineCommand({
  name: 'voicemaster',
  aliases: ['vm'],
  module: 'VoiceMaster',
  description: 'Set up and configure temporary voice channels',
  userPermissions: [PermissionFlagsBits.ManageGuild],
  botPermissions: [PermissionFlagsBits.ManageChannels],
  subcommands: {
    setup: {
      name: 'setup', module: 'VoiceMaster',
      description: 'Create the join-to-create channel and control panel',
      execute: async (ctx) => {
        const existing = await engine(ctx).getConfig(ctx.guild.id);
        if (existing) {
          throw new UsageError(
            'VoiceMaster is already set up here.',
            `Run \`${ctx.guildConfig.prefix}voicemaster reset\` first if you want to rebuild it.`,
          );
        }

        const category = await ctx.guild.channels.create({
          name: 'Voice channels',
          type: ChannelType.GuildCategory,
        });

        const generator = await ctx.guild.channels.create({
          name: 'Join to create',
          type: ChannelType.GuildVoice,
          parent: category,
        });

        const panel = await buildInterface(ctx.guild.id);
        const interfaceChannel = await ctx.guild.channels.create({
          name: 'voice-controls',
          type: ChannelType.GuildText,
          parent: category,
        });
        const panelMessage = await interfaceChannel.send(panel);

        await db.insert(schema.vmConfigs).values({
          guildId: ctx.guild.id,
          generatorChannelId: generator.id,
          categoryId: category.id,
          interfaceChannelId: interfaceChannel.id,
          interfaceMessageId: panelMessage.id,
        });
        await forget(key.vmConfig(ctx.guild.id));

        return ctx.ok(`Join ${generator} to get your own channel. Controls are in ${interfaceChannel}.`);
      },
    },
    interface: {
      name: 'interface', aliases: ['panel'], module: 'VoiceMaster',
      description: 'Post the control panel in this channel',
      execute: async (ctx) => {
        const config = await requireConfig(ctx);
        const message = await ctx.channel.send(await buildInterface(ctx.guild.id));
        await db.update(schema.vmConfigs)
          .set({ interfaceChannelId: ctx.channel.id, interfaceMessageId: message.id })
          .where(eqGuild(config.guildId));
        await forget(key.vmConfig(ctx.guild.id));
        return ctx.ok('Control panel posted.');
      },
    },
    defaultname: {
      name: 'defaultname', aliases: ['name'], module: 'VoiceMaster',
      description: 'Set the naming template for new channels',
      usage: 'defaultname <template>',
      examples: ["voicemaster defaultname {user}'s room"],
      execute: async (ctx) => {
        const template = ctx.rest();
        if (!template) throw new UsageError('Give a template. Variables: {user}, {user.name}, {count}, {game}.');
        const config = await requireConfig(ctx);
        await db.update(schema.vmConfigs).set({ nameTemplate: template.slice(0, 64) })
          .where(eqGuild(config.guildId));
        await forget(key.vmConfig(ctx.guild.id));
        return ctx.ok(`New channels will be called **${template}**.`);
      },
    },
    defaultlimit: {
      name: 'defaultlimit', aliases: ['limit'], module: 'VoiceMaster',
      description: 'Set the default user limit for new channels',
      usage: 'defaultlimit <0-99>',
      execute: async (ctx) => {
        const limit = Number.parseInt(ctx.args[0] ?? '', 10);
        if (Number.isNaN(limit) || limit < 0 || limit > 99) {
          throw new UsageError('Give a number between 0 and 99.');
        }
        const config = await requireConfig(ctx);
        await db.update(schema.vmConfigs).set({ defaultLimit: limit }).where(eqGuild(config.guildId));
        await forget(key.vmConfig(ctx.guild.id));
        return ctx.ok(`New channels start with a limit of ${limit || 'none'}.`);
      },
    },
    reset: {
      name: 'reset', aliases: ['disable'], module: 'VoiceMaster',
      description: 'Delete the setup and every active temporary channel',
      execute: async (ctx) => {
        const removed = await engine(ctx).resetGuild(ctx.guild);
        await invalidateGuild(ctx.guild.id);
        return ctx.ok(`VoiceMaster is off. ${removed} temporary channel${removed === 1 ? '' : 's'} removed.`);
      },
    },
  },
});

async function requireConfig(ctx: Context) {
  const config = await ctx.client.voicemaster.getConfig(ctx.guild.id);
  if (!config) {
    throw new UsageError(
      'VoiceMaster is not set up here.',
      `Run \`${ctx.guildConfig.prefix}voicemaster setup\` first.`,
    );
  }
  return config;
}

// Small local helper so the query reads cleanly above.
import { eq } from 'drizzle-orm';
const eqGuild = (guildId: string) => eq(schema.vmConfigs.guildId, guildId);
