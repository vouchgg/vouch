/**
 * The VoiceMaster control panel.
 *
 * Buttons are stateless: the custom id carries an action name and nothing
 * else. Ownership is read from the database at click time, so a panel posted
 * six months ago still works after any number of ownership transfers.
 */

import {
  ButtonStyle, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle,
  UserSelectMenuBuilder, ActionRowBuilder,
  type ButtonInteraction, type ModalSubmitInteraction, type UserSelectMenuInteraction,
} from 'discord.js';
import { cid, type BountyClient, type ComponentHandler } from '../../core/client.js';
import { buildEmbed, button, buttonRow, PALETTE } from '../../core/branding.js';
import { UsageError } from '../../core/errors.js';
import { getGuildConfig } from '../../db/index.js';
import type { VoiceMasterEngine } from './engine.js';

const NS = 'vm';

/* ------------------------------------------------------------ the panel */

/**
 * Icon-only buttons with a legend in the embed. Labels would push this to
 * three crowded rows on mobile, and the legend has to exist anyway — an
 * unlabelled row of icons is unusable without one.
 *
 * Swap ICONS for your own application emoji (`<:name:id>`) once you have
 * them uploaded; the ids are the only thing that needs to change.
 */
const ICONS = {
  lock: '🔒', unlock: '🔓', ghost: '👻', reveal: '👁️', claim: '🎤',
  rename: '✏️', limit: '👥', permit: '➕', reject: '➖',
  transfer: '🔀', info: 'ℹ️',
} as const;

const LEGEND: Array<[keyof typeof ICONS, string, string]> = [
  ['lock', 'Lock', 'stop anyone new joining'],
  ['unlock', 'Unlock', 'open it back up'],
  ['ghost', 'Ghost', 'lock and hide at once'],
  ['reveal', 'Reveal', 'show it in the channel list again'],
  ['claim', 'Claim', 'take a channel whose owner left'],
  ['rename', 'Rename', 'change the channel name'],
  ['limit', 'Limit', 'set how many people fit'],
  ['permit', 'Permit', 'let one person in'],
  ['reject', 'Reject', 'remove someone and block them'],
  ['transfer', 'Transfer', 'hand the channel to someone in it'],
  ['info', 'Info', 'who owns it and how it is set up'],
];

export async function buildInterface(guildId: string) {
  const guildConfig = await getGuildConfig(guildId);

  const embed = buildEmbed({ guildConfig }, {
    title: 'Voice controls',
    description:
      'These buttons act on the temporary voice channel you are in. The owner ' +
      'and anyone they trust can use them.',
    fields: [{
      name: 'Button usage',
      value: LEGEND.map(([icon, name, what]) =>
        `${ICONS[icon]} — \`${name}\` ${what}`).join('\n'),
    }],
  });

  const order: Array<keyof typeof ICONS> = [
    'lock', 'unlock', 'ghost', 'reveal', 'claim',
    'rename', 'limit', 'permit', 'reject', 'transfer',
    'info',
  ];

  const rows = [];
  for (let i = 0; i < order.length; i += 5) {
    rows.push(buttonRow(...order.slice(i, i + 5).map((action) =>
      button({ id: cid.build(NS, action), emoji: ICONS[action] }))));
  }

  return { embeds: [embed], components: rows };
}

/* ---------------------------------------------------------- the handler */

export function registerVoiceInterface(client: BountyClient, engine: VoiceMasterEngine): void {
  const handler: ComponentHandler = {
    namespace: NS,
    async execute(interaction, [action, ...args]) {
      if (interaction.isModalSubmit()) {
        await handleModal(interaction as ModalSubmitInteraction<'cached'>, action, engine);
        return;
      }
      if (interaction.isUserSelectMenu()) {
        await handleUserSelect(interaction as UserSelectMenuInteraction<'cached'>, args[0] ?? action, engine);
        return;
      }
      await handleButton(interaction as ButtonInteraction<'cached'>, action, engine);
    },
  };

  client.registerComponent(handler);
}

async function handleButton(
  interaction: ButtonInteraction<'cached'>,
  action: string,
  engine: VoiceMasterEngine,
): Promise<void> {
  const member = interaction.member;

  // Modals and select menus must be the first response — they cannot follow
  // a defer, so they are handled before the acknowledgement below.
  switch (action) {
    case 'rename':
      await interaction.showModal(renameModal());
      return;
    case 'limit':
      await interaction.showModal(limitModal());
      return;
    case 'permit':
    case 'reject':
    case 'transfer':
      await engine.requireControl(member); // Fail before showing a useless picker.
      await interaction.reply({
        content: pickerPrompt(action),
        components: [userPicker(action)],
        flags: MessageFlags.Ephemeral,
      });
      return;
  }

  // Everything below writes to Discord, so acknowledge inside the 3s window
  // and report the outcome as an ephemeral follow-up.
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  switch (action) {
    case 'lock':
      await engine.setLock(member, true);
      await done(interaction, 'Channel locked. Nobody new can join.');
      return;
    case 'unlock':
      await engine.setLock(member, false);
      await done(interaction, 'Channel unlocked.');
      return;
    case 'hide':
      await engine.setHidden(member, true);
      await done(interaction, 'Channel hidden from the channel list.');
      return;
    case 'unhide':
    case 'reveal':
      await engine.setHidden(member, false);
      await done(interaction, 'Channel is visible again.');
      return;
    case 'ghost':
      await engine.setGhost(member, true);
      await done(interaction, 'Channel locked and hidden.');
      return;
    case 'claim': {
      const channel = await engine.claim(member);
      await done(interaction, `You now own ${channel}.`);
      return;
    }
    case 'info': {
      const { channel, record } = await engine.requireControl(member);
      const guildConfig = await getGuildConfig(interaction.guildId);
      await interaction.editReply({
        embeds: [buildEmbed({ guildConfig }, {
          title: channel.name,
          color: record.locked ? PALETTE.lilac : undefined,
          fields: [
            { name: 'Owner', value: `<@${record.ownerId}>`, inline: true },
            { name: 'Members', value: `${channel.members.size}${channel.userLimit ? ` / ${channel.userLimit}` : ''}`, inline: true },
            { name: 'Bitrate', value: `${channel.bitrate / 1000} kbps`, inline: true },
            { name: 'State', value: stateLabel(record.locked, record.hidden), inline: true },
            { name: 'Region', value: channel.rtcRegion ?? 'Automatic', inline: true },
            {
              name: 'Trusted',
              value: record.trustedIds.length
                ? record.trustedIds.map((id) => `<@${id}>`).join(' ')
                : 'Nobody yet',
              inline: false,
            },
          ],
        })],
      });
      return;
    }
    default:
      throw new UsageError('That control is not recognised.');
  }
}

async function handleModal(
  interaction: ModalSubmitInteraction<'cached'>,
  action: string,
  engine: VoiceMasterEngine,
): Promise<void> {
  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  if (action === 'rename-modal') {
    const value = interaction.fields.getTextInputValue('name');
    const channel = await engine.rename(interaction.member, value);
    await done(interaction, `Renamed to **${channel.name}**.`);
    return;
  }

  if (action === 'limit-modal') {
    const raw = interaction.fields.getTextInputValue('limit').trim();
    const parsed = Number.parseInt(raw, 10);
    if (Number.isNaN(parsed)) throw new UsageError('Enter a whole number between 0 and 99.');
    await engine.setLimit(interaction.member, parsed);
    await done(interaction, parsed === 0 ? 'User limit removed.' : `User limit set to ${parsed}.`);
    return;
  }

  throw new UsageError('That form is not recognised.');
}

async function handleUserSelect(
  interaction: UserSelectMenuInteraction<'cached'>,
  action: string,
  engine: VoiceMasterEngine,
): Promise<void> {
  await interaction.deferUpdate();

  const targetId = interaction.values[0];
  const target = await interaction.guild.members.fetch(targetId).catch(() => null);
  if (!target) throw new UsageError('That user is not in this server any more.');

  switch (action) {
    case 'permit':
      await engine.permit(interaction.member, target);
      await interaction.editReply({ content: `${target} can now join your channel.`, components: [] });
      return;
    case 'reject':
      await engine.reject(interaction.member, target);
      await interaction.editReply({ content: `${target} was removed and blocked.`, components: [] });
      return;
    case 'transfer':
      await engine.transfer(interaction.member, target);
      await interaction.editReply({ content: `${target} now owns the channel.`, components: [] });
      return;
    default:
      throw new UsageError('That picker is not recognised.');
  }
}

/* ------------------------------------------------------------ builders */

const renameModal = () =>
  new ModalBuilder()
    .setCustomId(cid.build(NS, 'rename-modal'))
    .setTitle('Rename your channel')
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('name')
          .setLabel('New channel name')
          .setStyle(TextInputStyle.Short)
          .setMaxLength(100)
          .setRequired(true),
      ),
    );

const limitModal = () =>
  new ModalBuilder()
    .setCustomId(cid.build(NS, 'limit-modal'))
    .setTitle('Set a user limit')
    .addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('limit')
          .setLabel('How many people, 0 for unlimited')
          .setStyle(TextInputStyle.Short)
          .setMaxLength(2)
          .setRequired(true),
      ),
    );

const userPicker = (action: string) =>
  new ActionRowBuilder<UserSelectMenuBuilder>().addComponents(
    new UserSelectMenuBuilder()
      .setCustomId(cid.build(NS, 'pick', action))
      .setPlaceholder(action === 'transfer' ? 'Choose the new owner' : 'Choose a member')
      .setMaxValues(1),
  );

const pickerPrompt = (action: string) =>
  action === 'transfer' ? 'Who should take over the channel?'
    : action === 'permit' ? 'Who should be allowed in?'
      : 'Who should be removed?';

const stateLabel = (locked: boolean, hidden: boolean) =>
  locked && hidden ? 'Ghosted' : locked ? 'Locked' : hidden ? 'Hidden' : 'Open';

async function done(
  interaction: ButtonInteraction<'cached'> | ModalSubmitInteraction<'cached'>,
  message: string,
): Promise<void> {
  await interaction.editReply({ content: message });
}
