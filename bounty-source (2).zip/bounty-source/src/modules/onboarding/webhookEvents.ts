/**
 * Account installs.
 *
 * When someone adds Bounty to their account instead of a server, no gateway
 * event fires — Discord only tells you over HTTP, through the Webhook Events
 * endpoint you set in the developer portal (Bot → Webhooks → Events URL, with
 * APPLICATION_AUTHORIZED subscribed).
 *
 * Two rules Discord enforces on that endpoint:
 *  1. Every request is signed. An unsigned or badly signed request must get a
 *     401, and Discord tests this before it will accept the URL at all.
 *  2. You have 3 seconds to respond. So the response goes out first and the
 *     DM is sent afterwards, off the request.
 */

import { createServer, type IncomingMessage, type ServerResponse } from 'node:http';
import { createPublicKey, verify as verifySignature } from 'node:crypto';
import type { BountyClient } from '../../core/client.js';
import { userWelcome } from './welcome.js';
import { logger } from '../../core/logger.js';

/** Discord sends the raw 32-byte Ed25519 key as hex; node wants SPKI DER. */
const SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');

const WEBHOOK_TYPE = { PING: 0, EVENT: 1 } as const;
const INTEGRATION_TYPE = { GUILD: 0, USER: 1 } as const;

interface WebhookEventBody {
  type: number;
  event?: {
    type: string;
    timestamp: string;
    data?: {
      integration_type?: number;
      user?: { id: string };
      scopes?: string[];
      guild?: { id: string };
    };
  };
}

export function startWebhookEvents(client: BountyClient): void {
  const publicKeyHex = process.env.DISCORD_PUBLIC_KEY;
  const port = Number(process.env.WEBHOOK_PORT ?? 0);

  if (!port) {
    logger.warn('http server disabled — set WEBHOOK_PORT to serve /shards and account-install greetings');
    return;
  }

  const publicKey = publicKeyHex
    ? createPublicKey({
      key: Buffer.concat([SPKI_PREFIX, Buffer.from(publicKeyHex, 'hex')]),
      format: 'der',
      type: 'spki',
    })
    : null;

  if (!publicKey) {
    logger.warn('DISCORD_PUBLIC_KEY not set — account installs will not be greeted');
  }

  const server = createServer((req, res) => {
    // The status page reads this. Public on purpose: it is counts, nothing else.
    if (req.method === 'GET' && req.url?.startsWith('/shards')) {
      serveShards(client, res);
      return;
    }

    if (!publicKey) { res.writeHead(404).end(); return; }

    void handle(client, publicKey, req, res).catch((err) => {
      logger.error({ err }, 'webhook handler failed');
      if (!res.writableEnded) res.writeHead(500).end();
    });
  });

  server.listen(port, () => logger.info({ port }, 'http server listening'));
}

/**
 * Per-shard health for the status page. Numbers come from the running client,
 * so a shard that is actually down reports as down rather than as missing.
 */
function serveShards(client: BountyClient, res: ServerResponse): void {
  const guilds = [...client.guilds.cache.values()];

  const shards = [...(client.ws.shards.values() ?? [])].map((shard) => {
    const mine = guilds.filter((g) => g.shardId === shard.id);
    return {
      id: shard.id,
      status: shard.status === 0 ? 'operational' : 'degraded',
      latency: Math.round(shard.ping),
      guilds: mine.length,
      users: mine.reduce((total, guild) => total + guild.memberCount, 0),
      uptimeMs: client.uptime ?? 0,
    };
  });

  const body = JSON.stringify({
    updatedAt: new Date().toISOString(),
    totals: {
      shards: shards.length,
      guilds: guilds.length,
      users: guilds.reduce((total, guild) => total + guild.memberCount, 0),
    },
    shards,
  });

  res.writeHead(200, {
    'content-type': 'application/json',
    // The status page is served from another origin.
    'access-control-allow-origin': '*',
    'cache-control': 'public, max-age=10',
  });
  res.end(body);
}

async function handle(
  client: BountyClient,
  publicKey: ReturnType<typeof createPublicKey>,
  req: IncomingMessage,
  res: ServerResponse,
): Promise<void> {
  if (req.method !== 'POST') { res.writeHead(405).end(); return; }

  const raw = await readBody(req);
  const signature = req.headers['x-signature-ed25519'];
  const timestamp = req.headers['x-signature-timestamp'];

  if (typeof signature !== 'string' || typeof timestamp !== 'string') {
    res.writeHead(401).end('missing signature');
    return;
  }

  const valid = verifySignature(
    null,
    Buffer.concat([Buffer.from(timestamp), raw]),
    publicKey,
    Buffer.from(signature, 'hex'),
  );
  if (!valid) { res.writeHead(401).end('invalid signature'); return; }

  let body: WebhookEventBody;
  try { body = JSON.parse(raw.toString('utf8')) as WebhookEventBody; }
  catch { res.writeHead(400).end('bad json'); return; }

  // Discord's readiness probe.
  if (body.type === WEBHOOK_TYPE.PING) { res.writeHead(204).end(); return; }

  // Acknowledge now. Anything slow happens after this line.
  res.writeHead(204).end();

  if (body.type !== WEBHOOK_TYPE.EVENT) return;
  if (body.event?.type !== 'APPLICATION_AUTHORIZED') return;

  const data = body.event.data ?? {};
  // Server installs are already handled by the gateway's guildCreate event.
  if (data.integration_type !== INTEGRATION_TYPE.USER) return;

  const userId = data.user?.id;
  if (!userId) return;

  await greet(client, userId);
}

async function greet(client: BountyClient, userId: string): Promise<void> {
  const user = await client.users.fetch(userId).catch(() => null);
  if (!user) return;

  const sent = await user.send(userWelcome(client, user)).then(() => true).catch(() => false);

  // Closed DMs are the normal case, not an error worth alarming on. The
  // greeting reappears the first time they use a command instead.
  logger.info({ userId, sent }, sent ? 'account install greeted' : 'account install DM blocked');
}

function readBody(req: IncomingMessage): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    let size = 0;
    req.on('data', (chunk: Buffer) => {
      size += chunk.length;
      // A signed endpoint is still a public endpoint.
      if (size > 64 * 1024) { req.destroy(); reject(new Error('body too large')); return; }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
