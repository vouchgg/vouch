/**
 * The message Bounty sends the moment it is added, to a server or to an
 * account.
 *
 * One payload builder for both paths, because the two entry points arrive
 * through completely different Discord plumbing: a server install fires the
 * `guildCreate` gateway event, an account install only shows up as an
 * `APPLICATION_AUTHORIZED` webhook event over HTTP. Same greeting either way.
 */

import {
  ButtonStyle, OAuth2Scopes, PermissionsBitField,
  type Client, type Guild, type MessageCreateOptions, type User,
} from 'discord.js';
import { buildEmbed, button, buttonRow, PALETTE } from '../../core/branding.js';
import { cid } from '../../core/client.js';

export const WELCOME_NS = 'welcome';

/** Upload `bounty-banner.png` somewhere permanent and point this at it. */
const BANNER_URL = process.env.BRAND_BANNER_URL;
const WEBSITE_URL = process.env.WEBSITE_URL ?? 'https://bounty.lol';
const SUPPORT_URL = process.env.SUPPORT_INVITE_URL ?? 'https://discord.gg/bounty';
const DOCS_URL = process.env.DOCS_URL ?? 'https://bounty.lol/commands';

/** Everything Bounty needs to run every module without asking twice. */
const REQUIRED_PERMISSIONS = new PermissionsBitField([
  'ViewChannel', 'SendMessages', 'EmbedLinks', 'AttachFiles', 'ReadMessageHistory',
  'AddReactions', 'UseExternalEmojis', 'ManageMessages', 'ManageChannels',
  'ManageRoles', 'MoveMembers', 'MuteMembers', 'DeafenMembers',
  'KickMembers', 'BanMembers', 'ModerateMembers', 'ManageNicknames',
  'CreatePublicThreads', 'ManageThreads',
]);

export function inviteUrl(client: Client): string {
  return client.generateInvite({
    scopes: [OAuth2Scopes.Bot, OAuth2Scopes.ApplicationsCommands],
    permissions: REQUIRED_PERMISSIONS,
  });
}

/* --------------------------------------------------------- server install */

export function guildWelcome(client: Client, guild: Guild, prefix: string): MessageCreateOptions {
  const embed = buildEmbed({}, {
    color: PALETTE.violet,
    title: 'Thanks for adding Bounty',
    description:
      `Every command starts with \`${prefix}\`. Change it any time with ` +
      `\`${prefix}prefix <new>\`, or just ping <@${client.user!.id}> if you forget it.`,
    fields: [
      {
        name: 'Set these up first',
        value:
          `\`${prefix}voicemaster setup\` — join-to-create voice channels with a control panel\n` +
          `\`${prefix}ticket setup\` — a ticket panel with dropdown topics\n` +
          `\`${prefix}welcome setup\` — join cards for new members`,
      },
      {
        name: 'Try these right now',
        value:
          `\`${prefix}avatar\` · \`${prefix}userinfo\` · \`${prefix}spotify\`\n` +
          `\`${prefix}gstart 24h 1 Nitro\` · \`${prefix}purge 50\` · \`${prefix}snipe\``,
      },
      {
        name: 'Make it yours',
        value:
          `\`${prefix}embed color <hex>\` recolours every embed Bounty sends.\n` +
          `\`${prefix}alias add avh avatarhistory\` makes your own shortcuts.`,
      },
    ],
    footer: 'Run help to see all 120+ commands',
  });

  if (BANNER_URL) embed.setImage(BANNER_URL);

  return {
    embeds: [embed],
    components: [
      buttonRow(
        button({ id: cid.build(WELCOME_NS, 'quickstart'), label: 'Quick start', style: ButtonStyle.Primary }),
        button({ label: 'Commands', url: DOCS_URL }),
        button({ label: 'Support server', url: SUPPORT_URL }),
        button({ label: 'Website', url: WEBSITE_URL }),
      ),
    ],
  };
}

/* -------------------------------------------------------- account install */

/**
 * Sent by DM when someone adds Bounty to their account rather than a server.
 * The tone shifts because none of the server setup applies to them yet.
 */
export function userWelcome(client: Client, user: User): MessageCreateOptions {
  const embed = buildEmbed({}, {
    color: PALETTE.violet,
    title: `Welcome to Bounty, ${user.username}`,
    description:
      'Bounty is on your account now, so its commands come with you into any ' +
      'server, group chat or DM — even ones the bot is not in.',
    fields: [
      {
        name: 'What you can do anywhere',
        value:
          '`/avatar` — pull anyone\'s avatar in full resolution\n' +
          '`/userinfo` — account age, badges and join date\n' +
          '`/spotify` — what someone is listening to right now\n' +
          '`/fm` — your own Last.fm now playing card',
      },
      {
        name: 'Link your accounts',
        value:
          '`/lastfm set <username>` for scrobbles and charts\n' +
          '`/bio claim <slug>` for your own bounty.lol page',
      },
      {
        name: 'Want the full thing?',
        value:
          'Voice channels, tickets, giveaways and moderation need Bounty in the ' +
          'server itself. Add it below and run `,voicemaster setup`.',
      },
    ],
    footer: 'Only you can see Bounty responses in servers it has not joined',
  });

  if (BANNER_URL) embed.setImage(BANNER_URL);

  return {
    embeds: [embed],
    components: [
      buttonRow(
        button({ label: 'Add to a server', url: inviteUrl(client) }),
        button({ label: 'Commands', url: DOCS_URL }),
        button({ label: 'Support server', url: SUPPORT_URL }),
      ),
    ],
  };
}

/* ------------------------------------------------------------ quick start */

/** The ephemeral shown by the Quick start button, so the channel stays clean. */
export function quickStart(prefix: string) {
  return buildEmbed({}, {
    color: PALETTE.violet,
    title: 'Three minutes to a working setup',
    description:
      `**1.** \`${prefix}voicemaster setup\`\n` +
      'Creates a join-to-create channel, a category, and a button panel. Anyone ' +
      'who joins gets their own channel they can lock, hide, rename and hand over.\n\n' +
      `**2.** \`${prefix}ticket setup\`\n` +
      'Posts a dropdown panel. Each topic can have its own category, staff roles ' +
      'and questions, and every close writes an HTML transcript.\n\n' +
      `**3.** \`${prefix}embed color #5B2E9D\`\n` +
      'Sets the accent on every embed Bounty sends here.\n\n' +
      `**4.** \`${prefix}antinuke setup\`\n` +
      'Rate limits channel deletes, role deletes and bot invites before someone ' +
      'with Administrator has a bad day.',
    footer: 'Nothing here is permanent — every setup command has a reset',
  });
}
