/**
 * `,purge …`
 *
 * Every variant is the same operation with a different predicate, so the
 * filters are a table and the fetch/delete/report loop is written once.
 *
 * The two constraints that shape it: Discord will not bulk delete anything
 * older than 14 days, and only 100 messages come back per fetch. So a purge
 * of 1000 is up to ten fetches, filtered, chunked, with the age cut applied
 * before the API can reject the whole batch.
 */

import { PermissionFlagsBits, type Collection, type Message } from 'discord.js';
import { defineCommand, type Command, type Context } from '../../../core/command.js';
import { UsageError } from '../../../core/errors.js';

const TWO_WEEKS = 14 * 86_400_000;
const MAX = 1000;

type Filter = (message: Message, ctx: Context) => boolean;

async function run(ctx: Context, wanted: number, filter: Filter, label: string) {
  if (!Number.isInteger(wanted) || wanted < 1 || wanted > MAX) {
    throw new UsageError(`Give a number between 1 and ${MAX}.`);
  }

  // The command itself goes first, so it never shows up in the count.
  await ctx.message.delete().catch(() => undefined);

  const collected: Message[] = [];
  let before: string | undefined;
  let scanned = 0;

  while (collected.length < wanted && scanned < MAX * 2) {
    const batch: Collection<string, Message> = await ctx.channel.messages
      .fetch({ limit: 100, before })
      .catch(() => null as never);
    if (!batch?.size) break;

    scanned += batch.size;
    before = batch.last()?.id;

    for (const message of batch.values()) {
      if (collected.length >= wanted) break;
      if (Date.now() - message.createdTimestamp > TWO_WEEKS) { scanned = MAX * 2; break; }
      if (message.pinned) continue; // Pinned messages are deliberate. Leave them.
      if (!filter(message, ctx)) continue;
      collected.push(message);
    }
  }

  if (!collected.length) {
    const reply = await ctx.warn(`Nothing matched ${label} in the last two weeks of messages.`);
    setTimeout(() => void reply.delete().catch(() => undefined), 8000).unref();
    return reply;
  }

  let deleted = 0;
  for (let i = 0; i < collected.length; i += 100) {
    const chunk = collected.slice(i, i + 100);
    const removed = await ctx.channel.bulkDelete(chunk, true).catch(() => null);
    deleted += removed?.size ?? 0;
  }

  const reply = await ctx.ok(
    `Deleted **${deleted}** message${deleted === 1 ? '' : 's'}${label ? ` ${label}` : ''}.` +
    (deleted < collected.length ? '\nSome were older than 14 days, which Discord will not bulk delete.' : ''),
  );
  // The confirmation should not become the next thing to clean up.
  setTimeout(() => void reply.delete().catch(() => undefined), 6000).unref();
  return reply;
}

/** Each entry becomes a real subcommand. */
const FILTERS: Array<{
  name: string; aliases?: string[]; description: string; label: string;
  needsArg?: boolean;
  build: (ctx: Context) => Promise<Filter> | Filter;
}> = [
  {
    name: 'bots', aliases: ['bot'], description: 'Delete messages from bots',
    label: 'from bots', build: () => (m) => m.author.bot,
  },
  {
    name: 'humans', aliases: ['people'], description: 'Delete messages from people, not bots',
    label: 'from people', build: () => (m) => !m.author.bot,
  },
  {
    name: 'embeds', description: 'Delete messages containing embeds',
    label: 'with embeds', build: () => (m) => m.embeds.length > 0,
  },
  {
    name: 'images', aliases: ['files', 'attachments'], description: 'Delete messages with attachments',
    label: 'with attachments', build: () => (m) => m.attachments.size > 0,
  },
  {
    name: 'links', aliases: ['urls'], description: 'Delete messages containing links',
    label: 'with links', build: () => (m) => /https?:\/\//i.test(m.content),
  },
  {
    name: 'invites', description: 'Delete messages containing Discord invites',
    label: 'with invites', build: () => (m) => /discord(?:\.gg|app\.com\/invite)\//i.test(m.content),
  },
  {
    name: 'mentions', aliases: ['pings'], description: 'Delete messages that ping someone',
    label: 'with mentions',
    build: () => (m) => m.mentions.users.size > 0 || m.mentions.roles.size > 0 || m.mentions.everyone,
  },
  {
    name: 'stickers', description: 'Delete messages with stickers',
    label: 'with stickers', build: () => (m) => m.stickers.size > 0,
  },
  {
    name: 'reactions', description: 'Delete messages that have reactions',
    label: 'with reactions', build: () => (m) => m.reactions.cache.size > 0,
  },
  {
    name: 'text', aliases: ['plain'], description: 'Delete plain text only, keeping media',
    label: 'that were plain text',
    build: () => (m) => m.attachments.size === 0 && m.embeds.length === 0 && m.stickers.size === 0,
  },
  {
    name: 'emojis', aliases: ['emotes'], description: 'Delete messages containing custom emoji',
    label: 'with custom emoji', build: () => (m) => /<a?:\w+:\d+>/.test(m.content),
  },
  {
    name: 'upper', aliases: ['caps'], description: 'Delete messages shouting in capitals',
    label: 'in capitals',
    build: () => (m) => m.content.length > 6 && m.content === m.content.toUpperCase() && /[A-Z]/.test(m.content),
  },
  {
    name: 'user', aliases: ['from'], description: 'Delete messages from one person',
    label: 'from that member', needsArg: true,
    build: async (ctx) => {
      const user = await ctx.resolveUser(0, { fallbackToAuthor: false });
      // Shift so the amount is read from the next position.
      ctx.args.shift();
      return (m) => m.author.id === user.id;
    },
  },
  {
    name: 'contains', aliases: ['match'], description: 'Delete messages containing a phrase',
    label: 'containing that phrase', needsArg: true,
    build: (ctx) => {
      const needle = ctx.args[0]?.toLowerCase();
      if (!needle) throw new UsageError('Give the text to look for.');
      ctx.args.shift();
      return (m) => m.content.toLowerCase().includes(needle);
    },
  },
  {
    name: 'startswith', aliases: ['starts'], description: 'Delete messages starting with something',
    label: 'starting with that', needsArg: true,
    build: (ctx) => {
      const prefix = ctx.args[0]?.toLowerCase();
      if (!prefix) throw new UsageError('Give the starting text.');
      ctx.args.shift();
      return (m) => m.content.toLowerCase().startsWith(prefix);
    },
  },
  {
    name: 'endswith', aliases: ['ends'], description: 'Delete messages ending with something',
    label: 'ending with that', needsArg: true,
    build: (ctx) => {
      const suffix = ctx.args[0]?.toLowerCase();
      if (!suffix) throw new UsageError('Give the ending text.');
      ctx.args.shift();
      return (m) => m.content.toLowerCase().endsWith(suffix);
    },
  },
];

const subcommands: Record<string, Command> = Object.fromEntries(
  FILTERS.map((filter) => [filter.name, {
    name: filter.name,
    aliases: filter.aliases,
    module: 'Moderation' as const,
    description: filter.description,
    usage: `purge ${filter.name}${filter.needsArg ? ' <value>' : ''} <amount>`,
    execute: async (ctx: Context) => {
      const predicate = await filter.build(ctx);
      const amount = Number.parseInt(ctx.args[0] ?? '100', 10);
      return run(ctx, amount, predicate, filter.label);
    },
  }]),
);

export const purge = defineCommand({
  name: 'purge',
  aliases: ['clear', 'c', 'prune'],
  module: 'Moderation',
  description: 'Delete recent messages',
  usage: 'purge <amount>',
  userPermissions: [PermissionFlagsBits.ManageMessages],
  botPermissions: [PermissionFlagsBits.ManageMessages, PermissionFlagsBits.ReadMessageHistory],
  cooldown: { uses: 3, windowMs: 10_000, scope: 'channel' },
  execute: async (ctx) => {
    const amount = Number.parseInt(ctx.args[0] ?? '', 10);
    if (Number.isNaN(amount)) {
      throw new UsageError(
        'Give the number of messages to delete.',
        `Filters: ${FILTERS.map((f) => f.name).join(', ')}`,
      );
    }
    return run(ctx, amount, () => true, '');
  },
  subcommands: {
    ...subcommands,
    between: {
      name: 'between', module: 'Moderation',
      description: 'Delete everything between two message IDs',
      usage: 'purge between <start_id> <end_id>',
      execute: async (ctx) => {
        const [startId, endId] = ctx.args;
        if (!startId || !endId) throw new UsageError('Give two message IDs.');
        const low = BigInt(startId) < BigInt(endId) ? startId : endId;
        const high = low === startId ? endId : startId;
        return run(ctx, MAX, (m) => BigInt(m.id) > BigInt(low) && BigInt(m.id) < BigInt(high), 'in that range');
      },
    },
    after: {
      name: 'after', module: 'Moderation',
      description: 'Delete everything sent after a message',
      usage: 'purge after <message_id>',
      execute: async (ctx) => {
        const id = ctx.args[0];
        if (!id || !/^\d{17,20}$/.test(id)) throw new UsageError('Give a message ID.');
        return run(ctx, MAX, (m) => BigInt(m.id) > BigInt(id), 'after that message');
      },
    },
  },
});
