/**
 * Moderation.
 *
 * Every punishment writes a numbered case, DMs the target before the action
 * lands (you cannot DM someone you just banned), and runs the hierarchy check
 * from middleware rather than repeating it per command.
 */

import { PermissionFlagsBits, type GuildMember } from 'discord.js';
import { and, desc, eq, sql } from 'drizzle-orm';
import { defineCommand, parseDuration, type Command, type Context } from '../../../core/command.js';
import { assertHierarchy } from '../../../core/middleware.js';
import { NotFoundError, UsageError } from '../../../core/errors.js';
import { db, schema } from '../../../db/index.js';
import { humanDuration, ts } from '../../../core/branding.js';

type CaseKind = typeof schema.caseKind.enumValues[number];

/** Allocates the next per-guild case number without a race. */
async function openCase(ctx: Context, kind: CaseKind, target: string, opts: {
  reason?: string | null; expiresAt?: Date | null; restoreRoleIds?: string[];
} = {}) {
  const [config] = await db.insert(schema.guildModeration)
    .values({ guildId: ctx.guild.id, nextCaseNumber: 2 })
    .onConflictDoUpdate({
      target: schema.guildModeration.guildId,
      set: { nextCaseNumber: sql`${schema.guildModeration.nextCaseNumber} + 1` },
    })
    .returning();

  const caseNumber = (config?.nextCaseNumber ?? 2) - 1;

  const [row] = await db.insert(schema.modCases).values({
    guildId: ctx.guild.id,
    caseNumber,
    kind,
    targetId: target,
    moderatorId: ctx.author.id,
    reason: opts.reason ?? null,
    expiresAt: opts.expiresAt ?? null,
    restoreRoleIds: opts.restoreRoleIds ?? [],
    active: true,
  }).returning();

  return row;
}

/** Tells someone why, before the action removes our ability to. */
async function notify(member: GuildMember, ctx: Context, action: string, reason: string | null, duration?: string) {
  const [config] = await db.select().from(schema.guildModeration)
    .where(eq(schema.guildModeration.guildId, ctx.guild.id)).limit(1);
  if (config && !config.dmOnPunish) return;

  await member.send({
    embeds: [ctx.embed({
      tone: 'danger',
      title: `You were ${action} in ${ctx.guild.name}`,
      description: reason ? `Reason: ${reason}` : 'No reason was given.',
      fields: duration ? [{ name: 'Duration', value: duration }] : [],
    })],
  }).catch(() => undefined);
}

const modPerms = (perm: bigint): Partial<Command> => ({
  userPermissions: [perm],
  botPermissions: [perm],
});

export const ban = defineCommand({
  name: 'ban',
  aliases: ['b'],
  module: 'Moderation',
  description: 'Ban a member and log the case',
  usage: 'ban <user> [reason]',
  ...modPerms(PermissionFlagsBits.BanMembers),
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);
    const reason = ctx.rest(1) || null;
    assertHierarchy(ctx.member, member!, 'ban');

    await notify(member!, ctx, 'banned', reason);
    await member!.ban({ reason: `${ctx.author.tag}: ${reason ?? 'no reason'}`, deleteMessageSeconds: 0 });
    const record = await openCase(ctx, 'ban', member!.id, { reason });

    return ctx.ok(`Banned ${member!.user.tag} · case **#${record.caseNumber}**`);
  },
  subcommands: {
    clean: {
      name: 'clean', aliases: ['purge'], module: 'Moderation',
      description: 'Ban and delete their last 7 days of messages',
      usage: 'ban clean <user> [reason]',
      execute: async (ctx) => {
        const member = await ctx.resolveMember(0);
        const reason = ctx.rest(1) || null;
        assertHierarchy(ctx.member, member!, 'ban');
        await notify(member!, ctx, 'banned', reason);
        await member!.ban({ reason: `${ctx.author.tag}: ${reason ?? 'no reason'}`, deleteMessageSeconds: 604_800 });
        const record = await openCase(ctx, 'ban', member!.id, { reason });
        return ctx.ok(`Banned ${member!.user.tag} and cleared 7 days of messages · case **#${record.caseNumber}**`);
      },
    },
  },
});

export const softban = defineCommand({
  name: 'softban',
  aliases: ['sb'],
  module: 'Moderation',
  description: 'Ban then immediately unban, to clear their messages',
  usage: 'softban <user> [reason]',
  ...modPerms(PermissionFlagsBits.BanMembers),
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);
    const reason = ctx.rest(1) || null;
    assertHierarchy(ctx.member, member!, 'softban');

    await notify(member!, ctx, 'removed', reason);
    await member!.ban({ reason: `Softban by ${ctx.author.tag}`, deleteMessageSeconds: 604_800 });
    await ctx.guild.bans.remove(member!.id, 'Softban: immediate unban');
    const record = await openCase(ctx, 'softban', member!.id, { reason });

    return ctx.ok(`Softbanned ${member!.user.tag}. They can rejoin · case **#${record.caseNumber}**`);
  },
});

export const unban = defineCommand({
  name: 'unban',
  aliases: ['ub'],
  module: 'Moderation',
  description: 'Unban someone by ID',
  usage: 'unban <user_id> [reason]',
  ...modPerms(PermissionFlagsBits.BanMembers),
  execute: async (ctx) => {
    const id = ctx.args[0];
    if (!id || !/^\d{17,20}$/.test(id)) throw new UsageError('Give the user ID to unban.');

    const ban = await ctx.guild.bans.fetch(id).catch(() => null);
    if (!ban) throw new NotFoundError(`\`${id}\` is not banned here.`);

    await ctx.guild.bans.remove(id, `${ctx.author.tag}: ${ctx.rest(1) || 'no reason'}`);
    await db.update(schema.modCases).set({ active: false }).where(and(
      eq(schema.modCases.guildId, ctx.guild.id),
      eq(schema.modCases.targetId, id),
      eq(schema.modCases.kind, 'ban'),
    ));
    const record = await openCase(ctx, 'unban', id, { reason: ctx.rest(1) || null });

    return ctx.ok(`Unbanned ${ban.user.tag} · case **#${record.caseNumber}**`);
  },
});

export const kick = defineCommand({
  name: 'kick',
  aliases: ['k'],
  module: 'Moderation',
  description: 'Kick a member',
  usage: 'kick <user> [reason]',
  ...modPerms(PermissionFlagsBits.KickMembers),
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);
    const reason = ctx.rest(1) || null;
    assertHierarchy(ctx.member, member!, 'kick');

    await notify(member!, ctx, 'kicked', reason);
    await member!.kick(`${ctx.author.tag}: ${reason ?? 'no reason'}`);
    const record = await openCase(ctx, 'kick', member!.id, { reason });

    return ctx.ok(`Kicked ${member!.user.tag} · case **#${record.caseNumber}**`);
  },
});

export const timeout = defineCommand({
  name: 'timeout',
  aliases: ['mute', 't'],
  module: 'Moderation',
  description: 'Time a member out',
  usage: 'timeout <user> <duration> [reason]',
  examples: ['timeout @user 10m spamming'],
  ...modPerms(PermissionFlagsBits.ModerateMembers),
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);
    const duration = parseDuration(ctx.args[1] ?? '');
    if (!duration) throw new UsageError('Give a duration like `10m`, `2h` or `7d`.');
    // Discord's own ceiling. Anything longer needs a jail or a ban.
    if (duration > 28 * 86_400_000) throw new UsageError('Discord caps timeouts at 28 days.');

    const reason = ctx.rest(2) || null;
    assertHierarchy(ctx.member, member!, 'time out');

    await notify(member!, ctx, 'timed out', reason, humanDuration(duration));
    await member!.timeout(duration, `${ctx.author.tag}: ${reason ?? 'no reason'}`);
    const record = await openCase(ctx, 'timeout', member!.id, {
      reason, expiresAt: new Date(Date.now() + duration),
    });

    return ctx.ok(`${member} is timed out for ${humanDuration(duration)} · case **#${record.caseNumber}**`);
  },
});

export const untimeout = defineCommand({
  name: 'untimeout',
  aliases: ['unmute'],
  module: 'Moderation',
  description: 'Lift a timeout early',
  usage: 'untimeout <user>',
  ...modPerms(PermissionFlagsBits.ModerateMembers),
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);
    if (!member!.isCommunicationDisabled()) throw new UsageError(`${member} is not timed out.`);

    await member!.timeout(null, `Lifted by ${ctx.author.tag}`);
    await db.update(schema.modCases).set({ active: false }).where(and(
      eq(schema.modCases.guildId, ctx.guild.id),
      eq(schema.modCases.targetId, member!.id),
      eq(schema.modCases.kind, 'timeout'),
    ));
    await openCase(ctx, 'untimeout', member!.id);

    return ctx.ok(`${member} can talk again.`);
  },
});

export const jail = defineCommand({
  name: 'jail',
  aliases: ['j'],
  module: 'Moderation',
  description: 'Strip every role and isolate a member',
  usage: 'jail <user> [duration] [reason]',
  ...modPerms(PermissionFlagsBits.ManageRoles),
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);
    assertHierarchy(ctx.member, member!, 'jail');

    const [config] = await db.select().from(schema.guildModeration)
      .where(eq(schema.guildModeration.guildId, ctx.guild.id)).limit(1);
    if (!config?.jailRoleId) {
      throw new UsageError('Jail is not set up.', `Run \`${ctx.guildConfig.prefix}jail setup\` first.`);
    }

    const jailRole = ctx.guild.roles.cache.get(config.jailRoleId);
    if (!jailRole) throw new UsageError('The jail role was deleted. Run setup again.');

    const maybeDuration = parseDuration(ctx.args[1] ?? '');
    const reason = ctx.rest(maybeDuration ? 2 : 1) || null;

    // Remember what they had, or unjail cannot put it back.
    const restore = member!.roles.cache
      .filter((r) => r.id !== ctx.guild.id && !r.managed && ctx.me.roles.highest.comparePositionTo(r) > 0)
      .map((r) => r.id);

    await notify(member!, ctx, 'jailed', reason, maybeDuration ? humanDuration(maybeDuration) : undefined);
    await member!.roles.set([jailRole.id], `Jailed by ${ctx.author.tag}`);

    const record = await openCase(ctx, 'jail', member!.id, {
      reason,
      restoreRoleIds: restore,
      expiresAt: maybeDuration ? new Date(Date.now() + maybeDuration) : null,
    });

    return ctx.ok(
      `${member} is jailed${maybeDuration ? ` for ${humanDuration(maybeDuration)}` : ''} · ` +
      `case **#${record.caseNumber}** · ${restore.length} roles saved`,
    );
  },
  subcommands: {
    setup: {
      name: 'setup', module: 'Moderation',
      description: 'Create the jail role and channel',
      userPermissions: [PermissionFlagsBits.ManageGuild],
      execute: async (ctx) => {
        const role = await ctx.guild.roles.create({
          name: 'Jailed', color: 0x2b2d31, reason: 'Jail setup',
        });

        const channel = await ctx.guild.channels.create({
          name: 'jail',
          permissionOverwrites: [
            { id: ctx.guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: role.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
          ],
        });

        // Deny the jail role everywhere else, or jail does nothing.
        let secured = 0;
        for (const target of ctx.guild.channels.cache.values()) {
          if (target.id === channel.id || !('permissionOverwrites' in target)) continue;
          const ok = await target.permissionOverwrites.edit(role, {
            ViewChannel: false, SendMessages: false, Connect: false,
          }).then(() => true).catch(() => false);
          if (ok) secured += 1;
        }

        await db.insert(schema.guildModeration)
          .values({ guildId: ctx.guild.id, jailRoleId: role.id, jailChannelId: channel.id })
          .onConflictDoUpdate({
            target: schema.guildModeration.guildId,
            set: { jailRoleId: role.id, jailChannelId: channel.id },
          });

        return ctx.ok(`Jail ready: ${role} and ${channel}, locked out of ${secured} channels.`);
      },
    },
  },
});

export const unjail = defineCommand({
  name: 'unjail',
  aliases: ['uj'],
  module: 'Moderation',
  description: 'Release someone and give their roles back',
  usage: 'unjail <user>',
  ...modPerms(PermissionFlagsBits.ManageRoles),
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);

    const [record] = await db.select().from(schema.modCases).where(and(
      eq(schema.modCases.guildId, ctx.guild.id),
      eq(schema.modCases.targetId, member!.id),
      eq(schema.modCases.kind, 'jail'),
      eq(schema.modCases.active, true),
    )).orderBy(desc(schema.modCases.createdAt)).limit(1);

    if (!record) throw new UsageError(`${member} is not jailed.`);

    const restore = record.restoreRoleIds.filter((id) => ctx.guild.roles.cache.has(id));
    await member!.roles.set(restore, `Unjailed by ${ctx.author.tag}`);
    await db.update(schema.modCases).set({ active: false })
      .where(eq(schema.modCases.id, record.id));
    await openCase(ctx, 'unjail', member!.id);

    return ctx.ok(`${member} is out, with ${restore.length} role${restore.length === 1 ? '' : 's'} restored.`);
  },
});

export const warn = defineCommand({
  name: 'warn',
  aliases: ['w'],
  module: 'Moderation',
  description: 'Warn a member on the record',
  usage: 'warn <user> <reason>',
  userPermissions: [PermissionFlagsBits.ModerateMembers],
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);
    const reason = ctx.rest(1);
    if (!reason) throw new UsageError('A warning needs a reason, or it is not much of a warning.');
    assertHierarchy(ctx.member, member!, 'warn');

    await notify(member!, ctx, 'warned', reason);
    const record = await openCase(ctx, 'warn', member!.id, { reason });

    const [{ total }] = await db
      .select({ total: sql<number>`count(*)` })
      .from(schema.modCases)
      .where(and(
        eq(schema.modCases.guildId, ctx.guild.id),
        eq(schema.modCases.targetId, member!.id),
        eq(schema.modCases.kind, 'warn'),
      ));

    return ctx.ok(`Warned ${member} · case **#${record.caseNumber}** · ${total} warning${Number(total) === 1 ? '' : 's'} total`);
  },
});

export const warnings = defineCommand({
  name: 'warnings',
  aliases: ['warns', 'infractions'],
  module: 'Moderation',
  description: 'List someone\'s warnings',
  usage: 'warnings [user]',
  userPermissions: [PermissionFlagsBits.ModerateMembers],
  execute: async (ctx) => {
    const user = await ctx.resolveUser(0);
    const rows = await db.select().from(schema.modCases).where(and(
      eq(schema.modCases.guildId, ctx.guild.id),
      eq(schema.modCases.targetId, user.id),
      eq(schema.modCases.kind, 'warn'),
    )).orderBy(desc(schema.modCases.createdAt)).limit(10);

    if (!rows.length) return ctx.ok(`${user.username} has a clean record.`);

    return ctx.send({
      title: `${user.username}'s warnings`,
      description: rows.map((r) =>
        `**#${r.caseNumber}** · ${ts(r.createdAt)} · by <@${r.moderatorId}>\n${r.reason ?? 'No reason'}`)
        .join('\n\n'),
    });
  },
});

export const modcase = defineCommand({
  name: 'case',
  aliases: ['modlog', 'cases'],
  module: 'Moderation',
  description: 'Look up a case by number',
  usage: 'case <number>',
  userPermissions: [PermissionFlagsBits.ModerateMembers],
  execute: async (ctx) => {
    const number = Number.parseInt(ctx.args[0] ?? '', 10);
    if (Number.isNaN(number)) throw new UsageError('Give a case number.');

    const [record] = await db.select().from(schema.modCases).where(and(
      eq(schema.modCases.guildId, ctx.guild.id),
      eq(schema.modCases.caseNumber, number),
    )).limit(1);
    if (!record) throw new NotFoundError(`No case **#${number}** in this server.`);

    return ctx.send({
      title: `Case #${record.caseNumber} · ${record.kind}`,
      fields: [
        { name: 'Member', value: `<@${record.targetId}>`, inline: true },
        { name: 'Moderator', value: `<@${record.moderatorId}>`, inline: true },
        { name: 'When', value: ts(record.createdAt), inline: true },
        { name: 'Reason', value: record.reason ?? 'None given' },
        ...(record.expiresAt ? [{ name: 'Expires', value: ts(record.expiresAt), inline: true }] : []),
        { name: 'Status', value: record.active ? 'Active' : 'Lifted', inline: true },
      ],
    });
  },
  subcommands: {
    reason: {
      name: 'reason', aliases: ['edit'], module: 'Moderation',
      description: 'Change the reason on a case',
      usage: 'case reason <number> <reason>',
      execute: async (ctx) => {
        const number = Number.parseInt(ctx.args[0] ?? '', 10);
        const reason = ctx.rest(1);
        if (Number.isNaN(number) || !reason) throw new UsageError('Give a case number then the new reason.');

        const updated = await db.update(schema.modCases).set({ reason })
          .where(and(
            eq(schema.modCases.guildId, ctx.guild.id),
            eq(schema.modCases.caseNumber, number),
          )).returning();
        if (!updated.length) throw new NotFoundError(`No case **#${number}**.`);
        return ctx.ok(`Case **#${number}** updated.`);
      },
    },
    user: {
      name: 'user', aliases: ['history'], module: 'Moderation',
      description: 'Every case against one member',
      usage: 'case user <user>',
      execute: async (ctx) => {
        const user = await ctx.resolveUser(0, { fallbackToAuthor: false });
        const rows = await db.select().from(schema.modCases).where(and(
          eq(schema.modCases.guildId, ctx.guild.id),
          eq(schema.modCases.targetId, user.id),
        )).orderBy(desc(schema.modCases.caseNumber)).limit(12);

        if (!rows.length) return ctx.ok(`${user.username} has no cases.`);
        return ctx.send({
          title: `${user.username}'s record · ${rows.length} case${rows.length === 1 ? '' : 's'}`,
          description: rows.map((r) =>
            `**#${r.caseNumber}** \`${r.kind}\` ${ts(r.createdAt)}${r.active ? '' : ' *(lifted)*'}` +
            `\n${(r.reason ?? 'No reason').slice(0, 100)}`).join('\n\n'),
        });
      },
    },
  },
});

export const slowmode = defineCommand({
  name: 'slowmode',
  aliases: ['sm', 'cooldown'],
  module: 'Moderation',
  description: 'Set the channel slowmode',
  usage: 'slowmode <seconds|off>',
  ...modPerms(PermissionFlagsBits.ManageChannels),
  execute: async (ctx) => {
    const raw = ctx.args[0]?.toLowerCase();
    if (!raw) throw new UsageError('Give a number of seconds, or `off`.');

    const seconds = raw === 'off' ? 0 : (parseDuration(raw) ?? Number.parseInt(raw, 10) * 1000) / 1000;
    if (Number.isNaN(seconds) || seconds < 0 || seconds > 21_600) {
      throw new UsageError('Slowmode goes from 0 to 6 hours.');
    }

    await ctx.channel.edit({ rateLimitPerUser: seconds });
    return ctx.ok(seconds ? `Slowmode set to ${humanDuration(seconds * 1000)}.` : 'Slowmode off.');
  },
});

export const lock = defineCommand({
  name: 'lock',
  aliases: ['lockdown'],
  module: 'Moderation',
  description: 'Stop everyone talking in this channel',
  usage: 'lock [reason]',
  ...modPerms(PermissionFlagsBits.ManageChannels),
  execute: async (ctx) => {
    // Threads inherit their parent's permissions and have none of their own.
    if (ctx.channel.isThread()) throw new UsageError('Lock the parent channel, not the thread.');
    await ctx.channel.permissionOverwrites.edit(ctx.guild.roles.everyone, { SendMessages: false });
    await openCase(ctx, 'lockdown', ctx.channel.id, { reason: ctx.rest() || null });
    return ctx.ok(`${ctx.channel} is locked.${ctx.rest() ? `\n${ctx.rest()}` : ''}`);
  },
  subcommands: {
    all: {
      name: 'all', aliases: ['server'], module: 'Moderation',
      description: 'Lock every text channel at once',
      userPermissions: [PermissionFlagsBits.Administrator],
      execute: async (ctx) => {
        let locked = 0;
        for (const channel of ctx.guild.channels.cache.values()) {
          if (!channel.isTextBased() || channel.isThread()) continue;
          const target = channel as import('discord.js').TextChannel;
          const ok = await target.permissionOverwrites
            .edit(ctx.guild.roles.everyone, { SendMessages: false })
            .then(() => true).catch(() => false);
          if (ok) locked += 1;
        }
        return ctx.ok(`Locked ${locked} channels. Unlock with \`${ctx.guildConfig.prefix}unlock all\`.`);
      },
    },
  },
});

export const unlock = defineCommand({
  name: 'unlock',
  module: 'Moderation',
  description: 'Let people talk here again',
  ...modPerms(PermissionFlagsBits.ManageChannels),
  execute: async (ctx) => {
    if (ctx.channel.isThread()) throw new UsageError('Unlock the parent channel, not the thread.');
    await ctx.channel.permissionOverwrites.edit(ctx.guild.roles.everyone, { SendMessages: null });
    return ctx.ok(`${ctx.channel} is open.`);
  },
  subcommands: {
    all: {
      name: 'all', aliases: ['server'], module: 'Moderation',
      description: 'Unlock every text channel',
      userPermissions: [PermissionFlagsBits.Administrator],
      execute: async (ctx) => {
        let unlocked = 0;
        for (const channel of ctx.guild.channels.cache.values()) {
          if (!channel.isTextBased() || channel.isThread()) continue;
          const target = channel as import('discord.js').TextChannel;
          const ok = await target.permissionOverwrites
            .edit(ctx.guild.roles.everyone, { SendMessages: null })
            .then(() => true).catch(() => false);
          if (ok) unlocked += 1;
        }
        return ctx.ok(`Unlocked ${unlocked} channels.`);
      },
    },
  },
});

export const nickname = defineCommand({
  name: 'nickname',
  aliases: ['nick', 'setnick'],
  module: 'Moderation',
  description: 'Change or clear a member\'s nickname',
  usage: 'nickname <user> [name]',
  ...modPerms(PermissionFlagsBits.ManageNicknames),
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);
    assertHierarchy(ctx.member, member!, 'rename');
    const name = ctx.rest(1);

    await member!.setNickname(name || null, `Set by ${ctx.author.tag}`);
    return ctx.ok(name ? `${member} is now **${name}**.` : `Cleared ${member}'s nickname.`);
  },
});

export const vckick = defineCommand({
  name: 'vckick',
  aliases: ['voicekick', 'disconnect'],
  module: 'Moderation',
  description: 'Disconnect someone from voice',
  usage: 'vckick <user>',
  ...modPerms(PermissionFlagsBits.MoveMembers),
  execute: async (ctx) => {
    const member = await ctx.resolveMember(0);
    if (!member!.voice.channelId) throw new UsageError(`${member} is not in a voice channel.`);
    await member!.voice.disconnect(`Disconnected by ${ctx.author.tag}`);
    return ctx.ok(`Disconnected ${member}.`);
  },
});

export const vcmove = defineCommand({
  name: 'vcmove',
  aliases: ['voicemove', 'vcm'],
  module: 'Moderation',
  description: 'Move everyone from one voice channel to another',
  usage: 'vcmove <from> <to>',
  ...modPerms(PermissionFlagsBits.MoveMembers),
  execute: async (ctx) => {
    const ids = ctx.args.slice(0, 2).map((a) => a.match(/\d{17,20}/)?.[0]);
    const [from, to] = ids.map((id) => id ? ctx.guild.channels.cache.get(id) : undefined);

    if (!from?.isVoiceBased() || !to?.isVoiceBased()) {
      throw new UsageError('Give two voice channels, by ID or mention.');
    }

    let moved = 0;
    for (const member of from.members.values()) {
      const ok = await member.voice.setChannel(to, `Moved by ${ctx.author.tag}`)
        .then(() => true).catch(() => false);
      if (ok) moved += 1;
    }
    return ctx.ok(`Moved ${moved} member${moved === 1 ? '' : 's'} to ${to}.`);
  },
});
