/**
 * `,serverinfo`, `,membercount`, `,joins`, `,growth`, `,counters …`
 *
 * Everything time-based reads the member_events ledger rather than counting
 * members live, because Discord will not tell you who joined yesterday — only
 * who is here now.
 */

import { ChannelType, GuildVerificationLevel, PermissionFlagsBits } from 'discord.js';
import { and, count, desc, eq, gte, sql } from 'drizzle-orm';
import { defineCommand, type Context } from '../../../core/command.js';
import { UsageError } from '../../../core/errors.js';
import { db, schema } from '../../../db/index.js';
import { ts } from '../../../core/branding.js';
import { consume } from '../../../core/cache.js';

/** Counts joins and leaves inside a window, in one round trip. */
async function windowCounts(guildId: string, since: Date) {
  const [row] = await db
    .select({
      joins: sql<number>`count(*) filter (where ${schema.memberEvents.kind} = 'join')`,
      leaves: sql<number>`count(*) filter (where ${schema.memberEvents.kind} = 'leave')`,
    })
    .from(schema.memberEvents)
    .where(and(
      eq(schema.memberEvents.guildId, guildId),
      gte(schema.memberEvents.at, since),
    ));

  const joins = Number(row?.joins ?? 0);
  const leaves = Number(row?.leaves ?? 0);
  return { joins, leaves, net: joins - leaves };
}

const startOfToday = () => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
};

const daysAgo = (n: number) => new Date(Date.now() - n * 86_400_000);

export const serverinfo = defineCommand({
  name: 'serverinfo',
  aliases: ['si', 'guildinfo', 'server'],
  module: 'Utility',
  description: 'Full report on the server',
  cooldown: { uses: 3, windowMs: 10_000 },
  execute: async (ctx) => {
    const guild = ctx.guild;
    const members = await guild.members.fetch().catch(() => guild.members.cache);

    const humans = members.filter((m) => !m.user.bot).size;
    const bots = members.size - humans;
    const online = members.filter((m) => m.presence && m.presence.status !== 'offline').size;

    const channels = guild.channels.cache;
    const text = channels.filter((c) => c.type === ChannelType.GuildText).size;
    const voice = channels.filter((c) => c.type === ChannelType.GuildVoice).size;
    const categories = channels.filter((c) => c.type === ChannelType.GuildCategory).size;

    const today = await windowCounts(guild.id, startOfToday());
    const week = await windowCounts(guild.id, daysAgo(7));

    return ctx.send({
      title: guild.name,
      thumbnail: guild.iconURL({ size: 256 }) ?? undefined,
      image: guild.bannerURL({ size: 1024 }) ?? undefined,
      description: guild.description ?? undefined,
      fields: [
        { name: 'Owner', value: `<@${guild.ownerId}>`, inline: true },
        { name: 'Created', value: ts(guild.createdAt, 'D'), inline: true },
        { name: 'ID', value: `\`${guild.id}\``, inline: true },
        {
          name: `Members · ${guild.memberCount.toLocaleString('en-GB')}`,
          value: `${humans.toLocaleString('en-GB')} people · ${bots} bots · ${online} online`,
          inline: false,
        },
        {
          name: 'Recent movement',
          value:
            `Today: **+${today.joins}** joined, **−${today.leaves}** left (net ${signed(today.net)})\n` +
            `This week: **+${week.joins}** joined, **−${week.leaves}** left (net ${signed(week.net)})`,
        },
        {
          name: `Channels · ${channels.size}`,
          value: `${text} text · ${voice} voice · ${categories} categories`,
          inline: true,
        },
        { name: 'Roles', value: String(guild.roles.cache.size - 1), inline: true },
        { name: 'Emojis', value: `${guild.emojis.cache.size} · ${guild.stickers.cache.size} stickers`, inline: true },
        {
          name: 'Boosts',
          value: `${guild.premiumSubscriptionCount ?? 0} · tier ${guild.premiumTier}`,
          inline: true,
        },
        { name: 'Verification', value: GuildVerificationLevel[guild.verificationLevel], inline: true },
        { name: 'Vanity', value: guild.vanityURLCode ? `.gg/${guild.vanityURLCode}` : 'None', inline: true },
      ],
      footer: `Movement counts start from when Bounty joined`,
    });
  },
});

export const membercount = defineCommand({
  name: 'membercount',
  aliases: ['mc', 'members'],
  module: 'Utility',
  description: 'Member count with today\'s joins and leaves',
  cooldown: { uses: 4, windowMs: 8000 },
  execute: async (ctx) => {
    const guild = ctx.guild;
    const today = await windowCounts(guild.id, startOfToday());
    const week = await windowCounts(guild.id, daysAgo(7));
    const month = await windowCounts(guild.id, daysAgo(30));

    const bots = guild.members.cache.filter((m) => m.user.bot).size;

    return ctx.send({
      title: `${guild.memberCount.toLocaleString('en-GB')} members`,
      thumbnail: guild.iconURL({ size: 128 }) ?? undefined,
      fields: [
        { name: 'Today', value: `+${today.joins} / −${today.leaves}\n**${signed(today.net)}**`, inline: true },
        { name: '7 days', value: `+${week.joins} / −${week.leaves}\n**${signed(week.net)}**`, inline: true },
        { name: '30 days', value: `+${month.joins} / −${month.leaves}\n**${signed(month.net)}**`, inline: true },
        {
          name: 'Breakdown',
          value:
            `${(guild.memberCount - bots).toLocaleString('en-GB')} people · ${bots} bots\n` +
            `${guild.premiumSubscriptionCount ?? 0} boosting`,
        },
      ],
    });
  },
  subcommands: {
    today: {
      name: 'today', module: 'Utility',
      description: 'Just today\'s numbers',
      execute: async (ctx) => joinWindow(ctx, startOfToday(), 'today'),
    },
    week: {
      name: 'week', aliases: ['7d'], module: 'Utility',
      description: 'The last seven days',
      execute: async (ctx) => joinWindow(ctx, daysAgo(7), 'in the last 7 days'),
    },
    month: {
      name: 'month', aliases: ['30d'], module: 'Utility',
      description: 'The last thirty days',
      execute: async (ctx) => joinWindow(ctx, daysAgo(30), 'in the last 30 days'),
    },
  },
});

export const joins = defineCommand({
  name: 'joins',
  aliases: ['joined', 'newmembers'],
  module: 'Utility',
  description: 'Who joined recently',
  execute: async (ctx) => {
    const since = startOfToday();
    const rows = await db.select().from(schema.memberEvents)
      .where(and(
        eq(schema.memberEvents.guildId, ctx.guild.id),
        eq(schema.memberEvents.kind, 'join'),
        gte(schema.memberEvents.at, since),
      ))
      .orderBy(desc(schema.memberEvents.at))
      .limit(15);

    if (!rows.length) return ctx.warn('Nobody has joined today.');

    return ctx.send({
      title: `${rows.length} joined today`,
      description: rows.map((r) => `<@${r.userId}> · ${ts(r.at)}`).join('\n'),
      footer: rows.length === 15 ? 'Showing the 15 most recent' : undefined,
    });
  },
  subcommands: {
    leaves: {
      name: 'leaves', aliases: ['left'], module: 'Utility',
      description: 'Who left today',
      execute: async (ctx) => {
        const rows = await db.select().from(schema.memberEvents)
          .where(and(
            eq(schema.memberEvents.guildId, ctx.guild.id),
            eq(schema.memberEvents.kind, 'leave'),
            gte(schema.memberEvents.at, startOfToday()),
          ))
          .orderBy(desc(schema.memberEvents.at))
          .limit(15);
        if (!rows.length) return ctx.ok('Nobody has left today.');
        return ctx.send({
          title: `${rows.length} left today`,
          description: rows.map((r) => `<@${r.userId}> · ${ts(r.at)}`).join('\n'),
        });
      },
    },
  },
});

export const growth = defineCommand({
  name: 'growth',
  aliases: ['graph', 'membergraph'],
  module: 'Utility',
  description: 'Day by day growth for the last two weeks',
  cooldown: { uses: 2, windowMs: 15_000 },
  execute: async (ctx) => {
    const rows = await db
      .select({
        day: sql<string>`date_trunc('day', ${schema.memberEvents.at})::date::text`,
        joins: sql<number>`count(*) filter (where ${schema.memberEvents.kind} = 'join')`,
        leaves: sql<number>`count(*) filter (where ${schema.memberEvents.kind} = 'leave')`,
      })
      .from(schema.memberEvents)
      .where(and(
        eq(schema.memberEvents.guildId, ctx.guild.id),
        gte(schema.memberEvents.at, daysAgo(14)),
      ))
      .groupBy(sql`1`)
      .orderBy(sql`1`);

    if (!rows.length) return ctx.warn('Not enough history yet. Check back tomorrow.');

    const peak = Math.max(...rows.map((r) => Math.max(Number(r.joins), Number(r.leaves))), 1);

    // A text bar chart beats an image here: it renders on mobile, costs no
    // upload, and stays readable when the server is quiet.
    const lines = rows.map((r) => {
      const j = Number(r.joins);
      const l = Number(r.leaves);
      const bar = '█'.repeat(Math.round((j / peak) * 12)) || '·';
      return `\`${r.day.slice(5)}\` ${bar} **+${j}** −${l}`;
    });

    const totals = rows.reduce(
      (acc, r) => ({ joins: acc.joins + Number(r.joins), leaves: acc.leaves + Number(r.leaves) }),
      { joins: 0, leaves: 0 },
    );

    return ctx.send({
      title: 'Growth, last 14 days',
      description: lines.join('\n'),
      fields: [{
        name: 'Total',
        value: `+${totals.joins} joined, −${totals.leaves} left, net ${signed(totals.joins - totals.leaves)}`,
      }],
    });
  },
});

export const boosters = defineCommand({
  name: 'boosters',
  aliases: ['boosts', 'nitro'],
  module: 'Utility',
  description: 'Everyone boosting the server',
  execute: async (ctx) => {
    const members = await ctx.guild.members.fetch().catch(() => ctx.guild.members.cache);
    const list = members.filter((m) => m.premiumSince)
      .sort((a, b) => (a.premiumSinceTimestamp ?? 0) - (b.premiumSinceTimestamp ?? 0));

    if (!list.size) return ctx.warn('Nobody is boosting right now.');

    return ctx.send({
      title: `${list.size} booster${list.size === 1 ? '' : 's'} · tier ${ctx.guild.premiumTier}`,
      description: list.first(20)!
        .map((m, i) => `\`${i + 1}.\` ${m} — since ${ts(m.premiumSince!, 'D')}`)
        .join('\n'),
      footer: list.size > 20 ? `Showing the 20 longest running` : undefined,
    });
  },
});

export const counters = defineCommand({
  name: 'counters',
  aliases: ['counter', 'statschannels'],
  module: 'Utility',
  description: 'Channels that show a live count in their name',
  userPermissions: [PermissionFlagsBits.ManageGuild],
  botPermissions: [PermissionFlagsBits.ManageChannels],
  subcommands: {
    add: {
      name: 'add', aliases: ['create'], module: 'Utility',
      description: 'Create a counter channel',
      usage: 'counters add <members|humans|bots|boosters|online|channels|roles|joins_today> [template]',
      execute: async (ctx) => {
        const kind = ctx.args[0]?.toLowerCase() as typeof schema.counterKind.enumValues[number];
        if (!schema.counterKind.enumValues.includes(kind)) {
          throw new UsageError(
            'Pick what to count.',
            `One of: ${schema.counterKind.enumValues.join(', ')}`,
          );
        }
        const template = ctx.rest(1) || defaultTemplate(kind);

        const channel = await ctx.guild.channels.create({
          name: template.replace('{count}', '0'),
          type: ChannelType.GuildVoice,
          permissionOverwrites: [{
            id: ctx.guild.roles.everyone.id,
            deny: [PermissionFlagsBits.Connect],
          }],
        });

        await db.insert(schema.counterChannels).values({
          channelId: channel.id, guildId: ctx.guild.id, kind, template,
        });

        return ctx.ok(
          `Created ${channel}. It refreshes every 10 minutes — Discord limits ` +
          'channel renames to two per ten minutes, so faster is not possible.',
        );
      },
    },
    remove: {
      name: 'remove', aliases: ['delete'], module: 'Utility',
      description: 'Delete a counter channel',
      usage: 'counters remove <#channel>',
      execute: async (ctx) => {
        const id = ctx.args[0]?.match(/^<#(\d{17,20})>$/)?.[1] ?? ctx.args[0];
        if (!id) throw new UsageError('Name the counter channel.');
        const deleted = await db.delete(schema.counterChannels).where(and(
          eq(schema.counterChannels.guildId, ctx.guild.id),
          eq(schema.counterChannels.channelId, id),
        )).returning();
        if (!deleted.length) throw new UsageError('That is not a counter channel.');
        await ctx.guild.channels.cache.get(id)?.delete('Counter removed').catch(() => undefined);
        return ctx.ok('Counter removed.');
      },
    },
    list: {
      name: 'list', module: 'Utility',
      description: 'Show every counter channel',
      execute: async (ctx) => {
        const rows = await db.select().from(schema.counterChannels)
          .where(eq(schema.counterChannels.guildId, ctx.guild.id));
        if (!rows.length) return ctx.warn('No counter channels yet.');
        return ctx.send({
          title: 'Counter channels',
          description: rows.map((r) => `<#${r.channelId}> — \`${r.kind}\` · \`${r.template}\``).join('\n'),
        });
      },
    },
  },
});

/* --------------------------------------------------------- background */

/**
 * Refreshes counter channels. Renames are the tightest limit Discord has on
 * channels, so a channel is only touched when its number actually moved.
 */
export async function refreshCounters(client: import('../../../core/client.js').BountyClient): Promise<void> {
  const rows = await db.select().from(schema.counterChannels).catch(() => []);

  for (const row of rows) {
    const guild = client.guilds.cache.get(row.guildId);
    const channel = guild?.channels.cache.get(row.channelId);
    if (!guild || !channel) continue;

    const value = await counterValue(guild, row.kind);
    if (row.lastValue === value) continue;

    const bucket = await consume(`bounty:counter:${row.channelId}`, 2, 10 * 60_000);
    if (bucket.limited) continue;

    const name = row.template.replace('{count}', value.toLocaleString('en-GB'));
    await channel.setName(name, 'Counter refresh').catch(() => undefined);
    await db.update(schema.counterChannels)
      .set({ lastValue: value, updatedAt: new Date() })
      .where(eq(schema.counterChannels.channelId, row.channelId))
      .catch(() => undefined);
  }
}

async function counterValue(
  guild: import('discord.js').Guild,
  kind: typeof schema.counterKind.enumValues[number],
): Promise<number> {
  switch (kind) {
    case 'members': return guild.memberCount;
    case 'humans': return guild.members.cache.filter((m) => !m.user.bot).size;
    case 'bots': return guild.members.cache.filter((m) => m.user.bot).size;
    case 'boosters': return guild.premiumSubscriptionCount ?? 0;
    case 'online': return guild.members.cache.filter((m) => m.presence && m.presence.status !== 'offline').size;
    case 'channels': return guild.channels.cache.size;
    case 'roles': return guild.roles.cache.size - 1;
    case 'joins_today': {
      const [row] = await db.select({ n: count() }).from(schema.memberEvents).where(and(
        eq(schema.memberEvents.guildId, guild.id),
        eq(schema.memberEvents.kind, 'join'),
        gte(schema.memberEvents.at, startOfToday()),
      ));
      return Number(row?.n ?? 0);
    }
  }
}

/* ----------------------------------------------------------- helpers */

async function joinWindow(ctx: Context, since: Date, label: string) {
  const { joins: j, leaves, net } = await windowCounts(ctx.guild.id, since);
  return ctx.send({
    title: `Movement ${label}`,
    description:
      `**+${j}** joined\n**−${leaves}** left\n**${signed(net)}** net change\n\n` +
      `The server is on **${ctx.guild.memberCount.toLocaleString('en-GB')}** members.`,
  });
}

const signed = (n: number) => (n > 0 ? `+${n}` : String(n));

const defaultTemplate = (kind: string) => ({
  members: 'Members: {count}',
  humans: 'People: {count}',
  bots: 'Bots: {count}',
  boosters: 'Boosters: {count}',
  online: 'Online: {count}',
  channels: 'Channels: {count}',
  roles: 'Roles: {count}',
  joins_today: 'Joined today: {count}',
}[kind] ?? 'Count: {count}');
