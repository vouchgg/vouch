/**
 * `,log …`
 *
 * The eighteen category commands are generated from one list, because they
 * differ only by the enum value they write. Everything with real behaviour —
 * ignores, webhook mode, the test send — is written out.
 */

import { ChannelType, PermissionFlagsBits, type TextChannel } from 'discord.js';
import { and, eq, inArray } from 'drizzle-orm';
import { defineCommand, type Command, type Context } from '../../../core/command.js';
import { UsageError } from '../../../core/errors.js';
import { db, schema } from '../../../db/index.js';
import { LoggingEngine } from '../engine.js';
import { buildEmbed } from '../../../core/branding.js';

type Category = (typeof schema.logCategory.enumValues)[number];

/** Every category, with the words that go in help output. */
const CATEGORIES: Array<{ id: Category; aliases?: string[]; what: string }> = [
  { id: 'messages', aliases: ['msg', 'msgs'], what: 'edits, deletes and bulk purges' },
  { id: 'images', aliases: ['media', 'attachments'], what: 'deleted images, re-uploaded so they survive' },
  { id: 'members', aliases: ['joins', 'leaves'], what: 'joins, leaves and username changes' },
  { id: 'moderation', aliases: ['mod', 'punishments'], what: 'bans, kicks, timeouts and jails' },
  { id: 'roles', aliases: ['role'], what: 'role edits and who gained or lost one' },
  { id: 'channels', aliases: ['channel'], what: 'channels created, deleted and renamed' },
  { id: 'voice', aliases: ['vc'], what: 'voice joins, leaves and moves' },
  { id: 'invites', aliases: ['invite'], what: 'invites created, deleted and used' },
  { id: 'server', aliases: ['guild'], what: 'server name, icon, vanity and owner' },
  { id: 'emojis', aliases: ['emoji', 'stickers'], what: 'emoji and sticker changes' },
  { id: 'threads', aliases: ['thread'], what: 'threads created and deleted' },
  { id: 'webhooks', aliases: ['webhook'], what: 'webhook changes, worth watching closely' },
  { id: 'boosts', aliases: ['boost', 'nitro'], what: 'boosts gained and lost' },
  { id: 'automod', what: 'Discord AutoMod triggers' },
  { id: 'bots', aliases: ['bot'], what: 'bots added to the server' },
  { id: 'nicknames', aliases: ['nicks', 'nickname'], what: 'nickname changes' },
  { id: 'avatars', aliases: ['avatar', 'pfp'], what: 'avatar changes' },
  { id: 'reactions', aliases: ['reaction'], what: 'reactions removed or cleared' },
];

async function setCategory(ctx: Context, category: Category, channelId: string | null): Promise<void> {
  if (channelId === null) {
    await db.delete(schema.logChannels).where(and(
      eq(schema.logChannels.guildId, ctx.guild.id),
      eq(schema.logChannels.category, category),
    ));
  } else {
    await db.insert(schema.logChannels)
      .values({ guildId: ctx.guild.id, category, channelId })
      .onConflictDoUpdate({
        target: [schema.logChannels.guildId, schema.logChannels.category],
        set: { channelId, enabled: true, updatedAt: new Date() },
      });
  }
  await LoggingEngine.invalidate(ctx.guild.id);
}

/** Resolves a channel argument and checks Bounty can actually post there. */
function resolveLogChannel(ctx: Context): TextChannel | null {
  const raw = ctx.args[0];
  if (!raw) throw new UsageError('Name a channel, or say `none` to turn this off.');
  if (['none', 'off', 'disable', 'remove'].includes(raw.toLowerCase())) return null;

  const id = raw.match(/^<#(\d{17,20})>$/)?.[1] ?? (/^\d{17,20}$/.test(raw) ? raw : null);
  const channel = id
    ? ctx.guild.channels.cache.get(id)
    : ctx.guild.channels.cache.find((c) => c.name === raw.replace(/^#/, ''));

  if (!channel || channel.type !== ChannelType.GuildText) {
    throw new UsageError(`No text channel matched \`${raw.slice(0, 40)}\`.`);
  }

  const perms = channel.permissionsFor(ctx.me);
  if (!perms?.has(PermissionFlagsBits.SendMessages) || !perms.has(PermissionFlagsBits.EmbedLinks)) {
    throw new UsageError(
      `Bounty cannot post in ${channel}.`,
      'It needs View Channel, Send Messages and Embed Links there.',
    );
  }
  return channel;
}

const categoryCommands: Record<string, Command> = Object.fromEntries(
  CATEGORIES.map(({ id, aliases, what }) => [id, {
    name: id,
    aliases,
    module: 'Utility' as const,
    description: `Log ${what}`,
    usage: `log ${id} <#channel|none>`,
    execute: async (ctx: Context) => {
      const channel = resolveLogChannel(ctx);
      await setCategory(ctx, id, channel?.id ?? null);
      return ctx.ok(channel
        ? `Logging ${what} to ${channel}.`
        : `Stopped logging ${what}.`);
    },
  }]),
);

export const log = defineCommand({
  name: 'log',
  aliases: ['logs', 'logging'],
  module: 'Utility',
  description: 'Choose what gets logged and where',
  userPermissions: [PermissionFlagsBits.ManageGuild],
  botPermissions: [PermissionFlagsBits.ViewAuditLog],
  subcommands: {
    ...categoryCommands,

    all: {
      name: 'all', aliases: ['everything'], module: 'Utility',
      description: 'Send every category to one channel',
      usage: 'log all <#channel|none>',
      execute: async (ctx) => {
        const channel = resolveLogChannel(ctx);
        if (!channel) {
          await db.delete(schema.logChannels).where(eq(schema.logChannels.guildId, ctx.guild.id));
          await LoggingEngine.invalidate(ctx.guild.id);
          return ctx.ok('Logging turned off completely.');
        }

        await db.insert(schema.logChannels)
          .values(CATEGORIES.map(({ id }) => ({
            guildId: ctx.guild.id, category: id, channelId: channel.id,
          })))
          .onConflictDoUpdate({
            target: [schema.logChannels.guildId, schema.logChannels.category],
            set: { channelId: channel.id, enabled: true, updatedAt: new Date() },
          });
        await LoggingEngine.invalidate(ctx.guild.id);

        return ctx.ok(
          `All ${CATEGORIES.length} categories now log to ${channel}. ` +
          `Split them up any time with \`${ctx.guildConfig.prefix}log <category> #channel\`.`,
        );
      },
    },

    split: {
      name: 'split', module: 'Utility',
      description: 'Create a logs category with a channel per group',
      execute: async (ctx) => {
        const parent = await ctx.guild.channels.create({
          name: 'logs', type: ChannelType.GuildCategory,
          permissionOverwrites: [{
            id: ctx.guild.roles.everyone.id,
            deny: [PermissionFlagsBits.ViewChannel],
          }],
        });

        // Grouped by who reads them, not by event type.
        const groups: Array<[string, Category[]]> = [
          ['message-logs', ['messages', 'images', 'reactions']],
          ['member-logs', ['members', 'nicknames', 'avatars', 'boosts']],
          ['mod-logs', ['moderation', 'automod']],
          ['server-logs', ['channels', 'roles', 'server', 'emojis', 'threads', 'webhooks', 'bots']],
          ['voice-logs', ['voice']],
          ['invite-logs', ['invites']],
        ];

        for (const [name, categories] of groups) {
          const channel = await ctx.guild.channels.create({
            name, type: ChannelType.GuildText, parent,
          });
          await db.insert(schema.logChannels)
            .values(categories.map((category) => ({
              guildId: ctx.guild.id, category, channelId: channel.id,
            })))
            .onConflictDoUpdate({
              target: [schema.logChannels.guildId, schema.logChannels.category],
              set: { channelId: channel.id, enabled: true, updatedAt: new Date() },
            });
        }

        await LoggingEngine.invalidate(ctx.guild.id);
        return ctx.ok(`Built ${groups.length} log channels under **${parent.name}**.`);
      },
    },

    list: {
      name: 'list', aliases: ['show', 'config'], module: 'Utility',
      description: 'Show every category and where it goes',
      execute: async (ctx) => {
        const rows = await db.select().from(schema.logChannels)
          .where(eq(schema.logChannels.guildId, ctx.guild.id));
        const settings = await db.select().from(schema.logSettings)
          .where(eq(schema.logSettings.guildId, ctx.guild.id)).limit(1);

        const configured = CATEGORIES.filter((c) => rows.some((r) => r.category === c.id));
        const off = CATEGORIES.filter((c) => !rows.some((r) => r.category === c.id));
        const s = settings[0];

        return ctx.send({
          title: 'Logging',
          description: configured.length
            ? configured.map((c) => {
              const row = rows.find((r) => r.category === c.id)!;
              return `\`${c.id}\` → <#${row.channelId}>${row.enabled ? '' : ' *(paused)*'}`;
            }).join('\n')
            : `Nothing is being logged. Start with \`${ctx.guildConfig.prefix}log all #channel\`.`,
          fields: [
            ...(off.length ? [{ name: 'Not logged', value: off.map((c) => `\`${c.id}\``).join(' ') }] : []),
            ...(s ? [{
              name: 'Filters',
              value:
                `Bots ${s.ignoreBots ? 'hidden' : 'shown'} · ` +
                `attachments ${s.mirrorAttachments ? 'mirrored' : 'linked'}\n` +
                `Ignoring ${s.ignoredChannelIds.length} channels, ` +
                `${s.ignoredUserIds.length} users, ${s.ignoredRoleIds.length} roles`,
            }] : []),
          ],
        });
      },
    },

    ignore: {
      name: 'ignore', module: 'Utility',
      description: 'Stop logging a channel, user or role',
      usage: 'log ignore <#channel|@user|@role>',
      execute: async (ctx) => ignoreCommand(ctx, true),
    },

    unignore: {
      name: 'unignore', aliases: ['watch'], module: 'Utility',
      description: 'Start logging something that was ignored',
      usage: 'log unignore <#channel|@user|@role>',
      execute: async (ctx) => ignoreCommand(ctx, false),
    },

    bots: {
      name: 'bots', module: 'Utility',
      description: 'Include or hide bot activity in the logs',
      usage: 'log bots <on|off>',
      execute: async (ctx) => {
        const show = ctx.args[0]?.toLowerCase() === 'on';
        await upsertSettings(ctx, { ignoreBots: !show });
        return ctx.ok(show ? 'Bot activity will be logged.' : 'Bot activity is hidden from the logs.');
      },
    },

    mirror: {
      name: 'mirror', module: 'Utility',
      description: 'Re-upload deleted images instead of linking them',
      usage: 'log mirror <on|off>',
      execute: async (ctx) => {
        const on = ctx.args[0]?.toLowerCase() !== 'off';
        await upsertSettings(ctx, { mirrorAttachments: on });
        return ctx.ok(on
          ? 'Deleted images are re-uploaded, so they stay viewable after Discord drops them.'
          : 'Deleted images are linked only. The links stop working within minutes.');
      },
    },

    webhook: {
      name: 'webhook', module: 'Utility',
      description: 'Send logs through a webhook for higher throughput',
      usage: 'log webhook <on|off>',
      botPermissions: [PermissionFlagsBits.ManageWebhooks],
      execute: async (ctx) => {
        const on = ctx.args[0]?.toLowerCase() !== 'off';
        const rows = await db.select().from(schema.logChannels)
          .where(eq(schema.logChannels.guildId, ctx.guild.id));
        if (!rows.length) throw new UsageError('Set up at least one log channel first.');

        if (!on) {
          await db.update(schema.logChannels).set({ webhookId: null, webhookToken: null })
            .where(eq(schema.logChannels.guildId, ctx.guild.id));
          await LoggingEngine.invalidate(ctx.guild.id);
          return ctx.ok('Logs post as Bounty again.');
        }

        const unique = [...new Set(rows.map((r) => r.channelId))];
        let made = 0;

        for (const channelId of unique) {
          const channel = ctx.guild.channels.cache.get(channelId) as TextChannel | undefined;
          if (!channel) continue;
          const hook = await channel.createWebhook({
            name: 'Bounty logs',
            reason: 'Logging throughput',
          }).catch(() => null);
          if (!hook) continue;

          await db.update(schema.logChannels)
            .set({ webhookId: hook.id, webhookToken: hook.token })
            .where(and(
              eq(schema.logChannels.guildId, ctx.guild.id),
              eq(schema.logChannels.channelId, channelId),
            ));
          made += 1;
        }

        await LoggingEngine.invalidate(ctx.guild.id);
        return ctx.ok(`Logs now post through ${made} webhook${made === 1 ? '' : 's'}, which keeps them flowing during a raid.`);
      },
    },

    pause: {
      name: 'pause', module: 'Utility',
      description: 'Pause a category without losing its channel',
      usage: 'log pause <category>',
      execute: async (ctx) => togglePause(ctx, false),
    },

    resume: {
      name: 'resume', module: 'Utility',
      description: 'Resume a paused category',
      usage: 'log resume <category>',
      execute: async (ctx) => togglePause(ctx, true),
    },

    test: {
      name: 'test', module: 'Utility',
      description: 'Send a sample entry to check permissions',
      usage: 'log test <category>',
      execute: async (ctx) => {
        const wanted = ctx.args[0]?.toLowerCase();
        const category = CATEGORIES.find((c) => c.id === wanted || c.aliases?.includes(wanted ?? ''));
        if (!category) {
          throw new UsageError(
            'Name a category.',
            `One of: ${CATEGORIES.map((c) => c.id).join(', ')}`,
          );
        }

        const [row] = await db.select().from(schema.logChannels).where(and(
          eq(schema.logChannels.guildId, ctx.guild.id),
          eq(schema.logChannels.category, category.id),
        )).limit(1);
        if (!row) throw new UsageError(`\`${category.id}\` has no channel yet.`);

        const channel = ctx.guild.channels.cache.get(row.channelId) as TextChannel | undefined;
        if (!channel) throw new UsageError('That log channel was deleted.');

        await channel.send({
          embeds: [buildEmbed({ guildConfig: ctx.guildConfig }, {
            title: `Test entry · ${category.id}`,
            description: `Sent by ${ctx.author}. Real entries cover ${category.what}.`,
            footer: ctx.guild.name,
          })],
        });
        return ctx.ok(`Sent a test entry to ${channel}.`);
      },
    },

    reset: {
      name: 'reset', aliases: ['disable'], module: 'Utility',
      description: 'Turn logging off and forget every channel',
      execute: async (ctx) => {
        await db.delete(schema.logChannels).where(eq(schema.logChannels.guildId, ctx.guild.id));
        await db.delete(schema.logSettings).where(eq(schema.logSettings.guildId, ctx.guild.id));
        await LoggingEngine.invalidate(ctx.guild.id);
        return ctx.ok('Logging is off and every channel was forgotten.');
      },
    },
  },
});

/* ------------------------------------------------------------- helpers */

async function upsertSettings(
  ctx: Context,
  patch: Partial<typeof schema.logSettings.$inferInsert>,
): Promise<void> {
  await db.insert(schema.logSettings)
    .values({ guildId: ctx.guild.id, ...patch })
    .onConflictDoUpdate({ target: schema.logSettings.guildId, set: patch });
  await LoggingEngine.invalidate(ctx.guild.id);
}

async function ignoreCommand(ctx: Context, add: boolean) {
  const raw = ctx.args[0];
  if (!raw) throw new UsageError('Name a channel, user or role.');

  const [existing] = await db.select().from(schema.logSettings)
    .where(eq(schema.logSettings.guildId, ctx.guild.id)).limit(1);

  const current = {
    channels: existing?.ignoredChannelIds ?? [],
    users: existing?.ignoredUserIds ?? [],
    roles: existing?.ignoredRoleIds ?? [],
  };

  const channelId = raw.match(/^<#(\d{17,20})>$/)?.[1];
  const userId = raw.match(/^<@!?(\d{17,20})>$/)?.[1];
  const roleId = raw.match(/^<@&(\d{17,20})>$/)?.[1];

  let label: string;
  if (channelId) {
    current.channels = apply(current.channels, channelId, add);
    label = `<#${channelId}>`;
  } else if (roleId) {
    current.roles = apply(current.roles, roleId, add);
    label = `<@&${roleId}>`;
  } else if (userId) {
    current.users = apply(current.users, userId, add);
    label = `<@${userId}>`;
  } else {
    throw new UsageError('Mention a channel, user or role so there is no ambiguity.');
  }

  await upsertSettings(ctx, {
    ignoredChannelIds: current.channels,
    ignoredUserIds: current.users,
    ignoredRoleIds: current.roles,
  });

  return ctx.ok(add ? `${label} is no longer logged.` : `${label} is logged again.`);
}

const apply = (list: string[], id: string, add: boolean) =>
  add ? [...new Set([...list, id])] : list.filter((x) => x !== id);

async function togglePause(ctx: Context, enabled: boolean) {
  const wanted = ctx.args[0]?.toLowerCase();
  const category = CATEGORIES.find((c) => c.id === wanted || c.aliases?.includes(wanted ?? ''));
  if (!category) throw new UsageError(`Name a category, such as \`${CATEGORIES[0].id}\`.`);

  const updated = await db.update(schema.logChannels).set({ enabled })
    .where(and(
      eq(schema.logChannels.guildId, ctx.guild.id),
      inArray(schema.logChannels.category, [category.id]),
    )).returning();

  if (!updated.length) throw new UsageError(`\`${category.id}\` has no channel set.`);
  await LoggingEngine.invalidate(ctx.guild.id);
  return ctx.ok(enabled ? `\`${category.id}\` is logging again.` : `\`${category.id}\` is paused.`);
}
