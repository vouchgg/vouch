/**
 * Logging engine.
 *
 * Three problems decide the shape of this file:
 *
 *  1. **Volume.** A busy server deletes hundreds of messages a minute. Sending
 *     one message per event burns the channel's rate limit in seconds, so
 *     events are batched per channel and flushed as up to ten embeds at once.
 *  2. **Attribution.** The gateway does not say who deleted a message or a
 *     channel. That only comes from the audit log, which is itself rate
 *     limited, so lookups are cached and skipped when they cannot help.
 *  3. **Discord deletes the evidence.** Attachments on a deleted message are
 *     gone from the CDN almost immediately, so images are mirrored into the
 *     log message itself while the URL is still alive.
 */

import {
  AuditLogEvent, ChannelType, Events, PermissionFlagsBits, WebhookClient,
  type Attachment, type AuditLogChange, type Guild, type GuildAuditLogsEntry,
  type GuildTextBasedChannel, type Message, type PartialMessage,
} from 'discord.js';
import { and, eq } from 'drizzle-orm';
import { db, schema } from '../../db/index.js';
import { key, redis, remember, TTL, forget } from '../../core/cache.js';
import { buildEmbed, PALETTE, ts } from '../../core/branding.js';
import { logger } from '../../core/logger.js';
import type { BountyClient } from '../../core/client.js';
import type { EmbedBuilder } from 'discord.js';

export type LogCategory = (typeof schema.logCategory.enumValues)[number];

interface Target {
  channelId: string;
  webhookId: string | null;
  webhookToken: string | null;
}

interface Queued {
  embed: EmbedBuilder;
  files?: string[];
}

const FLUSH_MS = 1200;
const MAX_EMBEDS = 10;

export class LoggingEngine {
  /** channelId → pending embeds. */
  private readonly queues = new Map<string, Queued[]>();
  private readonly timers = new Map<string, NodeJS.Timeout>();
  private readonly webhooks = new Map<string, WebhookClient>();

  constructor(private readonly client: BountyClient) {}

  attach(): void {
    const on = <K extends keyof import('discord.js').ClientEvents>(
      event: K,
      handler: (...args: import('discord.js').ClientEvents[K]) => Promise<void>,
    ) => {
      this.client.on(event, (...args) => {
        void handler(...args).catch((err) => logger.warn({ err, event }, 'log handler failed'));
      });
    };

    /* ------------------------------------------------------- messages */

    on(Events.MessageDelete, async (message) => {
      if (!message.inGuild()) return;
      await this.messageDeleted(message);
    });

    on(Events.MessageBulkDelete, async (messages) => {
      const first = messages.first();
      if (!first?.inGuild()) return;

      const actor = await this.actor(first.guild, AuditLogEvent.MessageBulkDelete, first.channelId);
      await this.push(first.guild, 'messages', {
        embed: this.embed(first.guild, {
          tone: 'danger',
          title: `${messages.size} messages purged`,
          description: `In <#${first.channelId}>${actor ? ` by ${actor}` : ''}.`,
          fields: [{
            name: 'Authors',
            value: summariseAuthors(messages.map((m) => m.author?.id)),
          }],
        }),
      });
    });

    on(Events.MessageUpdate, async (before, after) => {
      if (!after.inGuild() || !after.author || after.author.bot) return;
      if (before.content === after.content) return; // embed resolution, not an edit
      if (await this.ignored(after.guildId, after.channelId, after.author.id, after.member?.roles.cache.keys())) return;

      await this.push(after.guild, 'messages', {
        embed: this.embed(after.guild, {
          tone: 'warn',
          title: 'Message edited',
          description: `${after.author} in <#${after.channelId}> · [jump](${after.url})`,
          fields: [
            { name: 'Before', value: clip(before.content) },
            { name: 'After', value: clip(after.content) },
          ],
        }),
      });
    });

    /* --------------------------------------------------------- members */

    on(Events.GuildMemberAdd, async (member) => {
      const age = Date.now() - member.user.createdTimestamp;
      await this.push(member.guild, 'members', {
        embed: this.embed(member.guild, {
          tone: 'success',
          title: 'Member joined',
          description: `${member} · \`${member.user.tag}\` · \`${member.id}\``,
          thumbnail: member.user.displayAvatarURL({ size: 128 }),
          fields: [
            { name: 'Account made', value: `${ts(member.user.createdAt)}`, inline: true },
            { name: 'Member count', value: String(member.guild.memberCount), inline: true },
            // A day-old account joining is the single most useful raid signal.
            ...(age < 86_400_000 * 7
              ? [{ name: 'Heads up', value: 'This account is less than a week old.' }]
              : []),
          ],
        }),
      });
    });

    on(Events.GuildMemberRemove, async (member) => {
      const kicked = await this.actorEntry(member.guild, AuditLogEvent.MemberKick, member.id);
      await this.push(member.guild, kicked ? 'moderation' : 'members', {
        embed: this.embed(member.guild, {
          tone: 'danger',
          title: kicked ? 'Member kicked' : 'Member left',
          description: `${member.user.tag} · \`${member.id}\``,
          thumbnail: member.user.displayAvatarURL({ size: 128 }),
          fields: [
            ...(kicked ? [{ name: 'Moderator', value: `<@${kicked.executorId}>`, inline: true }] : []),
            ...(kicked?.reason ? [{ name: 'Reason', value: clip(kicked.reason) }] : []),
            {
              name: 'Roles',
              value: member.roles.cache.filter((r) => r.id !== member.guild.id)
                .map((r) => `<@&${r.id}>`).join(' ') || 'None',
            },
            { name: 'Joined', value: member.joinedAt ? ts(member.joinedAt) : 'Unknown', inline: true },
          ],
        }),
      });
    });

    /* ------------------------------------- roles, nicknames, avatars, boosts */

    on(Events.GuildMemberUpdate, async (before, after) => {
      if (before.nickname !== after.nickname) {
        await this.push(after.guild, 'nicknames', {
          embed: this.embed(after.guild, {
            title: 'Nickname changed',
            description: `${after} · \`${after.user.tag}\``,
            fields: [
              { name: 'Before', value: before.nickname ?? '*none*', inline: true },
              { name: 'After', value: after.nickname ?? '*none*', inline: true },
            ],
          }),
        });
      }

      const added = after.roles.cache.filter((r) => !before.roles.cache.has(r.id));
      const removed = before.roles.cache.filter((r) => !after.roles.cache.has(r.id));
      if (added.size || removed.size) {
        const entry = await this.actorEntry(after.guild, AuditLogEvent.MemberRoleUpdate, after.id);
        await this.push(after.guild, 'roles', {
          embed: this.embed(after.guild, {
            title: 'Member roles changed',
            description: `${after}${entry ? ` · by <@${entry.executorId}>` : ''}`,
            fields: [
              ...(added.size ? [{ name: 'Added', value: added.map((r) => `<@&${r.id}>`).join(' ') }] : []),
              ...(removed.size ? [{ name: 'Removed', value: removed.map((r) => `<@&${r.id}>`).join(' ') }] : []),
            ],
          }),
        });
      }

      if (!before.premiumSince && after.premiumSince) {
        await this.push(after.guild, 'boosts', {
          embed: this.embed(after.guild, {
            tone: 'live',
            title: 'Server boosted',
            description: `${after} boosted the server.`,
            fields: [{
              name: 'Total boosts',
              value: `${after.guild.premiumSubscriptionCount ?? 0} · tier ${after.guild.premiumTier}`,
            }],
          }),
        });
      }

      if (before.premiumSince && !after.premiumSince) {
        await this.push(after.guild, 'boosts', {
          embed: this.embed(after.guild, {
            tone: 'danger',
            title: 'Boost removed',
            description: `${after} stopped boosting.`,
          }),
        });
      }

      // Guild-specific avatars only; global changes come through userUpdate.
      if (before.avatar !== after.avatar) {
        await this.push(after.guild, 'avatars', {
          embed: this.embed(after.guild, {
            title: 'Server avatar changed',
            description: `${after}`,
            thumbnail: after.displayAvatarURL({ size: 256 }),
          }),
        });
      }

      const wasTimedOut = before.communicationDisabledUntilTimestamp ?? 0;
      const nowTimedOut = after.communicationDisabledUntilTimestamp ?? 0;
      if (wasTimedOut !== nowTimedOut) {
        const entry = await this.actorEntry(after.guild, AuditLogEvent.MemberUpdate, after.id);
        const lifted = nowTimedOut < Date.now();
        await this.push(after.guild, 'moderation', {
          embed: this.embed(after.guild, {
            tone: lifted ? 'success' : 'danger',
            title: lifted ? 'Timeout lifted' : 'Member timed out',
            description: `${after} · \`${after.id}\``,
            fields: [
              ...(lifted ? [] : [{ name: 'Until', value: ts(nowTimedOut), inline: true }]),
              ...(entry ? [{ name: 'Moderator', value: `<@${entry.executorId}>`, inline: true }] : []),
              ...(entry?.reason ? [{ name: 'Reason', value: clip(entry.reason) }] : []),
            ],
          }),
        });
      }
    });

    /* ------------------------------------------------------ moderation */

    on(Events.GuildBanAdd, async (ban) => {
      const entry = await this.actorEntry(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);
      await this.push(ban.guild, 'moderation', {
        embed: this.embed(ban.guild, {
          tone: 'danger',
          title: 'Member banned',
          description: `${ban.user.tag} · \`${ban.user.id}\``,
          thumbnail: ban.user.displayAvatarURL({ size: 128 }),
          fields: [
            ...(entry ? [{ name: 'Moderator', value: `<@${entry.executorId}>`, inline: true }] : []),
            { name: 'Reason', value: clip(entry?.reason ?? ban.reason ?? 'No reason given') },
          ],
        }),
      });
    });

    on(Events.GuildBanRemove, async (ban) => {
      const entry = await this.actorEntry(ban.guild, AuditLogEvent.MemberBanRemove, ban.user.id);
      await this.push(ban.guild, 'moderation', {
        embed: this.embed(ban.guild, {
          tone: 'success',
          title: 'Member unbanned',
          description: `${ban.user.tag} · \`${ban.user.id}\``,
          fields: entry ? [{ name: 'Moderator', value: `<@${entry.executorId}>`, inline: true }] : [],
        }),
      });
    });

    /* --------------------------------------------------------- channels */

    on(Events.ChannelCreate, async (channel) => {
      const entry = await this.actorEntry(channel.guild, AuditLogEvent.ChannelCreate, channel.id);
      await this.push(channel.guild, 'channels', {
        embed: this.embed(channel.guild, {
          tone: 'success',
          title: 'Channel created',
          description: `${channel} · \`${channel.name}\`${entry ? ` · by <@${entry.executorId}>` : ''}`,
          fields: [{ name: 'Type', value: ChannelType[channel.type] ?? String(channel.type), inline: true }],
        }),
      });
    });

    on(Events.ChannelDelete, async (channel) => {
      if (channel.isDMBased()) return;
      const entry = await this.actorEntry(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
      await this.push(channel.guild, 'channels', {
        embed: this.embed(channel.guild, {
          tone: 'danger',
          title: 'Channel deleted',
          description: `\`${channel.name}\`${entry ? ` · by <@${entry.executorId}>` : ''}`,
        }),
      });
    });

    on(Events.ChannelUpdate, async (before, after) => {
      if (after.isDMBased() || before.isDMBased()) return;
      if (before.name === after.name) return;
      await this.push(after.guild, 'channels', {
        embed: this.embed(after.guild, {
          title: 'Channel renamed',
          description: `${after}`,
          fields: [
            { name: 'Before', value: `\`${before.name}\``, inline: true },
            { name: 'After', value: `\`${after.name}\``, inline: true },
          ],
        }),
      });
    });

    /* ------------------------------------------------------------ roles */

    on(Events.GuildRoleCreate, async (role) => {
      const entry = await this.actorEntry(role.guild, AuditLogEvent.RoleCreate, role.id);
      await this.push(role.guild, 'roles', {
        embed: this.embed(role.guild, {
          tone: 'success',
          title: 'Role created',
          description: `${role} · \`${role.name}\`${entry ? ` · by <@${entry.executorId}>` : ''}`,
        }),
      });
    });

    on(Events.GuildRoleDelete, async (role) => {
      const entry = await this.actorEntry(role.guild, AuditLogEvent.RoleDelete, role.id);
      await this.push(role.guild, 'roles', {
        embed: this.embed(role.guild, {
          tone: 'danger',
          title: 'Role deleted',
          description: `\`${role.name}\` · ${role.members.size} members had it` +
            `${entry ? ` · by <@${entry.executorId}>` : ''}`,
        }),
      });
    });

    on(Events.GuildRoleUpdate, async (before, after) => {
      const changes: string[] = [];
      if (before.name !== after.name) changes.push(`Name \`${before.name}\` → \`${after.name}\``);
      if (before.hexColor !== after.hexColor) changes.push(`Colour \`${before.hexColor}\` → \`${after.hexColor}\``);
      if (before.hoist !== after.hoist) changes.push(`Displayed separately: ${after.hoist ? 'on' : 'off'}`);
      if (before.permissions.bitfield !== after.permissions.bitfield) {
        const gained = after.permissions.missing(before.permissions.toArray());
        const lost = before.permissions.missing(after.permissions.toArray());
        if (lost.length) changes.push(`Gained ${lost.join(', ')}`);
        if (gained.length) changes.push(`Lost ${gained.join(', ')}`);
      }
      if (!changes.length) return;

      await this.push(after.guild, 'roles', {
        embed: this.embed(after.guild, {
          title: 'Role updated',
          description: `${after}\n${changes.join('\n')}`,
        }),
      });
    });

    /* ------------------------------------------------------------ voice */

    on(Events.VoiceStateUpdate, async (before, after) => {
      const guild = after.guild;
      const who = after.member ?? before.member;
      if (!who) return;

      if (!before.channelId && after.channelId) {
        await this.push(guild, 'voice', {
          embed: this.embed(guild, {
            tone: 'success', title: 'Joined voice',
            description: `${who} joined <#${after.channelId}>`,
          }),
        });
      } else if (before.channelId && !after.channelId) {
        await this.push(guild, 'voice', {
          embed: this.embed(guild, {
            tone: 'danger', title: 'Left voice',
            description: `${who} left <#${before.channelId}>`,
          }),
        });
      } else if (before.channelId !== after.channelId) {
        await this.push(guild, 'voice', {
          embed: this.embed(guild, {
            title: 'Moved voice channel',
            description: `${who} · <#${before.channelId}> → <#${after.channelId}>`,
          }),
        });
      }
    });

    /* ---------------------------------------------------------- invites */

    on(Events.InviteCreate, async (invite) => {
      if (!invite.guild || !('id' in invite.guild)) return;
      const guild = this.client.guilds.cache.get(invite.guild.id);
      if (!guild) return;

      await this.push(guild, 'invites', {
        embed: this.embed(guild, {
          tone: 'success',
          title: 'Invite created',
          description: `\`${invite.code}\` by ${invite.inviter ?? 'someone'} for <#${invite.channelId}>`,
          fields: [
            { name: 'Max uses', value: invite.maxUses ? String(invite.maxUses) : 'Unlimited', inline: true },
            { name: 'Expires', value: invite.expiresAt ? ts(invite.expiresAt) : 'Never', inline: true },
          ],
        }),
      });
    });

    on(Events.InviteDelete, async (invite) => {
      const guild = invite.guild && 'id' in invite.guild
        ? this.client.guilds.cache.get(invite.guild.id) : null;
      if (!guild) return;
      await this.push(guild, 'invites', {
        embed: this.embed(guild, {
          tone: 'danger', title: 'Invite deleted', description: `\`${invite.code}\``,
        }),
      });
    });

    /* ----------------------------------------------- server, emoji, threads */

    on(Events.GuildUpdate, async (before, after) => {
      const changes: string[] = [];
      if (before.name !== after.name) changes.push(`Name \`${before.name}\` → \`${after.name}\``);
      if (before.iconURL() !== after.iconURL()) changes.push('Icon changed');
      if (before.bannerURL() !== after.bannerURL()) changes.push('Banner changed');
      if (before.vanityURLCode !== after.vanityURLCode) {
        changes.push(`Vanity \`${before.vanityURLCode ?? 'none'}\` → \`${after.vanityURLCode ?? 'none'}\``);
      }
      if (before.ownerId !== after.ownerId) changes.push(`Owner <@${before.ownerId}> → <@${after.ownerId}>`);
      if (!changes.length) return;

      await this.push(after, 'server', {
        embed: this.embed(after, { title: 'Server updated', description: changes.join('\n') }),
      });
    });

    on(Events.GuildEmojiCreate, async (emoji) => {
      await this.push(emoji.guild, 'emojis', {
        embed: this.embed(emoji.guild, {
          tone: 'success',
          title: 'Emoji added',
          description: `${emoji} · \`:${emoji.name}:\``,
          thumbnail: emoji.imageURL({ size: 128 }),
        }),
      });
    });

    on(Events.GuildEmojiDelete, async (emoji) => {
      await this.push(emoji.guild, 'emojis', {
        embed: this.embed(emoji.guild, {
          tone: 'danger', title: 'Emoji removed', description: `\`:${emoji.name}:\``,
          thumbnail: emoji.imageURL({ size: 128 }),
        }),
      });
    });

    on(Events.ThreadCreate, async (thread) => {
      await this.push(thread.guild, 'threads', {
        embed: this.embed(thread.guild, {
          tone: 'success',
          title: 'Thread created',
          description: `${thread} in <#${thread.parentId}> by <@${thread.ownerId}>`,
        }),
      });
    });

    on(Events.ThreadDelete, async (thread) => {
      await this.push(thread.guild, 'threads', {
        embed: this.embed(thread.guild, {
          tone: 'danger', title: 'Thread deleted', description: `\`${thread.name}\``,
        }),
      });
    });

    on(Events.WebhooksUpdate, async (channel) => {
      const entry = await this.actorEntry(channel.guild, AuditLogEvent.WebhookCreate);
      await this.push(channel.guild, 'webhooks', {
        embed: this.embed(channel.guild, {
          tone: 'warn',
          title: 'Webhooks changed',
          description: `In ${channel}${entry ? ` · by <@${entry.executorId}>` : ''}.` +
            '\nWebhooks can post as anyone, so this is worth a look.',
        }),
      });
    });

    on(Events.AutoModerationActionExecution, async (execution) => {
      await this.push(execution.guild, 'automod', {
        embed: this.embed(execution.guild, {
          tone: 'warn',
          title: 'AutoMod triggered',
          description: `<@${execution.userId}> in <#${execution.channelId}>`,
          fields: [
            { name: 'Rule', value: execution.ruleTriggerType ? String(execution.ruleTriggerType) : 'Unknown', inline: true },
            ...(execution.matchedKeyword ? [{ name: 'Matched', value: `\`${execution.matchedKeyword}\`` }] : []),
            ...(execution.content ? [{ name: 'Content', value: clip(execution.content) }] : []),
          ],
        }),
      });
    });

    on(Events.MessageReactionRemoveAll, async (message) => {
      if (!message.inGuild()) return;
      await this.push(message.guild, 'reactions', {
        embed: this.embed(message.guild, {
          tone: 'warn',
          title: 'All reactions cleared',
          description: `On a message in <#${message.channelId}> · [jump](${message.url})`,
        }),
      });
    });

    // Global username and avatar changes, mirrored into every shared guild.
    on(Events.UserUpdate, async (before, after) => {
      if (before.avatar === after.avatar && before.username === after.username) return;

      for (const guild of this.client.guilds.cache.values()) {
        if (!guild.members.cache.has(after.id)) continue;
        const avatarChanged = before.avatar !== after.avatar;

        await this.push(guild, avatarChanged ? 'avatars' : 'members', {
          embed: this.embed(guild, {
            title: avatarChanged ? 'Avatar changed' : 'Username changed',
            description: `${after} · \`${after.id}\``,
            thumbnail: after.displayAvatarURL({ size: 256 }),
            fields: avatarChanged ? [] : [
              { name: 'Before', value: `\`${before.username}\``, inline: true },
              { name: 'After', value: `\`${after.username}\``, inline: true },
            ],
          }),
        });
      }
    });
  }

  /* ------------------------------------------------- message deletion */

  private async messageDeleted(message: Message<true> | PartialMessage): Promise<void> {
    if (!message.guild) return;
    if (message.partial) return; // Nothing useful survives an uncached delete.
    if (await this.ignored(message.guild.id, message.channelId, message.author.id,
      message.member?.roles.cache.keys())) return;

    const settings = await this.settings(message.guild.id);
    if (settings.ignoreBots && message.author.bot) return;

    const entry = await this.actorEntry(message.guild, AuditLogEvent.MessageDelete, message.author.id);
    const images = message.attachments.filter(isImage);

    await this.push(message.guild, 'messages', {
      embed: this.embed(message.guild, {
        tone: 'danger',
        title: 'Message deleted',
        description: `${message.author} in <#${message.channelId}>` +
          `${entry ? ` · deleted by <@${entry.executorId}>` : ''}`,
        fields: [
          { name: 'Content', value: clip(message.content) },
          ...(message.attachments.size
            ? [{ name: 'Attachments', value: message.attachments.map((a) => a.name).join(', ') }]
            : []),
        ],
      }),
    });

    // Images get their own entry so an image log can exist without a message log.
    if (images.size) {
      await this.push(message.guild, 'images', {
        embed: this.embed(message.guild, {
          tone: 'danger',
          title: `${images.size} image${images.size === 1 ? '' : 's'} deleted`,
          description: `${message.author} in <#${message.channelId}>`,
          image: settings.mirrorAttachments ? undefined : images.first()!.url,
        }),
        // Mirroring re-uploads the bytes, because the CDN link dies within
        // minutes of the delete and a log of dead links is not a log.
        files: settings.mirrorAttachments ? images.map((a) => a.url).slice(0, 4) : undefined,
      });
    }
  }

  /* ------------------------------------------------------- config reads */

  private async target(guildId: string, category: LogCategory): Promise<Target | null> {
    const rows = await remember(`bounty:log:cfg:${guildId}`, TTL.guildConfig, async () =>
      db.select().from(schema.logChannels).where(eq(schema.logChannels.guildId, guildId)));

    const row = rows.find((r) => r.category === category && r.enabled);
    return row
      ? { channelId: row.channelId, webhookId: row.webhookId, webhookToken: row.webhookToken }
      : null;
  }

  private async settings(guildId: string) {
    return remember(`bounty:log:set:${guildId}`, TTL.guildConfig, async () => {
      const [row] = await db.select().from(schema.logSettings)
        .where(eq(schema.logSettings.guildId, guildId)).limit(1);
      return row ?? {
        guildId, ignoredChannelIds: [], ignoredUserIds: [], ignoredRoleIds: [],
        ignoreBots: true, mirrorAttachments: true,
      };
    });
  }

  private async ignored(
    guildId: string, channelId: string, userId: string,
    roleIds?: IterableIterator<string>,
  ): Promise<boolean> {
    const settings = await this.settings(guildId);
    if (settings.ignoredChannelIds.includes(channelId)) return true;
    if (settings.ignoredUserIds.includes(userId)) return true;
    if (roleIds && settings.ignoredRoleIds.length) {
      for (const id of roleIds) if (settings.ignoredRoleIds.includes(id)) return true;
    }
    return false;
  }

  static invalidate(guildId: string) {
    return forget(`bounty:log:cfg:${guildId}`, `bounty:log:set:${guildId}`);
  }

  /* --------------------------------------------------- audit log lookup */

  /**
   * Audit log entries appear a beat after the gateway event and are rate
   * limited, so results are cached briefly and only entries from the last
   * few seconds are trusted — an older one belongs to a different action.
   */
  private async actorEntry(
    guild: Guild,
    type: AuditLogEvent,
    targetId?: string,
  ): Promise<{ executorId: string; reason: string | null } | null> {
    if (!guild.members.me?.permissions.has(PermissionFlagsBits.ViewAuditLog)) return null;

    const cacheKey = `bounty:audit:${guild.id}:${type}:${targetId ?? 'any'}`;
    try {
      const hit = await redis.get(cacheKey);
      if (hit) return JSON.parse(hit) as { executorId: string; reason: string | null };
    } catch { /* fall through to a live fetch */ }

    const logs = await guild.fetchAuditLogs({ type, limit: 6 }).catch(() => null);
    if (!logs) return null;

    const entry = logs.entries.find((e: GuildAuditLogsEntry) => {
      if (Date.now() - e.createdTimestamp > 8000) return false;
      if (!targetId) return true;
      return (e.target as { id?: string } | null)?.id === targetId ||
        e.targetId === targetId;
    });

    if (!entry?.executorId) return null;
    const result = { executorId: entry.executorId, reason: entry.reason ?? null };
    await redis.set(cacheKey, JSON.stringify(result), 'EX', 10).catch(() => undefined);
    return result;
  }

  private async actor(guild: Guild, type: AuditLogEvent, targetId?: string): Promise<string | null> {
    const entry = await this.actorEntry(guild, type, targetId);
    return entry ? `<@${entry.executorId}>` : null;
  }

  /* ------------------------------------------------------------ delivery */

  private embed(guild: Guild, opts: Parameters<typeof buildEmbed>[1]): EmbedBuilder {
    return buildEmbed({}, {
      color: opts.tone ? undefined : PALETTE.violet,
      footer: guild.name,
      ...opts,
    });
  }

  /** Queues an entry and schedules the flush. Never throws into an event. */
  private async push(guild: Guild, category: LogCategory, entry: Queued): Promise<void> {
    const target = await this.target(guild.id, category);
    if (!target) return;

    const queue = this.queues.get(target.channelId) ?? [];
    queue.push(entry);
    this.queues.set(target.channelId, queue);

    // Files cannot be batched safely, and a full batch should go immediately.
    if (entry.files?.length || queue.length >= MAX_EMBEDS) {
      await this.flush(guild, target);
      return;
    }

    if (!this.timers.has(target.channelId)) {
      const timer = setTimeout(() => {
        void this.flush(guild, target).catch((err) =>
          logger.warn({ err, channelId: target.channelId }, 'log flush failed'));
      }, FLUSH_MS);
      timer.unref();
      this.timers.set(target.channelId, timer);
    }
  }

  private async flush(guild: Guild, target: Target): Promise<void> {
    const timer = this.timers.get(target.channelId);
    if (timer) { clearTimeout(timer); this.timers.delete(target.channelId); }

    const queue = this.queues.get(target.channelId);
    if (!queue?.length) return;
    this.queues.set(target.channelId, []);

    const batch = queue.splice(0, MAX_EMBEDS);
    if (queue.length) this.queues.set(target.channelId, queue);

    const files = batch.flatMap((e) => e.files ?? []);
    const embeds = batch.map((e) => e.embed);

    // A webhook has its own rate limit bucket, which is why logging prefers it.
    if (target.webhookId && target.webhookToken) {
      const client = this.webhook(target);
      const ok = await client.send({ embeds, files }).then(() => true).catch(() => false);
      if (ok) return;
      // Webhook was deleted by hand. Drop it and fall back to the channel.
      this.webhooks.delete(target.webhookId);
      await db.update(schema.logChannels)
        .set({ webhookId: null, webhookToken: null })
        .where(and(
          eq(schema.logChannels.guildId, guild.id),
          eq(schema.logChannels.channelId, target.channelId),
        )).catch(() => undefined);
      await LoggingEngine.invalidate(guild.id);
    }

    const channel = guild.channels.cache.get(target.channelId) as GuildTextBasedChannel | undefined;
    if (!channel) return;

    await channel.send({ embeds, files }).catch((err) => {
      logger.warn({ err, channelId: target.channelId }, 'could not deliver logs');
    });
  }

  private webhook(target: Target): WebhookClient {
    const existing = this.webhooks.get(target.webhookId!);
    if (existing) return existing;
    const client = new WebhookClient({ id: target.webhookId!, token: target.webhookToken! });
    this.webhooks.set(target.webhookId!, client);
    return client;
  }
}

/* ------------------------------------------------------------- helpers */

const IMAGE = /\.(png|jpe?g|gif|webp|bmp|avif)(\?|$)/i;
const isImage = (a: Attachment) => a.contentType?.startsWith('image/') || IMAGE.test(a.url);

function clip(text: string | null | undefined, max = 1000): string {
  if (!text) return '*empty*';
  const safe = text.replace(/```/g, "'''");
  return safe.length > max ? `${safe.slice(0, max)}…` : safe;
}

function summariseAuthors(ids: Array<string | undefined>): string {
  const counts = new Map<string, number>();
  for (const id of ids) {
    if (!id) continue;
    counts.set(id, (counts.get(id) ?? 0) + 1);
  }
  const top = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5);
  return top.map(([id, n]) => `<@${id}> ×${n}`).join('\n') || 'Unknown';
}
