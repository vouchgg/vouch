import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { BountyClient } from './core/client.js';
import { registerMessageDispatcher } from './events/messageCreate.js';
import { registerInteractionRouter } from './events/interactionCreate.js';
import { registerGuildCreate } from './events/guildCreate.js';
import { startWebhookEvents } from './modules/onboarding/webhookEvents.js';
import { VoiceMasterEngine } from './modules/voicemaster/engine.js';
import { LoggingEngine } from './modules/logging/engine.js';
import { GreetingEngine } from './modules/greetings/engine.js';
import { InviteEngine } from './modules/invites/engine.js';
import { refreshCounters } from './modules/stats/commands/stats.js';
import { registerVoiceInterface } from './modules/voicemaster/interface.js';
import { runMigrations, shutdownDb } from './db/index.js';
import { shutdownCache } from './core/cache.js';
import { logger } from './core/logger.js';

const here = path.dirname(fileURLToPath(import.meta.url));

const client = new BountyClient();

async function main(): Promise<void> {
  // Before anything touches the database.
  await runMigrations();

  await client.commands.loadAll(path.join(here, 'modules'));

  client.voicemaster = new VoiceMasterEngine(client);
  client.voicemaster.attach();
  registerVoiceInterface(client, client.voicemaster);

  client.logging = new LoggingEngine(client);
  client.logging.attach();

  // Order matters. Invite tracking must register its member listener first so
  // the greeting engine can wait on the attribution it starts.
  client.inviteTracking = new InviteEngine(client);
  client.inviteTracking.attach();

  client.greetings = new GreetingEngine(client);
  client.greetings.attach();

  // Counter channels refresh on a timer; Discord caps renames at 2 per 10 min.
  setInterval(() => void refreshCounters(client).catch(() => undefined), 10 * 60_000).unref();

  registerMessageDispatcher(client);
  registerInteractionRouter(client);
  registerGuildCreate(client);

  // Account installs arrive over HTTP, not the gateway.
  startWebhookEvents(client);

  client.once('ready', (ready) => {
    logger.info({ user: ready.user.tag, guilds: ready.guilds.cache.size }, 'bounty online');
  });

  await client.login(process.env.DISCORD_TOKEN);
}

/* Nothing here should ever take the process down silently. */
process.on('unhandledRejection', (err) => logger.error({ err }, 'unhandled rejection'));
process.on('uncaughtException', (err) => {
  logger.fatal({ err }, 'uncaught exception');
  void shutdown(1);
});

for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.on(signal, () => void shutdown(0));
}

async function shutdown(code: number): Promise<void> {
  logger.info('shutting down');
  // Destroy the gateway first so no new work arrives mid-teardown.
  client.destroy();
  await Promise.allSettled([shutdownDb(), shutdownCache()]);
  process.exit(code);
}

void main().catch((err) => {
  logger.fatal({ err }, 'startup failed');
  process.exit(1);
});
