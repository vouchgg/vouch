/**
 * Bounty — PostgreSQL schema (Drizzle ORM)
 *
 * Conventions
 *  - Discord snowflakes are stored as `varchar(20)`, never bigint. JS numbers
 *    cannot hold a snowflake and `bigint` mode in node-postgres returns strings
 *    anyway, so we skip the round trip.
 *  - Every table that is read on a hot path (voice joins, message dispatch)
 *    has an explicit covering index. Nothing here relies on a sequential scan.
 *  - Deletes cascade from guild → child rows, so a guild removal cleans itself.
 *
 * Generate SQL with:  npx drizzle-kit generate
 */

import {
  pgTable, pgEnum, varchar, text, integer, smallint, boolean, timestamp,
  jsonb, index, uniqueIndex, primaryKey, serial, bigserial,
} from 'drizzle-orm/pg-core';
import { sql } from 'drizzle-orm';

/* ------------------------------------------------------------------ enums */

export const nameChangeType = pgEnum('name_change_type', ['username', 'global_name', 'nickname']);
export const assetType = pgEnum('asset_type', ['avatar', 'banner', 'guild_avatar']);
export const ticketStatus = pgEnum('ticket_status', ['open', 'claimed', 'closed', 'deleted']);
export const giveawayStatus = pgEnum('giveaway_status', ['running', 'ended', 'cancelled']);
export const customBotStatus = pgEnum('custom_bot_status', ['offline', 'starting', 'online', 'invalid_token', 'suspended']);
export const activityType = pgEnum('activity_type', ['playing', 'listening', 'watching', 'competing', 'streaming']);
export const presenceStatus = pgEnum('presence_status', ['online', 'idle', 'dnd', 'invisible']);

/* ----------------------------------------------------------------- guilds */

export const guilds = pgTable('guilds', {
  id: varchar('id', { length: 20 }).primaryKey(),
  prefix: varchar('prefix', { length: 8 }).notNull().default(','),
  /** Hex without the leading '#'. Drives every embed the bot sends here. */
  embedColor: varchar('embed_color', { length: 6 }).notNull().default('5B2E9D'),
  footerText: varchar('footer_text', { length: 128 }),
  footerIconUrl: text('footer_icon_url'),
  /** 'relative' | 'short' | 'long' | 'none' — how command footers render time. */
  timestampStyle: varchar('timestamp_style', { length: 16 }).notNull().default('relative'),
  locale: varchar('locale', { length: 8 }).notNull().default('en-GB'),
  premiumUntil: timestamp('premium_until', { withTimezone: true }),
  blacklisted: boolean('blacklisted').notNull().default(false),
  blacklistReason: text('blacklist_reason'),
  /** Module kill switches: { voicemaster: true, tickets: false, ... } */
  disabledModules: jsonb('disabled_modules').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  /** Per-command disables, and per-channel command locks. */
  commandOverrides: jsonb('command_overrides')
    .$type<Record<string, { disabled?: boolean; channels?: string[]; roles?: string[] }>>()
    .notNull().default(sql`'{}'::jsonb`),
  joinedAt: timestamp('joined_at', { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ users */

export const users = pgTable('users', {
  id: varchar('id', { length: 20 }).primaryKey(),
  /** Personal embed accent, overrides the guild colour when set. */
  embedColor: varchar('embed_color', { length: 6 }),
  lastfmUsername: varchar('lastfm_username', { length: 64 }),
  lastfmSessionKey: text('lastfm_session_key'),
  /** bounty.lol/@slug */
  bioSlug: varchar('bio_slug', { length: 32 }),
  timezone: varchar('timezone', { length: 48 }),
  blacklisted: boolean('blacklisted').notNull().default(false),
  blacklistReason: text('blacklist_reason'),
  /** Opt out of avatar/name history collection entirely. */
  historyOptOut: boolean('history_opt_out').notNull().default(false),
  firstSeenAt: timestamp('first_seen_at', { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt: timestamp('last_seen_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  bioSlugIdx: uniqueIndex('users_bio_slug_idx').on(t.bioSlug),
  lastfmIdx: index('users_lastfm_idx').on(t.lastfmUsername),
}));

/* --------------------------------------------------- asset & name history */

/**
 * One row per distinct asset a user has worn. `hash` is Discord's CDN hash, so
 * re-uploading the same image does not create a duplicate row — the unique
 * index absorbs it and we only bump `lastSeenAt`.
 */
export const assetHistory = pgTable('asset_history', {
  id: bigserial('id', { mode: 'number' }).primaryKey(),
  userId: varchar('user_id', { length: 20 }).notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  type: assetType('type').notNull(),
  /** Null for guild-scoped assets that belong to every guild. */
  guildId: varchar('guild_id', { length: 20 }),
  hash: varchar('hash', { length: 64 }).notNull(),
  /** Our own mirrored copy — Discord purges old CDN objects. */
  storedUrl: text('stored_url').notNull(),
  animated: boolean('animated').notNull().default(false),
  /** Dominant colour of the image, used to tint the history embed. */
  accentColor: varchar('accent_color', { length: 6 }),
  firstSeenAt: timestamp('first_seen_at', { withTimezone: true }).notNull().defaultNow(),
  lastSeenAt: timestamp('last_seen_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  uniq: uniqueIndex('asset_history_uniq').on(t.userId, t.type, t.hash),
  // The exact shape of `,avatarhistory` — newest first, one user, one type.
  lookupIdx: index('asset_history_lookup_idx').on(t.userId, t.type, t.firstSeenAt.desc()),
}));

export const nameHistory = pgTable('name_history', {
  id: bigserial('id', { mode: 'number' }).primaryKey(),
  userId: varchar('user_id', { length: 20 }).notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  type: nameChangeType('type').notNull(),
  /** Set for nickname changes only. */
  guildId: varchar('guild_id', { length: 20 }),
  previousValue: varchar('previous_value', { length: 64 }),
  newValue: varchar('new_value', { length: 64 }),
  changedAt: timestamp('changed_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  lookupIdx: index('name_history_lookup_idx').on(t.userId, t.changedAt.desc()),
  guildIdx: index('name_history_guild_idx').on(t.guildId, t.userId),
}));

/* ------------------------------------------------------------ voicemaster */

export const vmConfigs = pgTable('vm_configs', {
  guildId: varchar('guild_id', { length: 20 }).primaryKey()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  /** The "Join to Create" channel. */
  generatorChannelId: varchar('generator_channel_id', { length: 20 }).notNull(),
  categoryId: varchar('category_id', { length: 20 }).notNull(),
  interfaceChannelId: varchar('interface_channel_id', { length: 20 }),
  interfaceMessageId: varchar('interface_message_id', { length: 20 }),
  /** Supports {user}, {user.name}, {count}, {game}. */
  nameTemplate: varchar('name_template', { length: 64 }).notNull().default("{user}'s channel"),
  defaultLimit: smallint('default_limit').notNull().default(0),
  defaultBitrate: integer('default_bitrate').notNull().default(64000),
  defaultRegion: varchar('default_region', { length: 24 }),
  /** Grace period before an empty channel is destroyed. Stops join flicker. */
  emptyGraceSeconds: smallint('empty_grace_seconds').notNull().default(5),
  /** Hand the channel to the longest-present member instead of leaving it claimable. */
  autoTransferOwner: boolean('auto_transfer_owner').notNull().default(false),
  /** Restore each user's lock/hide/limit next time they spawn a channel. */
  persistUserSettings: boolean('persist_user_settings').notNull().default(true),
  enabled: boolean('enabled').notNull().default(true),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  generatorIdx: uniqueIndex('vm_configs_generator_idx').on(t.generatorChannelId),
}));

/** Live temporary channels. Rows are deleted the moment the channel dies. */
export const vmChannels = pgTable('vm_channels', {
  channelId: varchar('channel_id', { length: 20 }).primaryKey(),
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  ownerId: varchar('owner_id', { length: 20 }).notNull(),
  /** True once the owner has left — enables `,vc claim`. */
  claimable: boolean('claimable').notNull().default(false),
  locked: boolean('locked').notNull().default(false),
  hidden: boolean('hidden').notNull().default(false),
  trustedIds: jsonb('trusted_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
  lastEmptyAt: timestamp('last_empty_at', { withTimezone: true }),
}, (t) => ({
  guildIdx: index('vm_channels_guild_idx').on(t.guildId),
  ownerIdx: index('vm_channels_owner_idx').on(t.guildId, t.ownerId),
}));

/** Remembered preferences so a user's next channel comes back the way they left it. */
export const vmUserSettings = pgTable('vm_user_settings', {
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  userId: varchar('user_id', { length: 20 }).notNull(),
  name: varchar('name', { length: 100 }),
  userLimit: smallint('user_limit'),
  bitrate: integer('bitrate'),
  region: varchar('region', { length: 24 }),
  locked: boolean('locked').notNull().default(false),
  hidden: boolean('hidden').notNull().default(false),
  permittedIds: jsonb('permitted_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  rejectedIds: jsonb('rejected_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  pk: primaryKey({ columns: [t.guildId, t.userId] }),
}));

/* ---------------------------------------------------------------- tickets */

export const ticketPanels = pgTable('ticket_panels', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  channelId: varchar('channel_id', { length: 20 }).notNull(),
  messageId: varchar('message_id', { length: 20 }),
  title: varchar('title', { length: 256 }).notNull().default('Support'),
  description: text('description'),
  color: varchar('color', { length: 6 }),
  /** Where opened tickets are created. */
  categoryId: varchar('category_id', { length: 20 }),
  transcriptChannelId: varchar('transcript_channel_id', { length: 20 }),
  supportRoleIds: jsonb('support_role_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  /** Supports {user}, {number}, {topic}. */
  channelNameTemplate: varchar('channel_name_template', { length: 64 }).notNull().default('ticket-{number}'),
  /** One dropdown entry per topic, each with its own greeting and modal fields. */
  options: jsonb('options').$type<Array<{
    value: string; label: string; description?: string; emoji?: string;
    categoryId?: string; supportRoleIds?: string[]; greeting?: string;
    modalFields?: Array<{ id: string; label: string; style: 'short' | 'paragraph'; required: boolean; maxLength?: number }>;
  }>>().notNull().default(sql`'[]'::jsonb`),
  /** Tickets open per user at once, across this panel. */
  perUserLimit: smallint('per_user_limit').notNull().default(1),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  guildIdx: index('ticket_panels_guild_idx').on(t.guildId),
  messageIdx: uniqueIndex('ticket_panels_message_idx').on(t.messageId),
}));

export const tickets = pgTable('tickets', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  panelId: integer('panel_id').references(() => ticketPanels.id, { onDelete: 'set null' }),
  channelId: varchar('channel_id', { length: 20 }).notNull(),
  /** Per-guild incrementing display number, not the serial id. */
  number: integer('number').notNull(),
  ownerId: varchar('owner_id', { length: 20 }).notNull(),
  claimedBy: varchar('claimed_by', { length: 20 }),
  topic: varchar('topic', { length: 64 }),
  /** Answers to the panel's modal, keyed by field id. */
  formResponses: jsonb('form_responses').$type<Record<string, string>>(),
  addedUserIds: jsonb('added_user_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  status: ticketStatus('status').notNull().default('open'),
  transcriptUrl: text('transcript_url'),
  messageCount: integer('message_count').notNull().default(0),
  openedAt: timestamp('opened_at', { withTimezone: true }).notNull().defaultNow(),
  closedAt: timestamp('closed_at', { withTimezone: true }),
  closedBy: varchar('closed_by', { length: 20 }),
  closeReason: text('close_reason'),
}, (t) => ({
  channelIdx: uniqueIndex('tickets_channel_idx').on(t.channelId),
  numberIdx: uniqueIndex('tickets_number_idx').on(t.guildId, t.number),
  openByUserIdx: index('tickets_open_by_user_idx').on(t.guildId, t.ownerId, t.status),
}));

/* -------------------------------------------------------------- giveaways */

export const giveaways = pgTable('giveaways', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  channelId: varchar('channel_id', { length: 20 }).notNull(),
  messageId: varchar('message_id', { length: 20 }).notNull(),
  hostId: varchar('host_id', { length: 20 }).notNull(),
  prize: varchar('prize', { length: 256 }).notNull(),
  description: text('description'),
  winnerCount: smallint('winner_count').notNull().default(1),
  /**
   * Entry gates. Everything is optional and evaluated on button press:
   * roles the member must hold, roles that block entry, bonus entries per
   * role, minimum account/join age, boost requirement.
   */
  requirements: jsonb('requirements').$type<{
    requiredRoleIds?: string[];
    blockedRoleIds?: string[];
    bonusEntries?: Record<string, number>;
    minAccountAgeDays?: number;
    minJoinAgeDays?: number;
    requireBoost?: boolean;
    minMessages?: number;
  }>().notNull().default(sql`'{}'::jsonb`),
  status: giveawayStatus('status').notNull().default('running'),
  winnerIds: jsonb('winner_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  entryCount: integer('entry_count').notNull().default(0),
  endsAt: timestamp('ends_at', { withTimezone: true }).notNull(),
  endedAt: timestamp('ended_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  messageIdx: uniqueIndex('giveaways_message_idx').on(t.messageId),
  // The scheduler's only query: what is due, soonest first.
  dueIdx: index('giveaways_due_idx').on(t.status, t.endsAt),
  guildIdx: index('giveaways_guild_idx').on(t.guildId, t.status),
}));

export const giveawayEntries = pgTable('giveaway_entries', {
  giveawayId: integer('giveaway_id').notNull()
    .references(() => giveaways.id, { onDelete: 'cascade' }),
  userId: varchar('user_id', { length: 20 }).notNull(),
  /** Weight from bonus roles — a 3-entry member appears three times in the draw. */
  weight: smallint('weight').notNull().default(1),
  enteredAt: timestamp('entered_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  pk: primaryKey({ columns: [t.giveawayId, t.userId] }),
}));

/* ------------------------------------------------------------ custom bots */

export const customBots = pgTable('custom_bots', {
  id: serial('id').primaryKey(),
  ownerId: varchar('owner_id', { length: 20 }).notNull()
    .references(() => users.id, { onDelete: 'cascade' }),
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  /**
   * AES-256-GCM ciphertext. The plaintext token never touches this table, the
   * logs, or an embed — `,bot host` deletes the invoking message on sight.
   */
  tokenCiphertext: text('token_ciphertext').notNull(),
  tokenIv: varchar('token_iv', { length: 32 }).notNull(),
  tokenAuthTag: varchar('token_auth_tag', { length: 32 }).notNull(),
  /** Fingerprint for dedupe without decrypting: sha256(token). */
  tokenFingerprint: varchar('token_fingerprint', { length: 64 }).notNull(),
  applicationId: varchar('application_id', { length: 20 }),
  botUserId: varchar('bot_user_id', { length: 20 }),
  botUsername: varchar('bot_username', { length: 32 }),
  prefix: varchar('prefix', { length: 8 }).notNull().default(','),
  status: customBotStatus('status').notNull().default('offline'),
  activityKind: activityType('activity_kind'),
  activityText: varchar('activity_text', { length: 128 }),
  streamUrl: text('stream_url'),
  presence: presenceStatus('presence').notNull().default('online'),
  /** Which worker process currently owns this instance. */
  workerId: varchar('worker_id', { length: 64 }),
  lastStartedAt: timestamp('last_started_at', { withTimezone: true }),
  lastError: text('last_error'),
  restartCount: integer('restart_count').notNull().default(0),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  fingerprintIdx: uniqueIndex('custom_bots_fingerprint_idx').on(t.tokenFingerprint),
  guildIdx: uniqueIndex('custom_bots_guild_idx').on(t.guildId),
  workerIdx: index('custom_bots_worker_idx').on(t.workerId, t.status),
}));

/* --------------------------------------------------------- booster roles */

export const boosterRoles = pgTable('booster_roles', {
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  userId: varchar('user_id', { length: 20 }).notNull(),
  roleId: varchar('role_id', { length: 20 }).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  pk: primaryKey({ columns: [t.guildId, t.userId] }),
  roleIdx: uniqueIndex('booster_roles_role_idx').on(t.roleId),
}));

/* ------------------------------------------------------- command aliases */

/** Backs `,alias add avh avatarhistory` — merged into the resolver at dispatch. */
export const commandAliases = pgTable('command_aliases', {
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  alias: varchar('alias', { length: 32 }).notNull(),
  /** Full command path plus any baked-in arguments: "purge bots 50". */
  target: varchar('target', { length: 128 }).notNull(),
  createdBy: varchar('created_by', { length: 20 }).notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  pk: primaryKey({ columns: [t.guildId, t.alias] }),
}));

/* ------------------------------------------------------------------ types */

export type Guild = typeof guilds.$inferSelect;
export type User = typeof users.$inferSelect;
export type VmConfig = typeof vmConfigs.$inferSelect;
export type VmChannel = typeof vmChannels.$inferSelect;
export type VmUserSettings = typeof vmUserSettings.$inferSelect;
export type Ticket = typeof tickets.$inferSelect;
export type TicketPanel = typeof ticketPanels.$inferSelect;
export type Giveaway = typeof giveaways.$inferSelect;
export type CustomBot = typeof customBots.$inferSelect;

/* ================================================================ logging */

export const logCategory = pgEnum('log_category', [
  'messages', 'images', 'members', 'moderation', 'roles', 'channels',
  'voice', 'invites', 'server', 'emojis', 'threads', 'webhooks',
  'boosts', 'automod', 'bots', 'nicknames', 'avatars', 'reactions',
]);

/** One row per category a guild logs. Absent row means that category is off. */
export const logChannels = pgTable('log_channels', {
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  category: logCategory('category').notNull(),
  channelId: varchar('channel_id', { length: 20 }).notNull(),
  enabled: boolean('enabled').notNull().default(true),
  /** Webhook used instead of the bot user, so logs keep posting under load. */
  webhookId: varchar('webhook_id', { length: 20 }),
  webhookToken: text('webhook_token'),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  pk: primaryKey({ columns: [t.guildId, t.category] }),
  guildIdx: index('log_channels_guild_idx').on(t.guildId),
}));

export const logSettings = pgTable('log_settings', {
  guildId: varchar('guild_id', { length: 20 }).primaryKey()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  ignoredChannelIds: jsonb('ignored_channel_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  ignoredUserIds: jsonb('ignored_user_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  ignoredRoleIds: jsonb('ignored_role_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  /** Bots are noisy; most servers want them out of the message log. */
  ignoreBots: boolean('ignore_bots').notNull().default(true),
  /** Re-upload deleted attachments so the log survives the CDN purge. */
  mirrorAttachments: boolean('mirror_attachments').notNull().default(true),
});

/* ============================================================== greetings */

export const greetKind = pgEnum('greet_kind', ['welcome', 'goodbye', 'boost']);

/** Welcome, goodbye and boost cards share a shape, so they share a table. */
export const greetConfigs = pgTable('greet_configs', {
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  kind: greetKind('kind').notNull(),
  channelId: varchar('channel_id', { length: 20 }),
  /** Plain text above the embed. Supports every {variable}. */
  content: text('content'),
  /** Raw embed JSON from the builder, rendered after variable substitution. */
  embedJson: jsonb('embed_json').$type<Record<string, unknown>>(),
  /** Delete the card after N seconds. 0 keeps it. */
  deleteAfter: smallint('delete_after').notNull().default(0),
  dmEnabled: boolean('dm_enabled').notNull().default(false),
  dmContent: text('dm_content'),
  /** Roles handed out on join. Ignored for goodbye. */
  autoRoleIds: jsonb('auto_role_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  enabled: boolean('enabled').notNull().default(true),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  pk: primaryKey({ columns: [t.guildId, t.kind] }),
}));

/* ================================================================ invites */

/** Mirror of the guild's invite list, refreshed on boot and on every change. */
export const inviteCodes = pgTable('invite_codes', {
  code: varchar('code', { length: 32 }).primaryKey(),
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  inviterId: varchar('inviter_id', { length: 20 }),
  channelId: varchar('channel_id', { length: 20 }),
  uses: integer('uses').notNull().default(0),
  maxUses: integer('max_uses').notNull().default(0),
  expiresAt: timestamp('expires_at', { withTimezone: true }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  guildIdx: index('invite_codes_guild_idx').on(t.guildId),
  inviterIdx: index('invite_codes_inviter_idx').on(t.guildId, t.inviterId),
}));

/**
 * Who invited whom. `valid` goes false when the member leaves, which is how
 * the leaderboard separates real invites from a revolving door.
 */
export const inviteAttribution = pgTable('invite_attribution', {
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  userId: varchar('user_id', { length: 20 }).notNull(),
  inviterId: varchar('inviter_id', { length: 20 }),
  code: varchar('code', { length: 32 }),
  /** Account younger than the guild's threshold when it joined. */
  fake: boolean('fake').notNull().default(false),
  valid: boolean('valid').notNull().default(true),
  /** Counts rejoins, so leaving and returning does not farm the leaderboard. */
  rejoins: smallint('rejoins').notNull().default(0),
  joinedAt: timestamp('joined_at', { withTimezone: true }).notNull().defaultNow(),
  leftAt: timestamp('left_at', { withTimezone: true }),
}, (t) => ({
  pk: primaryKey({ columns: [t.guildId, t.userId] }),
  // The leaderboard query: one guild, grouped by inviter.
  leaderboardIdx: index('invite_attribution_leaderboard_idx').on(t.guildId, t.inviterId, t.valid),
}));

/** Manual adjustments from `,invites add` and `,invites remove`. */
export const inviteAdjustments = pgTable('invite_adjustments', {
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  userId: varchar('user_id', { length: 20 }).notNull(),
  bonus: integer('bonus').notNull().default(0),
}, (t) => ({ pk: primaryKey({ columns: [t.guildId, t.userId] }) }));

export const inviteRewards = pgTable('invite_rewards', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  threshold: integer('threshold').notNull(),
  roleId: varchar('role_id', { length: 20 }).notNull(),
}, (t) => ({
  guildIdx: index('invite_rewards_guild_idx').on(t.guildId, t.threshold),
}));

/* ================================================================== stats */

export const memberEventKind = pgEnum('member_event_kind', ['join', 'leave']);

/**
 * Append-only join/leave ledger. Everything `,joins today`, `,growth` and the
 * member graph need comes from counting rows in a time window.
 */
export const memberEvents = pgTable('member_events', {
  id: bigserial('id', { mode: 'number' }).primaryKey(),
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  userId: varchar('user_id', { length: 20 }).notNull(),
  kind: memberEventKind('kind').notNull(),
  /** Member count immediately after the event, for the growth line. */
  memberCount: integer('member_count'),
  at: timestamp('at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  windowIdx: index('member_events_window_idx').on(t.guildId, t.at),
}));

export const counterKind = pgEnum('counter_kind', [
  'members', 'humans', 'bots', 'boosters', 'online', 'channels', 'roles', 'joins_today',
]);

/** Voice or category channels renamed on a schedule to show a live number. */
export const counterChannels = pgTable('counter_channels', {
  channelId: varchar('channel_id', { length: 20 }).primaryKey(),
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  kind: counterKind('kind').notNull(),
  /** Supports {count}. Renames are throttled to Discord's 2 per 10 minutes. */
  template: varchar('template', { length: 64 }).notNull().default('Members: {count}'),
  lastValue: integer('last_value'),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({ guildIdx: index('counter_channels_guild_idx').on(t.guildId) }));

/* ============================================================ moderation */

export const caseKind = pgEnum('case_kind', [
  'ban', 'unban', 'softban', 'kick', 'timeout', 'untimeout',
  'jail', 'unjail', 'warn', 'unwarn', 'purge', 'lockdown',
]);

/** Every moderation action gets a numbered case, per guild. */
export const modCases = pgTable('mod_cases', {
  id: serial('id').primaryKey(),
  guildId: varchar('guild_id', { length: 20 }).notNull()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  caseNumber: integer('case_number').notNull(),
  kind: caseKind('kind').notNull(),
  targetId: varchar('target_id', { length: 20 }).notNull(),
  moderatorId: varchar('moderator_id', { length: 20 }).notNull(),
  reason: text('reason'),
  /** Roles stripped by jail, so unjail can put them back. */
  restoreRoleIds: jsonb('restore_role_ids').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
  /** Set for timeouts, jails and temp bans. */
  expiresAt: timestamp('expires_at', { withTimezone: true }),
  active: boolean('active').notNull().default(true),
  logMessageId: varchar('log_message_id', { length: 20 }),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
}, (t) => ({
  numberIdx: uniqueIndex('mod_cases_number_idx').on(t.guildId, t.caseNumber),
  targetIdx: index('mod_cases_target_idx').on(t.guildId, t.targetId),
  // The unjail/untimeout scheduler reads exactly this.
  dueIdx: index('mod_cases_due_idx').on(t.active, t.expiresAt),
}));

export const guildModeration = pgTable('guild_moderation', {
  guildId: varchar('guild_id', { length: 20 }).primaryKey()
    .references(() => guilds.id, { onDelete: 'cascade' }),
  jailRoleId: varchar('jail_role_id', { length: 20 }),
  jailChannelId: varchar('jail_channel_id', { length: 20 }),
  muteRoleId: varchar('mute_role_id', { length: 20 }),
  /** Accounts newer than this many days count as fake invites and raid risk. */
  minAccountAgeDays: smallint('min_account_age_days').notNull().default(7),
  dmOnPunish: boolean('dm_on_punish').notNull().default(true),
  deleteInvokeMessage: boolean('delete_invoke_message').notNull().default(false),
  nextCaseNumber: integer('next_case_number').notNull().default(1),
});

export type LogChannel = typeof logChannels.$inferSelect;
export type GreetConfig = typeof greetConfigs.$inferSelect;
export type InviteAttribution = typeof inviteAttribution.$inferSelect;
export type ModCase = typeof modCases.$inferSelect;
