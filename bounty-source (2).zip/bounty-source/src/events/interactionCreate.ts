/**
 * Component router.
 *
 * The hard part of interactions is not routing, it is the 3-second
 * acknowledgement window and the 15-minute token lifetime. Panels posted
 * weeks ago still get clicked, so every failure path here assumes the token
 * may already be dead and never throws on top of a dead token.
 */

import { Events, MessageFlags, type Interaction } from 'discord.js';
import { cid, type BountyClient, type ComponentInteraction } from '../core/client.js';
import { buildEmbed } from '../core/branding.js';
import { describeError, isExpiredInteraction } from '../core/errors.js';
import { getGuildConfig, getUserConfig } from '../db/index.js';
import { logger } from '../core/logger.js';

export function registerInteractionRouter(client: BountyClient): void {
  client.on(Events.InteractionCreate, async (interaction: Interaction) => {
    if (interaction.isAutocomplete()) return;
    const supported = interaction.isButton() || interaction.isStringSelectMenu()
      || interaction.isUserSelectMenu() || interaction.isModalSubmit();
    if (!supported) return;
    if (!interaction.inCachedGuild()) return;

    const parsed = cid.parse(interaction.customId);
    // Not ours — another bot's component or a legacy id from before the codec.
    if (!parsed) return;

    const handler = client.components.get(parsed.namespace);
    if (!handler) {
      await respondDead(interaction, 'That control is no longer supported.');
      return;
    }

    try {
      await handler.execute(interaction as ComponentInteraction, [parsed.action, ...parsed.args]);
    } catch (err) {
      if (isExpiredInteraction(err)) {
        // Nothing to say and nowhere to say it. Discord already closed the door.
        logger.debug({ customId: interaction.customId }, 'interaction expired mid-handler');
        return;
      }
      await reportInteractionError(interaction as ComponentInteraction, err);
    }
  });
}

/**
 * Sends an ephemeral error without assuming the interaction state. Handlers
 * may have deferred, replied, or done nothing at all before throwing.
 */
async function reportInteractionError(interaction: ComponentInteraction, err: unknown): Promise<void> {
  const described = describeError(err);

  if (described.internal) {
    logger.error({
      err, traceId: described.traceId,
      customId: interaction.customId, guildId: interaction.guildId,
    }, 'interaction error');
  }

  const [guildConfig, userConfig] = await Promise.all([
    getGuildConfig(interaction.guildId).catch(() => null),
    getUserConfig(interaction.user.id).catch(() => null),
  ]);

  const embed = buildEmbed({ guildConfig, userConfig }, {
    tone: described.tone,
    title: described.heading,
    description: described.hint ? `${described.message}\n\n${described.hint}` : described.message,
    footer: described.traceId ? `trace ${described.traceId}` : undefined,
  });

  const payload = { embeds: [embed], flags: MessageFlags.Ephemeral as const };

  try {
    if (interaction.deferred || interaction.replied) {
      await interaction.followUp(payload);
    } else {
      await interaction.reply(payload);
    }
  } catch {
    // Second failure means the token is gone. Stop.
  }
}

async function respondDead(interaction: ComponentInteraction, message: string): Promise<void> {
  await interaction.reply({ content: message, flags: MessageFlags.Ephemeral }).catch(() => undefined);
}
