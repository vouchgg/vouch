/**
 * The prefix dispatcher.
 *
 * Order matters: every rejection below the fold costs a Redis round trip, so
 * bots, DMs and non-prefixed chatter are dropped on in-memory checks first.
 * On a busy shard this path runs thousands of times a minute.
 */

import { Events, PermissionsBitField, type Message } from 'discord.js';
import type { BountyClient } from '../core/client.js';
import { Context } from '../core/command.js';
import { describeSubcommands } from '../core/registry.js';
import { runPipeline } from '../core/middleware.js';
import { buildEmbed } from '../core/branding.js';
import { describeError } from '../core/errors.js';
import { getGuildAliases, getGuildConfig, getUserConfig } from '../db/index.js';
import { logger } from '../core/logger.js';

export function registerMessageDispatcher(client: BountyClient): void {
  client.on(Events.MessageCreate, async (message) => {
    if (message.author.bot || !message.inGuild()) return;
    if (!message.content) return;

    try {
      await dispatch(client, message);
    } catch (err) {
      // Anything reaching here escaped the inner boundary — log, never crash.
      logger.error({ err, guildId: message.guildId }, 'dispatcher failure');
    }
  });
}

async function dispatch(client: BountyClient, message: Message<true>): Promise<void> {
  const guildConfig = await getGuildConfig(message.guildId);

  const prefix = resolvePrefix(message, guildConfig.prefix, client.user!.id);
  if (!prefix) return;

  const body = message.content.slice(prefix.length);
  // Bare mention is a prefix probe: answer it, cheaply.
  if (!body.trim()) {
    if (prefix.startsWith('<@')) {
      await message.reply({
        content: `My prefix here is \`${guildConfig.prefix}\`.`,
        allowedMentions: { repliedUser: false },
      }).catch(() => undefined);
    }
    return;
  }

  const aliases = await getGuildAliases(message.guildId);
  const resolved = client.commands.resolve(body, aliases);
  if (!resolved) return;

  // Bounty must at minimum be able to answer in this channel.
  const channelPerms = message.channel.permissionsFor(message.guild.members.me!);
  if (!channelPerms?.has(PermissionsBitField.Flags.SendMessages)) return;

  const userConfig = await getUserConfig(message.author.id);
  const ctx = new Context(client, message, resolved.args, resolved.path, guildConfig, userConfig);

  const started = process.hrtime.bigint();

  try {
    await runPipeline(ctx, resolved);

    if (!resolved.command.execute) {
      // A group invoked bare lists its children rather than failing silently.
      await ctx.send({
        title: `${guildConfig.prefix}${resolved.command.name}`,
        description: describeSubcommands(resolved.command, guildConfig.prefix)
          || 'That command has no subcommands configured.',
      });
      return;
    }

    await resolved.command.execute(ctx);

    logger.debug({
      path: resolved.path,
      guildId: message.guildId,
      ms: Number(process.hrtime.bigint() - started) / 1e6,
    }, 'command executed');
  } catch (err) {
    await reportError(ctx, err, resolved.path);
  }
}

/**
 * Guild prefix, a bare mention, or a mention followed by the command. A user
 * who forgets the prefix can always fall back to pinging the bot.
 */
function resolvePrefix(message: Message<true>, guildPrefix: string, botId: string): string | null {
  const mention = new RegExp(`^<@!?${botId}>\\s*`).exec(message.content);
  if (mention) return mention[0];
  if (message.content.startsWith(guildPrefix)) return guildPrefix;
  return null;
}

async function reportError(ctx: Context, err: unknown, path: string): Promise<void> {
  const described = describeError(err);

  if (described.internal) {
    logger.error({
      err, traceId: described.traceId, path,
      guildId: ctx.guild.id, userId: ctx.author.id,
    }, 'command error');
  }

  const embed = buildEmbed(
    { guildConfig: ctx.guildConfig, userConfig: ctx.userConfig },
    {
      tone: described.tone,
      title: described.heading,
      description: described.hint
        ? `${described.message}\n\n${described.hint}`
        : described.message,
      footer: described.traceId ? `trace ${described.traceId}` : undefined,
    },
  );

  await ctx.message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } })
    .catch(() => undefined); // The channel may have been deleted mid-command.
}
