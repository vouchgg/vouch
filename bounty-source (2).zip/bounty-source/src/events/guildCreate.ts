/**
 * Server install greeting.
 *
 * Picking the channel is most of the work. A bot that posts into the wrong
 * place on join, or worse into several, reads as spam — so this walks one
 * ordered list and stops at the first channel it can actually speak in.
 */

import {
  ChannelType, Events, PermissionFlagsBits,
  type Guild, type GuildTextBasedChannel,
} from 'discord.js';
import type { BountyClient } from '../core/client.js';
import { guildWelcome, quickStart, WELCOME_NS } from '../modules/onboarding/welcome.js';
import { getGuildConfig } from '../db/index.js';
import { redis } from '../core/cache.js';
import { logger } from '../core/logger.js';
import { MessageFlags } from 'discord.js';

const NEEDED = PermissionFlagsBits.ViewChannel
  | PermissionFlagsBits.SendMessages
  | PermissionFlagsBits.EmbedLinks;

export function registerGuildCreate(client: BountyClient): void {
  client.on(Events.GuildCreate, async (guild) => {
    try {
      await onJoin(client, guild);
    } catch (err) {
      logger.error({ err, guildId: guild.id }, 'guild welcome failed');
    }
  });

  client.on(Events.GuildDelete, (guild) => {
    // Rows stay put: a kick is often temporary, and cascading a delete here
    // would throw away every ticket, giveaway and setting on a misclick.
    logger.info({ guildId: guild.id, name: guild.name }, 'removed from guild');
  });

  // The Quick start button on the welcome message.
  client.registerComponent({
    namespace: WELCOME_NS,
    async execute(interaction) {
      if (!interaction.isButton()) return;
      const config = await getGuildConfig(interaction.guildId);
      await interaction.reply({
        embeds: [quickStart(config.prefix)],
        flags: MessageFlags.Ephemeral,
      });
    },
  });
}

async function onJoin(client: BountyClient, guild: Guild): Promise<void> {
  // Being re-added twice in a minute should not produce two greetings.
  const fresh = await redis.set(`bounty:welcomed:${guild.id}`, '1', 'EX', 86_400, 'NX')
    .catch(() => 'OK'); // Redis down: greet anyway, a duplicate beats silence.
  if (fresh !== 'OK') return;

  const config = await getGuildConfig(guild.id);
  const payload = guildWelcome(client, guild, config.prefix);

  const channel = pickChannel(guild);
  if (channel) {
    await channel.send(payload);
    logger.info({ guildId: guild.id, channelId: channel.id }, 'welcome sent');
    return;
  }

  // No channel Bounty can post in. Tell the person who added it instead.
  const owner = await guild.fetchOwner().catch(() => null);
  if (!owner) return;

  await owner.send({
    content:
      `Thanks for adding Bounty to **${guild.name}**. There was no channel it ` +
      'could post in, so here is the welcome instead — give the Bounty role ' +
      'View Channel, Send Messages and Embed Links somewhere to get started.',
    ...payload,
  }).catch(() => {
    logger.info({ guildId: guild.id }, 'no channel and owner DMs are closed');
  });
}

/**
 * System channel, then the channel the invite most likely came from, then the
 * first text channel in the list. Threads and forums are skipped: a greeting
 * inside someone's thread is worse than no greeting.
 */
function pickChannel(guild: Guild): GuildTextBasedChannel | null {
  const me = guild.members.me;
  if (!me) return null;

  const speakable = (channel: GuildTextBasedChannel | null | undefined) =>
    channel && channel.permissionsFor(me)?.has(NEEDED) ? channel : null;

  const system = speakable(guild.systemChannel);
  if (system) return system;

  const named = guild.channels.cache.find((c) =>
    c.type === ChannelType.GuildText &&
    /^(general|chat|lounge|main|bot|commands|bot-commands)$/i.test(c.name) &&
    speakable(c as GuildTextBasedChannel));
  if (named) return named as GuildTextBasedChannel;

  const first = guild.channels.cache
    .filter((c) => c.type === ChannelType.GuildText)
    .sort((a, b) => a.rawPosition - b.rawPosition)
    .find((c) => speakable(c as GuildTextBasedChannel));

  return (first as GuildTextBasedChannel) ?? null;
}
