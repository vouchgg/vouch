/**
 * Command contract.
 *
 * A command is a node in a tree. `,vc lock` and `,voicemaster default name`
 * are the same structure at different depths, so the resolver walks the tree
 * instead of switching on strings inside a handler.
 */

import {
  ChannelType, Colors, GuildMember, Message, PermissionsBitField, Role, User,
  type GuildTextBasedChannel, type MessageCreateOptions, type PermissionResolvable,
} from 'discord.js';
import type { BountyClient } from './client.js';
import { buildEmbed, type BrandContext, type BuildEmbedOptions } from './branding.js';
import { NotFoundError, UsageError } from './errors.js';
import type { Guild as GuildRow, User as UserRow } from '../db/schema.js';

export type ModuleName =
  | 'Lookups' | 'VoiceMaster' | 'Giveaways' | 'Tickets'
  | 'Aesthetic' | 'Moderation' | 'CustomInstanceHost' | 'Utility' | 'LastFM' | 'Bio';

/* --------------------------------------------------------------- context */

export class Context {
  constructor(
    readonly client: BountyClient,
    readonly message: Message<true>,
    /** Words after the resolved command path. `,vc limit 5` → ['5']. */
    readonly args: string[],
    /** Full dotted path of what actually ran: "voice.limit". */
    readonly path: string,
    readonly guildConfig: GuildRow,
    readonly userConfig: UserRow,
  ) {}

  get guild() { return this.message.guild; }
  get channel() { return this.message.channel as GuildTextBasedChannel; }
  get author() { return this.message.author; }
  get member() { return this.message.member as GuildMember; }
  get me() { return this.message.guild.members.me!; }

  private get brand(): BrandContext {
    return {
      guildConfig: this.guildConfig,
      userConfig: this.userConfig,
      author: { name: this.author.username, iconURL: this.author.displayAvatarURL({ size: 64 }) },
    };
  }

  embed(opts: BuildEmbedOptions) {
    return buildEmbed(this.brand, opts);
  }

  /** Reply without pinging. Every command output goes through here. */
  send(opts: BuildEmbedOptions | MessageCreateOptions) {
    const payload: MessageCreateOptions = 'tone' in opts || 'description' in opts || 'title' in opts
      ? { embeds: [this.embed(opts as BuildEmbedOptions)] }
      : opts as MessageCreateOptions;

    return this.message.reply({
      ...payload,
      allowedMentions: { repliedUser: false, parse: [] },
    });
  }

  ok(description: string, extra: BuildEmbedOptions = {}) {
    return this.send({ tone: 'success', description, ...extra });
  }

  warn(description: string, extra: BuildEmbedOptions = {}) {
    return this.send({ tone: 'warn', description, ...extra });
  }

  /* ------------------------------------------------------ arg resolution */

  /** `,ban @user`, `,ban 1234567890`, `,ban name#0`, `,ban partial name`. */
  async resolveMember(index = 0, { required = true, fallbackToAuthor = false } = {}): Promise<GuildMember | null> {
    const raw = this.args[index];
    if (!raw) {
      if (fallbackToAuthor) return this.member;
      if (required) throw new UsageError('Name a member.', `Example: ${this.guildConfig.prefix}${this.path.replace(/\./g, ' ')} @user`);
      return null;
    }

    const mention = this.message.mentions.members?.first();
    if (mention && raw.includes(mention.id)) return mention;

    const id = raw.match(/^<@!?(\d{17,20})>$/)?.[1] ?? (/^\d{17,20}$/.test(raw) ? raw : null);
    if (id) {
      const fetched = await this.guild.members.fetch(id).catch(() => null);
      if (fetched) return fetched;
      if (required) throw new NotFoundError(`No member with ID \`${id}\` is in this server.`);
      return null;
    }

    const query = raw.toLowerCase();
    const results = await this.guild.members.fetch({ query: raw, limit: 5 }).catch(() => null);
    const match = results?.find((m) =>
      m.user.username.toLowerCase() === query ||
      m.displayName.toLowerCase() === query) ?? results?.first();

    if (!match && required) throw new NotFoundError(`No member matched \`${clip(raw)}\`.`);
    return match ?? null;
  }

  /** Resolves users who may have left the server, for lookups. */
  async resolveUser(index = 0, { fallbackToAuthor = true } = {}): Promise<User> {
    const raw = this.args[index];
    if (!raw) {
      if (fallbackToAuthor) return this.author;
      throw new UsageError('Name a user.');
    }
    const id = raw.match(/^<@!?(\d{17,20})>$/)?.[1] ?? (/^\d{17,20}$/.test(raw) ? raw : null);
    if (id) {
      const user = await this.client.users.fetch(id, { force: false }).catch(() => null);
      if (!user) throw new NotFoundError(`No Discord user has the ID \`${id}\`.`);
      return user;
    }
    const member = await this.resolveMember(index, { required: true });
    return member!.user;
  }

  async resolveRole(index = 0): Promise<Role> {
    const raw = this.args[index];
    if (!raw) throw new UsageError('Name a role.');
    const id = raw.match(/^<@&(\d{17,20})>$/)?.[1] ?? (/^\d{17,20}$/.test(raw) ? raw : null);
    const role = id
      ? this.guild.roles.cache.get(id) ?? await this.guild.roles.fetch(id).catch(() => null)
      : this.guild.roles.cache.find((r) => r.name.toLowerCase() === raw.toLowerCase());
    if (!role) throw new NotFoundError(`No role matched \`${clip(raw)}\`.`);
    return role;
  }

  /** Everything from `index` onwards, joined. For reasons and names. */
  rest(index = 0): string {
    return this.args.slice(index).join(' ').trim();
  }
}

/* ------------------------------------------------------------- parsers */

const DURATION_UNITS: Record<string, number> = {
  s: 1000, sec: 1000, secs: 1000, m: 60_000, min: 60_000, mins: 60_000,
  h: 3_600_000, hr: 3_600_000, hrs: 3_600_000, d: 86_400_000, day: 86_400_000,
  days: 86_400_000, w: 604_800_000, wk: 604_800_000,
};

/** "10m", "1h30m", "2d" → milliseconds. Returns null on nonsense. */
export function parseDuration(input: string): number | null {
  const matches = input.toLowerCase().matchAll(/(\d+)\s*([a-z]+)/g);
  let total = 0;
  let found = false;
  for (const [, amount, unit] of matches) {
    const factor = DURATION_UNITS[unit];
    if (!factor) return null;
    total += Number(amount) * factor;
    found = true;
  }
  return found ? total : null;
}

/** Accepts "#ff0055", "ff0055", "f05" and the named brand colours. */
export function parseHex(input: string): number | null {
  const named = (Colors as Record<string, number>)[input.replace(/^\w/, (c) => c.toUpperCase())];
  if (typeof named === 'number') return named;
  let hex = input.replace(/^#/, '').trim();
  if (/^[0-9a-f]{3}$/i.test(hex)) hex = hex.split('').map((c) => c + c).join('');
  if (!/^[0-9a-f]{6}$/i.test(hex)) return null;
  return Number.parseInt(hex, 16);
}

const clip = (s: string, n = 40) => (s.length > n ? `${s.slice(0, n)}…` : s).replace(/`/g, "'");

/* ------------------------------------------------------ command shapes */

export interface CommandMeta {
  name: string;
  aliases?: string[];
  module: ModuleName;
  description: string;
  /** Shown in help and in usage errors, without the prefix. */
  usage?: string;
  examples?: string[];
  /** Permissions the invoking member must hold. */
  userPermissions?: PermissionResolvable[];
  /** Permissions the bot must hold in the target channel. */
  botPermissions?: PermissionResolvable[];
  /** Guild owner only — used by antinuke and custom bot hosting. */
  ownerOnly?: boolean;
  /** Bounty staff only. */
  developerOnly?: boolean;
  premium?: boolean;
  cooldown?: { uses: number; windowMs: number; scope?: 'user' | 'guild' | 'channel' };
  /** Channel types the command is allowed in. Defaults to guild text. */
  channelTypes?: ChannelType[];
}

export interface Command extends CommandMeta {
  /** Child commands keyed by name. Aliases are folded in at load time. */
  subcommands?: Record<string, Command>;
  /**
   * Runs when no subcommand matched. A group without `execute` and without a
   * matching child replies with its own subcommand list.
   */
  execute?: (ctx: Context) => Promise<unknown>;
}

export const defineCommand = (command: Command): Command => command;

/** Convenience for permission checks inside handlers. */
export const has = (member: GuildMember, perm: PermissionResolvable) =>
  member.permissions.has(perm) || member.permissions.has(PermissionsBitField.Flags.Administrator);
