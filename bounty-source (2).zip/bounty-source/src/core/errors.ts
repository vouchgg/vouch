/**
 * One error vocabulary for the whole bot.
 *
 * Rules:
 *  - Anything thrown inside a command or component handler is caught by the
 *    dispatcher and rendered through `describeError`.
 *  - A `BountyError` is safe to show a user. Anything else is logged with a
 *    trace id and the user sees a generic line — stack traces never reach chat.
 */

import { DiscordAPIError, HTTPError, PermissionsBitField, RESTJSONErrorCodes } from 'discord.js';
import { humanDuration } from './branding.js';
import type { EmbedTone } from './branding.js';

export abstract class BountyError extends Error {
  abstract readonly tone: EmbedTone;
  /** Shown above the message, e.g. "Missing permissions". */
  abstract readonly heading: string;
  /** A concrete next step. Errors are never vague about what to do. */
  readonly hint?: string;
  constructor(message: string, hint?: string) {
    super(message);
    this.name = new.target.name;
    this.hint = hint;
  }
}

/** The user asked for something impossible or malformed. */
export class UsageError extends BountyError {
  readonly tone = 'warn' as const;
  readonly heading = 'Check the usage';
}

/** The user is not allowed to do this. */
export class PermissionError extends BountyError {
  readonly tone = 'danger' as const;
  readonly heading = 'Not allowed';
}

/** The bot is not allowed to do this. */
export class BotPermissionError extends BountyError {
  readonly tone = 'danger' as const;
  readonly heading = 'Missing permissions';
  constructor(missing: bigint[] | string[], where?: string) {
    const names = missing.map((m) =>
      typeof m === 'string' ? m : new PermissionsBitField(m).toArray().join(', '));
    super(
      `Bounty needs ${names.join(', ')}${where ? ` in ${where}` : ''}.`,
      'Grant the permission, then run the command again.',
    );
  }
}

/** Role hierarchy blocked the action. */
export class HierarchyError extends BountyError {
  readonly tone = 'danger' as const;
  readonly heading = 'Blocked by role hierarchy';
}

export class NotFoundError extends BountyError {
  readonly tone = 'warn' as const;
  readonly heading = 'Nothing found';
}

export class CooldownError extends BountyError {
  readonly tone = 'warn' as const;
  readonly heading = 'Slow down';
  constructor(retryAfterMs: number) {
    super(`Try that again in ${humanDuration(retryAfterMs)}.`);
  }
}

/** Discord or an upstream API pushed back. */
export class UpstreamError extends BountyError {
  readonly tone = 'danger' as const;
  readonly heading = 'Service is busy';
}

export class DatabaseError extends BountyError {
  readonly tone = 'danger' as const;
  readonly heading = 'Storage is unavailable';
  constructor() {
    super('That change was not saved.', 'Nothing was lost — try again in a moment.');
  }
}

/* ------------------------------------------------------ interpretation */

export interface ErrorDescription {
  heading: string;
  message: string;
  hint?: string;
  tone: EmbedTone;
  /** True when the failure is ours and deserves a log line with a trace id. */
  internal: boolean;
  traceId?: string;
}

/** Discord API codes worth translating into plain language. */
const API_CODE_MESSAGES: Partial<Record<number, { heading: string; message: string; hint?: string }>> = {
  [RESTJSONErrorCodes.UnknownInteraction]: {
    heading: 'That panel expired',
    message: 'Discord stopped accepting responses for this interaction.',
    hint: 'Open the panel again — the newest one always works.',
  },
  [RESTJSONErrorCodes.InteractionHasAlreadyBeenAcknowledged]: {
    heading: 'Already handled',
    message: 'This button was answered a moment ago.',
  },
  [RESTJSONErrorCodes.MissingPermissions]: {
    heading: 'Missing permissions',
    message: 'Bounty is not allowed to do that here.',
    hint: 'Check the channel overwrites as well as the role permissions.',
  },
  [RESTJSONErrorCodes.MissingAccess]: {
    heading: 'No access',
    message: 'Bounty cannot see that channel.',
    hint: 'Give the Bounty role View Channel on it.',
  },
  [RESTJSONErrorCodes.UnknownChannel]: {
    heading: 'Channel is gone',
    message: 'That channel was deleted while the command was running.',
  },
  [RESTJSONErrorCodes.UnknownMessage]: {
    heading: 'Message is gone',
    message: 'That message was deleted or is older than Bounty can reach.',
  },
  [RESTJSONErrorCodes.UnknownMember]: {
    heading: 'Not in this server',
    message: 'That user is not a member here.',
  },
  [RESTJSONErrorCodes.CannotExecuteActionOnSystemMessage]: {
    heading: 'Unsupported message',
    message: 'System messages cannot be modified.',
  },
  [RESTJSONErrorCodes.MaximumNumberOfGuildChannelsReached]: {
    heading: 'Channel limit reached',
    message: 'This server already has 500 channels.',
    hint: 'Delete some channels before creating another temporary one.',
  },
};

/** True for interactions Discord will no longer accept a reply for. */
export function isExpiredInteraction(err: unknown): boolean {
  return err instanceof DiscordAPIError && (
    err.code === RESTJSONErrorCodes.UnknownInteraction ||
    err.code === RESTJSONErrorCodes.InteractionHasAlreadyBeenAcknowledged
  );
}

export function isRateLimit(err: unknown): boolean {
  return (err instanceof HTTPError && err.status === 429) ||
    (err instanceof DiscordAPIError && err.status === 429);
}

export function describeError(err: unknown): ErrorDescription {
  if (err instanceof BountyError) {
    return { heading: err.heading, message: err.message, hint: err.hint, tone: err.tone, internal: false };
  }

  if (isRateLimit(err)) {
    return {
      heading: 'Rate limited',
      message: 'Discord is throttling Bounty on this route.',
      hint: 'The action is queued — give it a few seconds.',
      tone: 'warn', internal: false,
    };
  }

  if (err instanceof DiscordAPIError) {
    const known = API_CODE_MESSAGES[Number(err.code)];
    if (known) return { ...known, tone: 'danger', internal: false };
  }

  // Postgres surfaces failures as coded errors; treat them as ours, not theirs.
  if (typeof err === 'object' && err !== null && 'code' in err && typeof (err as { code: unknown }).code === 'string') {
    const pgCode = (err as { code: string }).code;
    if (pgCode.startsWith('23') || pgCode.startsWith('40') || pgCode.startsWith('08')) {
      const dbErr = new DatabaseError();
      return { heading: dbErr.heading, message: dbErr.message, hint: dbErr.hint, tone: 'danger', internal: true, traceId: newTraceId() };
    }
  }

  return {
    heading: 'Something broke',
    message: 'That failed on our side, not yours.',
    hint: 'The incident was logged. Try again shortly.',
    tone: 'danger',
    internal: true,
    traceId: newTraceId(),
  };
}

export const newTraceId = () => Math.random().toString(36).slice(2, 10);
