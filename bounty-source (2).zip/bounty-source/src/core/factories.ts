/**
 * Command factories.
 *
 * Roughly a third of a bot this size is the same command written again with a
 * different column behind it: point a thing at a channel, flip a boolean, set
 * a string. Those are generated from a spec here so the behaviour — parsing,
 * permission text, the "unset" path, the confirmation wording — is written
 * once and fixed once.
 *
 * Anything with real logic is still hand-written. This is for the plumbing.
 */

import { ChannelType, PermissionFlagsBits, type GuildTextBasedChannel } from 'discord.js';
import type { Command, Context, ModuleName } from './command.js';
import { UsageError } from './errors.js';
import { parseHex } from './command.js';

export interface SettingSpec<V> {
  name: string;
  aliases?: string[];
  module: ModuleName;
  description: string;
  /** How the argument is read. */
  kind: 'channel' | 'role' | 'toggle' | 'text' | 'number' | 'hex';
  /** Persist the parsed value. `null` means the user asked to unset it. */
  save: (ctx: Context, value: V | null) => Promise<void>;
  /** The confirmation line. Gets the parsed value back. */
  confirm: (value: V | null) => string;
  min?: number;
  max?: number;
  maxLength?: number;
  channelTypes?: ChannelType[];
  userPermissions?: Command['userPermissions'];
}

const UNSET = new Set(['none', 'off', 'disable', 'disabled', 'clear', 'reset', 'remove']);

export function setting<V>(spec: SettingSpec<V>): Command {
  return {
    name: spec.name,
    aliases: spec.aliases,
    module: spec.module,
    description: spec.description,
    userPermissions: spec.userPermissions ?? [PermissionFlagsBits.ManageGuild],
    execute: async (ctx) => {
      const raw = ctx.rest();

      if (!raw) {
        throw new UsageError(
          `Give a ${describeKind(spec.kind)}.`,
          `Use \`${ctx.guildConfig.prefix}${ctx.path.replace(/\./g, ' ')} none\` to turn it off.`,
        );
      }

      if (UNSET.has(raw.toLowerCase())) {
        await spec.save(ctx, null);
        return ctx.ok(spec.confirm(null));
      }

      const value = await parse(ctx, spec, raw);
      await spec.save(ctx, value);
      return ctx.ok(spec.confirm(value));
    },
  };
}

async function parse<V>(ctx: Context, spec: SettingSpec<V>, raw: string): Promise<V> {
  switch (spec.kind) {
    case 'channel': {
      const id = raw.match(/^<#(\d{17,20})>$/)?.[1] ?? (/^\d{17,20}$/.test(raw) ? raw : null);
      const channel = id
        ? ctx.guild.channels.cache.get(id)
        : ctx.guild.channels.cache.find((c) => c.name === raw.replace(/^#/, ''));

      if (!channel) throw new UsageError(`No channel matched \`${raw.slice(0, 40)}\`.`);

      const allowed = spec.channelTypes ?? [ChannelType.GuildText, ChannelType.GuildAnnouncement];
      if (!allowed.includes(channel.type)) {
        throw new UsageError(`${channel} is not a channel Bounty can post in.`);
      }

      const perms = (channel as GuildTextBasedChannel).permissionsFor(ctx.me);
      if (!perms?.has(PermissionFlagsBits.SendMessages) || !perms.has(PermissionFlagsBits.EmbedLinks)) {
        throw new UsageError(
          `Bounty cannot post in ${channel}.`,
          'It needs View Channel, Send Messages and Embed Links there.',
        );
      }
      return channel as V;
    }

    case 'role': {
      const role = await ctx.resolveRole(0);
      if (role.managed) throw new UsageError(`${role} belongs to an integration and cannot be assigned.`);
      return role as V;
    }

    case 'toggle': {
      const on = ['on', 'true', 'yes', 'enable', 'enabled', '1'].includes(raw.toLowerCase());
      const off = ['off', 'false', 'no', '0'].includes(raw.toLowerCase());
      if (!on && !off) throw new UsageError('Say `on` or `off`.');
      return on as V;
    }

    case 'number': {
      const value = Number.parseInt(raw, 10);
      if (Number.isNaN(value)) throw new UsageError('Give a whole number.');
      const min = spec.min ?? 0;
      const max = spec.max ?? Number.MAX_SAFE_INTEGER;
      if (value < min || value > max) throw new UsageError(`Give a number between ${min} and ${max}.`);
      return value as V;
    }

    case 'hex': {
      const colour = parseHex(raw);
      if (colour === null) throw new UsageError('Give a hex colour like `#5B2E9D`.');
      return colour as V;
    }

    case 'text': {
      const max = spec.maxLength ?? 2000;
      if (raw.length > max) throw new UsageError(`Keep it under ${max} characters.`);
      return raw as V;
    }
  }
}

const describeKind = (kind: SettingSpec<unknown>['kind']) =>
  kind === 'channel' ? 'channel' : kind === 'role' ? 'role'
    : kind === 'toggle' ? 'value of on or off' : kind === 'number' ? 'number'
      : kind === 'hex' ? 'hex colour' : 'value';

/** Groups a set of generated settings under one parent command. */
export function settingsGroup(opts: {
  name: string;
  aliases?: string[];
  module: ModuleName;
  description: string;
  userPermissions?: Command['userPermissions'];
  children: Command[];
}): Command {
  return {
    name: opts.name,
    aliases: opts.aliases,
    module: opts.module,
    description: opts.description,
    userPermissions: opts.userPermissions ?? [PermissionFlagsBits.ManageGuild],
    subcommands: Object.fromEntries(opts.children.map((c) => [c.name, c])),
  };
}
