/**
 * Dispatch middleware. Each guard throws a `BountyError`; the dispatcher
 * catches once and renders once. Guards run in cost order — the cheap
 * in-memory checks reject before we touch Redis or Postgres.
 */

import { ChannelType, GuildMember, PermissionsBitField, type PermissionResolvable } from 'discord.js';
import type { Context, Command } from './command.js';
import type { Resolved } from './registry.js';
import {
  BotPermissionError, CooldownError, HierarchyError, PermissionError, UsageError,
} from './errors.js';
import { consume, key } from './cache.js';

export type Middleware = (ctx: Context, resolved: Resolved) => Promise<void>;

/** Union of metadata down the chain: a parent's requirements bind its children. */
function collect<T>(chain: Command[], pick: (c: Command) => T[] | undefined): T[] {
  return chain.flatMap((c) => pick(c) ?? []);
}

/* ------------------------------------------------------------- the gates */

const blacklist: Middleware = async (ctx) => {
  if (ctx.userConfig.blacklisted) {
    throw new PermissionError(
      'Your access to Bounty was revoked.',
      ctx.userConfig.blacklistReason ?? 'Appeal in the support server.',
    );
  }
  if (ctx.guildConfig.blacklisted) {
    throw new PermissionError('This server is blocked from using Bounty.');
  }
};

const moduleEnabled: Middleware = async (ctx, { command, path }) => {
  if (ctx.guildConfig.disabledModules.includes(command.module)) {
    throw new PermissionError(
      `The ${command.module} module is turned off in this server.`,
      `An admin can turn it on with \`${ctx.guildConfig.prefix}module enable ${command.module.toLowerCase()}\`.`,
    );
  }

  const override = ctx.guildConfig.commandOverrides[path] ?? ctx.guildConfig.commandOverrides[command.name];
  if (!override) return;

  if (override.disabled) {
    throw new PermissionError('That command is disabled here.');
  }
  if (override.channels?.length && !override.channels.includes(ctx.channel.id)) {
    const list = override.channels.slice(0, 3).map((id) => `<#${id}>`).join(', ');
    throw new PermissionError(`That command only works in ${list}.`);
  }
  if (override.roles?.length && !override.roles.some((id) => ctx.member.roles.cache.has(id))) {
    throw new PermissionError('You do not have a role that can run that command.');
  }
};

const channelType: Middleware = async (ctx, { command }) => {
  const allowed = command.channelTypes ?? [
    ChannelType.GuildText, ChannelType.PublicThread, ChannelType.PrivateThread,
    ChannelType.GuildAnnouncement, ChannelType.GuildVoice,
  ];
  if (!allowed.includes(ctx.channel.type)) {
    throw new UsageError('That command does not work in this kind of channel.');
  }
};

const ownership: Middleware = async (ctx, { chain }) => {
  if (chain.some((c) => c.developerOnly) && !ctx.client.isDeveloper(ctx.author.id)) {
    // Silence rather than confirm the command exists.
    throw new PermissionError('Unknown command.');
  }
  if (chain.some((c) => c.ownerOnly) && ctx.guild.ownerId !== ctx.author.id) {
    throw new PermissionError('Only the server owner can run that.');
  }
};

const userPermissions: Middleware = async (ctx, { chain }) => {
  const required = collect(chain, (c) => c.userPermissions);
  if (!required.length) return;

  const missing = ctx.member.permissions.missing(required as PermissionResolvable[]);
  if (missing.length && !ctx.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
    throw new PermissionError(`You need ${format(missing)} to do that.`);
  }
};

const botPermissions: Middleware = async (ctx, { chain }) => {
  const required = collect(chain, (c) => c.botPermissions);
  if (!required.length) return;

  // Channel-level, not guild-level: overwrites are where permissions actually fail.
  const effective = ctx.channel.permissionsFor(ctx.me);
  const missing = effective?.missing(required as PermissionResolvable[]) ?? [];
  if (missing.length) throw new BotPermissionError(missing, `<#${ctx.channel.id}>`);
};

const cooldown: Middleware = async (ctx, { command, path }) => {
  if (!command.cooldown) return;
  const { uses, windowMs, scope = 'user' } = command.cooldown;
  const scopeId = scope === 'guild' ? ctx.guild.id : scope === 'channel' ? ctx.channel.id : ctx.author.id;

  const bucket = await consume(key.cooldown(path, scopeId), uses, windowMs);
  if (bucket.limited) throw new CooldownError(bucket.retryAfterMs);
};

const premium: Middleware = async (ctx, { chain }) => {
  if (!chain.some((c) => c.premium)) return;
  const until = ctx.guildConfig.premiumUntil;
  if (!until || until.getTime() < Date.now()) {
    throw new PermissionError(
      'That command is part of Bounty premium.',
      'See what is included at bounty.lol/premium.',
    );
  }
};

export const pipeline: Middleware[] = [
  blacklist, moduleEnabled, channelType, ownership,
  userPermissions, botPermissions, premium, cooldown,
];

export async function runPipeline(ctx: Context, resolved: Resolved): Promise<void> {
  for (const guard of pipeline) await guard(ctx, resolved);
}

/* --------------------------------------------------- hierarchy utilities */

/**
 * Both checks that moderation commands forget: the bot must outrank the
 * target, and so must the moderator. Server owner outranks everyone.
 */
export function assertHierarchy(actor: GuildMember, target: GuildMember, action = 'moderate'): void {
  if (target.id === target.guild.ownerId) {
    throw new HierarchyError(`You cannot ${action} the server owner.`);
  }
  if (actor.id === target.id) {
    throw new UsageError(`You cannot ${action} yourself.`);
  }

  const me = target.guild.members.me!;
  if (me.roles.highest.comparePositionTo(target.roles.highest) <= 0) {
    throw new HierarchyError(
      `Bounty's role is not above ${target}.`,
      'Drag the Bounty role higher in Server Settings → Roles.',
    );
  }
  if (actor.id !== actor.guild.ownerId &&
      actor.roles.highest.comparePositionTo(target.roles.highest) <= 0) {
    throw new HierarchyError(`${target} has a role equal to or above yours.`);
  }
}

/** Same idea for role targets: `,role color @VIP` on a role above the bot. */
export function assertRoleEditable(actor: GuildMember, roleId: string): void {
  const role = actor.guild.roles.cache.get(roleId);
  if (!role) return;
  const me = actor.guild.members.me!;
  if (role.managed) {
    throw new HierarchyError(`${role} is managed by an integration and cannot be edited.`);
  }
  if (me.roles.highest.comparePositionTo(role) <= 0) {
    throw new HierarchyError(`${role} sits above Bounty's highest role.`);
  }
  if (actor.id !== actor.guild.ownerId && actor.roles.highest.comparePositionTo(role) <= 0) {
    throw new HierarchyError(`${role} sits above your highest role.`);
  }
}

const format = (perms: string[]) =>
  perms.map((p) => p.replace(/([a-z])([A-Z])/g, '$1 $2')).join(', ');
