import {
  Client, GatewayIntentBits, Options, Partials,
  type ButtonInteraction, type ModalSubmitInteraction, type StringSelectMenuInteraction,
  type UserSelectMenuInteraction,
} from 'discord.js';
import { CommandRegistry } from './registry.js';
import { logger } from './logger.js';
import type { VoiceMasterEngine } from '../modules/voicemaster/engine.js';
import type { LoggingEngine } from '../modules/logging/engine.js';
import type { GreetingEngine } from '../modules/greetings/engine.js';
import type { InviteEngine } from '../modules/invites/engine.js';

export type ComponentInteraction =
  | ButtonInteraction<'cached'>
  | StringSelectMenuInteraction<'cached'>
  | UserSelectMenuInteraction<'cached'>
  | ModalSubmitInteraction<'cached'>;

export interface ComponentHandler {
  /** Namespace claimed in the custom id: `bounty:vm:lock` → 'vm'. */
  namespace: string;
  /**
   * Reply within 3 seconds or Discord invalidates the token. Handlers that
   * cannot promise that must call `interaction.deferUpdate()` first.
   */
  execute: (interaction: ComponentInteraction, args: string[]) => Promise<unknown>;
}

export class BountyClient extends Client {
  readonly commands = new CommandRegistry();
  readonly components = new Map<string, ComponentHandler>();
  /** Engines are constructed during bootstrap, since each needs the client. */
  voicemaster!: VoiceMasterEngine;
  logging!: LoggingEngine;
  greetings!: GreetingEngine;
  inviteTracking!: InviteEngine;

  private readonly developerIds: Set<string>;

  constructor() {
    super({
      intents:
        GatewayIntentBits.Guilds |
        GatewayIntentBits.GuildMembers |
        GatewayIntentBits.GuildMessages |
        GatewayIntentBits.GuildVoiceStates |
        GatewayIntentBits.GuildPresences |      // required by ,spotify
        GatewayIntentBits.GuildMessageReactions |
        GatewayIntentBits.MessageContent,
      partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.GuildMember],
      allowedMentions: { parse: ['users'], repliedUser: false },
      // Cache what the bot reads constantly, drop what it does not. Message
      // cache stays small because snipes live in Redis, not memory.
      makeCache: Options.cacheWithLimits({
        ...Options.DefaultMakeCacheSettings,
        MessageManager: 50,
        PresenceManager: 0,
        ReactionManager: 0,
        GuildMemberManager: { maxSize: 200, keepOverLimit: (m) => m.id === m.client.user.id },
      }),
      sweepers: {
        ...Options.DefaultSweeperSettings,
        messages: { interval: 300, lifetime: 900 },
      },
    });

    this.developerIds = new Set((process.env.DEVELOPER_IDS ?? '').split(',').filter(Boolean));
  }

  isDeveloper(userId: string): boolean {
    return this.developerIds.has(userId);
  }

  registerComponent(handler: ComponentHandler): void {
    if (this.components.has(handler.namespace)) {
      throw new Error(`Component namespace "${handler.namespace}" is already claimed`);
    }
    this.components.set(handler.namespace, handler);
    logger.debug({ namespace: handler.namespace }, 'component handler registered');
  }
}

/* ------------------------------------------------------ custom id codec */

/**
 * Custom ids are `bounty:<namespace>:<action>[:arg...]`, capped at Discord's
 * 100 characters. Arguments are positional and never contain a colon — ids
 * carry references (a channel id, a giveaway id), never payloads.
 */
export const cid = {
  build(namespace: string, action: string, ...args: (string | number)[]): string {
    const id = ['bounty', namespace, action, ...args.map(String)].join(':');
    if (id.length > 100) throw new Error(`custom id too long (${id.length}): ${id}`);
    return id;
  },

  parse(customId: string): { namespace: string; action: string; args: string[] } | null {
    if (!customId.startsWith('bounty:')) return null;
    const [, namespace, action, ...args] = customId.split(':');
    if (!namespace || !action) return null;
    return { namespace, action, args };
  },
};
