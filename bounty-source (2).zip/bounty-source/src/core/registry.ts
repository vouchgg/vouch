/**
 * Loads every command module off disk and resolves an input line to the
 * deepest matching command node.
 *
 * `,voicemaster default name {user}` resolves greedily:
 *   voicemaster → default → name, leaving ['{user}'] as args.
 * No handler ever inspects `args[0]` to decide what it is.
 */

import { readdir } from 'node:fs/promises';
import { pathToFileURL } from 'node:url';
import path from 'node:path';
import type { Command, ModuleName } from './command.js';
import { logger } from './logger.js';

export interface Resolved {
  command: Command;
  /** Dotted path of the node that will execute: "voice.limit". */
  path: string;
  /** Words left over after the path was consumed. */
  args: string[];
  /** Every node walked through, root first — middleware unions their metadata. */
  chain: Command[];
}

export class CommandRegistry {
  /** Root commands by primary name. */
  readonly commands = new Map<string, Command>();
  /** Root aliases → primary name. */
  private readonly aliases = new Map<string, string>();

  async loadAll(modulesDir: string): Promise<void> {
    const entries = await readdir(modulesDir, { withFileTypes: true });

    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const commandsDir = path.join(modulesDir, entry.name, 'commands');
      const files = await readdir(commandsDir).catch(() => [] as string[]);

      for (const file of files) {
        if (!/\.(js|ts)$/.test(file) || file.endsWith('.d.ts')) continue;
        const url = pathToFileURL(path.join(commandsDir, file)).href;
        const mod = await import(url) as Record<string, unknown>;

        for (const exported of Object.values(mod)) {
          if (!isCommand(exported)) continue;
          this.register(exported);
        }
      }
    }

    logger.info({ commands: this.commands.size, aliases: this.aliases.size }, 'commands loaded');
  }

  register(command: Command): void {
    if (this.commands.has(command.name)) {
      throw new Error(`Duplicate command name: ${command.name}`);
    }
    this.commands.set(command.name, command);

    for (const alias of command.aliases ?? []) {
      const existing = this.aliases.get(alias);
      if (existing && existing !== command.name) {
        throw new Error(`Alias "${alias}" is claimed by both ${existing} and ${command.name}`);
      }
      this.aliases.set(alias, command.name);
    }
  }

  /**
   * @param content Message body with the prefix already stripped.
   * @param guildAliases Custom `,alias add` mappings for this guild, expanded
   *        before resolution so an alias can point at a full path with args.
   */
  resolve(content: string, guildAliases?: Map<string, string>): Resolved | null {
    let words = content.trim().split(/\s+/).filter(Boolean);
    if (!words.length) return null;

    // Custom aliases expand once. No recursion, so an alias cannot loop.
    const custom = guildAliases?.get(words[0].toLowerCase());
    if (custom) words = [...custom.split(/\s+/), ...words.slice(1)];

    const head = words[0].toLowerCase();
    const rootName = this.commands.has(head) ? head : this.aliases.get(head);
    if (!rootName) return null;

    let node = this.commands.get(rootName)!;
    const chain: Command[] = [node];
    const segments: string[] = [node.name];
    let index = 1;

    // Walk as deep as the input allows.
    while (index < words.length && node.subcommands) {
      const next = findChild(node, words[index].toLowerCase());
      if (!next) break;
      node = next;
      chain.push(node);
      segments.push(node.name);
      index += 1;
    }

    return { command: node, path: segments.join('.'), args: words.slice(index), chain };
  }

  /** For help output and the dashboard. */
  byModule(module: ModuleName): Command[] {
    return [...this.commands.values()].filter((c) => c.module === module);
  }
}

function findChild(node: Command, token: string): Command | undefined {
  const children = node.subcommands!;
  if (children[token]) return children[token];
  for (const child of Object.values(children)) {
    if (child.aliases?.includes(token)) return child;
  }
  return undefined;
}

function isCommand(value: unknown): value is Command {
  return typeof value === 'object' && value !== null &&
    'name' in value && 'module' in value &&
    ('execute' in value || 'subcommands' in value);
}

/** Human-readable list of a group's children, for the "no subcommand" reply. */
export function describeSubcommands(command: Command, prefix: string): string {
  if (!command.subcommands) return '';
  return Object.values(command.subcommands)
    .map((child) => `\`${prefix}${command.name} ${child.name}\` — ${child.description}`)
    .join('\n');
}
