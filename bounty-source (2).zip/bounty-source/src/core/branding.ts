/**
 * Every embed the bot sends is built here. Commands never construct an
 * EmbedBuilder directly — that is how colour drift and inconsistent footers
 * creep into a bot with 200 commands.
 */

import {
  EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
  StringSelectMenuBuilder, type APIEmbedField, type ColorResolvable,
} from 'discord.js';
import type { Guild as GuildRow, User as UserRow } from '../db/schema.js';

/** Brand palette, matching the logo. Violet is the default embed colour. */
export const PALETTE = {
  void: 0x0e0618,
  deep: 0x1a0b2e,
  violet: 0x5b2e9d,
  lilac: 0xb98cff,
  success: 0x5bd6a0,
  warn: 0xe8b44d,
  danger: 0xf0566b,
} as const;

export type EmbedTone = 'neutral' | 'success' | 'warn' | 'danger' | 'live';

const TONE_COLOR: Record<Exclude<EmbedTone, 'neutral'>, number> = {
  success: PALETTE.success,
  warn: PALETTE.warn,
  danger: PALETTE.danger,
  live: PALETTE.lilac,
};

/** Small glyphs prefixed to a description. Swap for guild emoji IDs if you host them. */
export const GLYPH = {
  neutral: '',
  success: '✓ ',
  warn: '! ',
  danger: '✕ ',
  live: '● ',
} as const;

export interface BrandContext {
  guildConfig?: Pick<GuildRow, 'embedColor' | 'footerText' | 'footerIconUrl' | 'timestampStyle'> | null;
  userConfig?: Pick<UserRow, 'embedColor'> | null;
  /** Author strip: shown as the embed author, not a title, so titles stay free. */
  author?: { name: string; iconURL?: string; url?: string };
}

function resolveColor(ctx: BrandContext, tone: EmbedTone): number {
  if (tone !== 'neutral') return TONE_COLOR[tone];
  const hex = ctx.userConfig?.embedColor ?? ctx.guildConfig?.embedColor;
  if (!hex) return PALETTE.violet;
  const parsed = Number.parseInt(hex.replace('#', ''), 16);
  return Number.isNaN(parsed) ? PALETTE.violet : parsed;
}

export interface BuildEmbedOptions {
  tone?: EmbedTone;
  /** Overrides the context author strip. `null` removes it entirely. */
  author?: { name: string; iconURL?: string; url?: string } | null;
  title?: string;
  url?: string;
  description?: string;
  fields?: APIEmbedField[];
  thumbnail?: string;
  image?: string;
  footer?: string;
  /** Overrides the guild's default timestamp behaviour for this one embed. */
  timestamp?: boolean;
  color?: ColorResolvable;
}

export function buildEmbed(ctx: BrandContext, opts: BuildEmbedOptions): EmbedBuilder {
  const tone = opts.tone ?? 'neutral';
  const embed = new EmbedBuilder().setColor(opts.color ?? resolveColor(ctx, tone));

  const author = opts.author === undefined ? ctx.author : opts.author;
  if (author) {
    embed.setAuthor({ name: author.name, iconURL: author.iconURL, url: author.url });
  }
  if (opts.title) embed.setTitle(opts.title);
  if (opts.url) embed.setURL(opts.url);
  if (opts.description) embed.setDescription(GLYPH[tone] + opts.description);
  if (opts.fields?.length) embed.addFields(opts.fields);
  if (opts.thumbnail) embed.setThumbnail(opts.thumbnail);
  if (opts.image) embed.setImage(opts.image);

  const footerText = opts.footer ?? ctx.guildConfig?.footerText ?? undefined;
  if (footerText) {
    embed.setFooter({ text: footerText, iconURL: ctx.guildConfig?.footerIconUrl ?? undefined });
  }

  const wantsTimestamp = opts.timestamp ?? ctx.guildConfig?.timestampStyle !== 'none';
  if (wantsTimestamp) embed.setTimestamp();

  return embed;
}

/* ------------------------------------------------------------ formatting */

/** Discord relative timestamp: renders in the reader's own locale and clock. */
export const ts = (date: Date | number, style: 'R' | 'f' | 'F' | 'D' | 'd' | 't' = 'R') =>
  `<t:${Math.floor((date instanceof Date ? date.getTime() : date) / 1000)}:${style}>`;

/** 3661000 → "1h 1m 1s". Used by giveaways, timeouts and cooldowns alike. */
export function humanDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  const units: Array<[number, string]> = [
    [86_400_000, 'd'], [3_600_000, 'h'], [60_000, 'm'], [1000, 's'],
  ];
  const parts: string[] = [];
  let left = ms;
  for (const [size, label] of units) {
    const value = Math.floor(left / size);
    if (value > 0) { parts.push(`${value}${label}`); left -= value * size; }
    if (parts.length === 2) break;
  }
  return parts.join(' ') || '0s';
}

/** A text progress bar, used by `,spotify` and `,rank`. */
export function progressBar(fraction: number, width = 14): string {
  const filled = Math.round(Math.min(Math.max(fraction, 0), 1) * width);
  return '─'.repeat(Math.max(filled - 1, 0)) + (filled > 0 ? '◉' : '') + '─'.repeat(width - filled);
}

/* ------------------------------------------------------------ components */

export type Row<T extends ButtonBuilder | StringSelectMenuBuilder> = ActionRowBuilder<T>;

export const buttonRow = (...buttons: ButtonBuilder[]): Row<ButtonBuilder> =>
  new ActionRowBuilder<ButtonBuilder>().addComponents(buttons);

export const selectRow = (menu: StringSelectMenuBuilder): Row<StringSelectMenuBuilder> =>
  new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(menu);

/**
 * A button is either an action (custom id) or a link (url), never both —
 * Discord rejects a link button carrying a custom id, so the type forbids it
 * rather than letting it fail at the API.
 */
export type ButtonOptions =
  | { id: string; url?: never; label?: string; emoji?: string; style?: ButtonStyle; disabled?: boolean }
  | { url: string; id?: never; label?: string; emoji?: string; style?: never; disabled?: boolean };

export function button(opts: ButtonOptions): ButtonBuilder {
  const b = new ButtonBuilder().setStyle(opts.url ? ButtonStyle.Link : opts.style ?? ButtonStyle.Secondary);
  if (opts.url) b.setURL(opts.url); else b.setCustomId(opts.id!);
  if (opts.label) b.setLabel(opts.label);
  if (opts.emoji) b.setEmoji(opts.emoji);
  if (opts.disabled) b.setDisabled(true);
  return b;
}
