/**
 * Redis layer: guild/user config memoisation, lookup caching, distributed
 * locks and the token bucket that keeps us off Discord's 429 wall.
 *
 * Key namespace is always `bounty:<domain>:<id>` so a stray FLUSH of one
 * domain never takes the rest with it.
 */

import { Redis } from 'ioredis';
import { logger } from './logger.js';

export const redis = new Redis(process.env.REDIS_URL!, {
  maxRetriesPerRequest: 3,
  enableReadyCheck: true,
  lazyConnect: false,
  // A dead Redis must not take the bot down: every helper below degrades to
  // "cache miss" instead of throwing.
  reconnectOnError: (err: Error) => err.message.includes('READONLY'),
});

redis.on('error', (err: Error) => logger.error({ err }, 'redis error'));

export const key = {
  guild: (id: string) => `bounty:guild:${id}`,
  user: (id: string) => `bounty:user:${id}`,
  vmConfig: (guildId: string) => `bounty:vm:cfg:${guildId}`,
  vmOwner: (channelId: string) => `bounty:vm:owner:${channelId}`,
  vmCooldown: (guildId: string, userId: string) => `bounty:vm:cd:${guildId}:${userId}`,
  avatarHistory: (userId: string) => `bounty:lookup:avatars:${userId}`,
  bannerHistory: (userId: string) => `bounty:lookup:banners:${userId}`,
  names: (userId: string) => `bounty:lookup:names:${userId}`,
  profile: (userId: string) => `bounty:lookup:profile:${userId}`,
  spotify: (userId: string) => `bounty:lookup:spotify:${userId}`,
  aliases: (guildId: string) => `bounty:aliases:${guildId}`,
  cooldown: (cmd: string, scope: string) => `bounty:cd:${cmd}:${scope}`,
  lock: (name: string) => `bounty:lock:${name}`,
  snipe: (channelId: string) => `bounty:snipe:${channelId}`,
};

export const TTL = {
  guildConfig: 900,      // 15m — invalidated explicitly on write
  userConfig: 900,
  assetHistory: 300,     // 5m — history only grows, staleness is harmless
  profile: 120,
  spotify: 15,           // presence changes constantly
  aliases: 600,
  snipe: 7200,
};

/* --------------------------------------------------------------- memoise */

/**
 * Read-through cache. On a Redis outage this silently falls through to the
 * loader, so a cache failure costs latency, never correctness.
 */
export async function remember<T>(
  cacheKey: string,
  ttlSeconds: number,
  loader: () => Promise<T>,
): Promise<T> {
  try {
    const hit = await redis.get(cacheKey);
    if (hit !== null) return JSON.parse(hit) as T;
  } catch (err) {
    logger.warn({ err, cacheKey }, 'cache read failed, falling through');
  }

  const value = await loader();

  try {
    // NX so two concurrent misses do not fight over the slot.
    await redis.set(cacheKey, JSON.stringify(value), 'EX', ttlSeconds);
  } catch (err) {
    logger.warn({ err, cacheKey }, 'cache write failed');
  }
  return value;
}

export async function forget(...keys: string[]): Promise<void> {
  if (!keys.length) return;
  try { await redis.del(...keys); } catch { /* best effort */ }
}

/* ----------------------------------------------------------------- locks */

/**
 * Single-holder lock. VoiceMaster uses this so two rapid joins from the same
 * user cannot spawn two channels, and so a delete and a rename never race.
 */
export async function withLock<T>(
  name: string,
  ttlMs: number,
  fn: () => Promise<T>,
): Promise<T | null> {
  const token = `${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const lockKey = key.lock(name);

  const acquired = await redis.set(lockKey, token, 'PX', ttlMs, 'NX');
  if (!acquired) return null;

  try {
    return await fn();
  } finally {
    // Compare-and-delete: never release a lock that has already expired and
    // been picked up by someone else.
    await redis.eval(
      `if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end`,
      1, lockKey, token,
    ).catch(() => undefined);
  }
}

/* ---------------------------------------------------------- rate limiting */

const BUCKET_SCRIPT = `
local current = redis.call('INCR', KEYS[1])
if current == 1 then redis.call('PEXPIRE', KEYS[1], ARGV[1]) end
local ttl = redis.call('PTTL', KEYS[1])
return {current, ttl}
`;

export interface BucketResult { hits: number; limited: boolean; retryAfterMs: number }

/** Fixed-window counter. Cheap, and precise enough for command cooldowns. */
export async function consume(
  bucketKey: string,
  limit: number,
  windowMs: number,
): Promise<BucketResult> {
  try {
    const [hits, ttl] = await redis.eval(BUCKET_SCRIPT, 1, bucketKey, windowMs) as [number, number];
    return { hits, limited: hits > limit, retryAfterMs: Math.max(ttl, 0) };
  } catch {
    // Fail open — a broken limiter should not block every command in the bot.
    return { hits: 0, limited: false, retryAfterMs: 0 };
  }
}

export async function shutdownCache(): Promise<void> {
  await redis.quit().catch(() => undefined);
}
