import pino from 'pino';

export const logger = pino({
  level: process.env.LOG_LEVEL ?? 'info',
  // Tokens must never reach a log sink, even in a serialised error object.
  redact: {
    paths: ['token', '*.token', 'tokenCiphertext', '*.tokenCiphertext', 'headers.authorization'],
    censor: '[redacted]',
  },
  transport: process.env.NODE_ENV === 'production' ? undefined : {
    target: 'pino-pretty',
    options: { colorize: true, translateTime: 'HH:MM:ss', ignore: 'pid,hostname' },
  },
});
