# Hosting Bounty on Railway

Everything lives on one site. Free for the first month, then $5/month.

## 1. Put the code on GitHub

1. Make an account at github.com.
2. Click the **+** at the top right → **New repository**.
3. Name it `bounty`, choose **Private**, click **Create repository**.
4. On the next page click **uploading an existing file**.
5. Unzip `bounty-source.zip` on your computer, open the `bounty-source`
   folder, select everything inside it, and drag it onto the page.
   Upload the *contents*, not the folder itself.
6. Click **Commit changes**.

## 2. Create the Discord bot

1. Go to discord.com/developers/applications → **New Application**.
2. Open the **Bot** tab → **Reset Token** → copy it. You only see it once.
3. On the same page turn on all three switches under
   **Privileged Gateway Intents**: Server Members, Message Content, Presence.
   Without these the bot connects but ignores everything.

## 3. Deploy on Railway

1. Sign up at railway.com with your GitHub account.
2. **New Project** → **Deploy from GitHub repo** → pick `bounty`.
3. It starts building. Ignore the failure — there is no database yet.

## 4. Add the two databases

In the same project:

1. **New** → **Database** → **Add PostgreSQL**.
2. **New** → **Database** → **Add Redis**.

Railway wires them up on its own network. Nothing to configure.

## 5. Fill in the settings

Click your **bounty** service → **Variables** tab → **New Variable**, once per
line below. Copy the `${{...}}` parts exactly, braces included — that is how
Railway points the bot at the two databases.

```
DISCORD_TOKEN         your token from step 2
DATABASE_URL          ${{Postgres.DATABASE_URL}}
REDIS_URL             ${{Redis.REDIS_URL}}
DEVELOPER_IDS         your Discord user ID
TOKEN_ENCRYPTION_KEY  any 64 random characters
LOG_LEVEL             info
```

To get your user ID: Discord → Settings → Advanced → turn on Developer Mode,
then right-click your own name → Copy User ID.

Railway redeploys automatically when you save. The bot creates its own
database tables on the first start.

## 6. Invite it to your server

1. Developer portal → **OAuth2** → **URL Generator**.
2. Tick **bot** and **applications.commands**.
3. Under permissions tick **Administrator** for now.
4. Open the link at the bottom of the page and pick your server.

## 7. Check it worked

In Railway, open your service and click **Deploy Logs**. You want a line
saying `bounty online`. Then type `,ping` in your Discord server.

## If something goes wrong

Read the last few lines of the Deploy Logs. The usual causes:

- **Used disallowed intents** — a switch in step 2.3 is still off.
- **Invalid token** — the token was copied with a space, or reset since.
- **connect ECONNREFUSED** — a `${{...}}` variable was typed wrong.

## Later

Changing a file on GitHub redeploys automatically. Watch the **Usage** tab in
Railway; a bot this size normally sits under the $5 of included credit.
