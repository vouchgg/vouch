# Bounty

Discord.js v14 · TypeScript · PostgreSQL (Drizzle) · Redis

Stack decision: **Discord.js over discord.py**. The command surface leans on
modals, user select menus and persistent panels, and d.js v14 has the tighter
typings for those. It also means the custom-bot host and the bounty.lol bio
pages share one language and one build.

```
src/
  core/
    client.ts       BountyClient, component registry, custom id codec
    command.ts      Command tree contract, Context, argument parsers
    registry.ts     Dynamic loader + greedy subcommand resolver
    middleware.ts   Guard pipeline + hierarchy assertions
    branding.ts     The only place an embed is constructed
    errors.ts       Error taxonomy, Discord API code translation
    cache.ts        Redis: memoisation, locks, token buckets
  db/
    schema.ts       Full Postgres schema
    index.ts        Pool + cached config accessors
  events/
    messageCreate.ts    Prefix dispatcher, single error boundary
    interactionCreate.ts Component router, expiry-safe replies
    guildCreate.ts      Welcome message on server install
  modules/
    logging/        18 log categories, batched delivery, audit-log attribution
    greetings/      welcome, goodbye and boost cards
    invites/        invite attribution, leaderboard, rewards
    stats/          serverinfo, membercount, growth, counter channels
    moderation/     cases, punishments, purge filters
    lookups/        avatars, banners, history, userinfo, spotify
    utility/        roles, snipes, config, help
    onboarding/
      welcome.ts      Greeting payloads for server and account installs
      webhookEvents.ts Signed HTTP endpoint for account installs
    voicemaster/
      engine.ts       voiceStateUpdate engine
      interface.ts    Control panel + modal/select handlers
      commands/       ,vc and ,voicemaster trees
```

## Running it

```bash
cp .env.example .env      # token, DATABASE_URL, REDIS_URL
npm install
npm run db:push           # or db:generate for a migration file
npm run dev
```

`npm run typecheck` compiles clean.

## Three ideas worth knowing before you extend it

**Commands are a tree, not a switch.** `,vc lock`, `,voicemaster default name`
and `,purge bots` all resolve through the same greedy walk in `registry.ts`.
A leaf receives only the arguments that follow it, so no handler inspects
`args[0]` to work out what it is. Adding a subcommand is adding a key to an
object.

**The engine owns state, commands and buttons are both thin.** `,vc lock` and
the Lock button on the panel both call `engine.setLock()`. There is no second
implementation to fall out of sync, and the panel needs no state in its custom
id — ownership is read from Postgres at click time, so a panel posted months
ago still works after any number of ownership transfers.

**Errors are a vocabulary.** Handlers throw `UsageError`, `PermissionError`,
`HierarchyError` and friends; the dispatcher catches once and renders once.
Discord API codes are translated in `errors.ts`, so a 50013 becomes "Bounty is
not allowed to do that here. Check the channel overwrites as well as the role
permissions." Internal failures get a trace id and a generic line — stack
traces never reach chat.

## Command count

Counted by loading the real registry, not by hand:

```
runnable commands : 187
groups            :  25   (,log  ,purge  ,vc … parents)
aliases           : 221
invokable names   : 433
```

`npm run count` prints this. What you type is one of 433 names; those resolve
to 187 things that actually do something. Bot listing sites quote the first
number, so 433 is the honest headline figure — but 187 is the real answer to
"how many things can this do".

## Built so far

- Schema for guilds, users, asset/name history, VoiceMaster, tickets,
  giveaways, custom bot tokens, booster roles and command aliases
- Command handler, middleware pipeline, interaction router
- VoiceMaster: join-to-create, grace-period cleanup, claim and transfer,
  trusted co-owners, persisted per-user settings, orphan sweep on boot
- Control panel with icon buttons, modals and user pickers
- Welcome message on install, for both servers and accounts
- Logging across 18 categories with webhook delivery and image mirroring
- Welcome, goodbye and boost cards with variables, auto roles and DM copies
- Invite tracking with attribution, leaderboard, fake detection and rewards
- Server stats: member movement by day, growth chart, live counter channels
- Moderation with numbered cases, jail role setup and 18 purge filters
- Lookups, role management, snipes, aliases and help

## The welcome message

Two entry points, one greeting.

**Server installs** come through the `guildCreate` gateway event. The greeting
goes to the system channel, then a channel named something like `general` or
`bot-commands`, then the first text channel Bounty can actually speak in — and
if there is none, the owner gets it by DM instead. A Redis key holds for 24
hours so re-adding the bot twice does not post twice.

**Account installs** fire no gateway event at all. Discord only reports them
over HTTP, so `webhookEvents.ts` runs a small signed endpoint:

1. Developer portal → Bot → Webhooks, set the Events URL to
   `https://your-host/` on `WEBHOOK_PORT`, and subscribe to
   `APPLICATION_AUTHORIZED`.
2. Copy the app's public key into `DISCORD_PUBLIC_KEY`.

Every request is Ed25519-signed and unsigned requests get a 401 — Discord
tests exactly that before it accepts the URL. The endpoint answers within
Discord's 3-second window and sends the DM afterwards, off the request.
Verified against valid signatures, forged signatures, missing headers and
wrong methods.

## Hosting

```bash
cp .env.example .env      # token, DISCORD_PUBLIC_KEY, POSTGRES_PASSWORD
docker compose up -d --build
```

The bot applies its own migrations at boot from the SQL in `drizzle/`, so
there is no separate database step. After changing `schema.ts`, run
`npm run db:generate` and commit the new SQL file.

Postgres and Redis come up alongside the bot. Redis runs with no persistence
and an LRU cap, because everything in it — snipes, caches, invite snapshots —
is rebuildable. The exposed port is only needed if you want account-install
welcome DMs.

## Next

Lookups (`,avatarhistory`, `,pastnames`, `,spotify`) with the Redis read-through
already wired in `cache.ts`; tickets; giveaways with the due-index scheduler;
the custom bot host worker.

## The website

`site/` is a static site — no build step, no framework. Open `site/index.html`
or drop the folder on Netlify, Vercel, Cloudflare Pages or GitHub Pages.

```bash
npm run site:commands   # regenerates site/commands.json from the bot
```

The commands page reads that file, so the list on the site is the command tree
the bot actually loaded — rename a command and the site follows. The status page
reads `GET /shards` from the bot's own HTTP server, so set `WEBHOOK_PORT` and
point `window.BOUNTY_API` at `https://your-host/shards`.

Pages: landing, commands (searchable, filtered by group), status, terms,
privacy. The legal pages describe what the schema really stores — have someone
read them before you launch.

## Brand

`index.html` shows the logo at real Discord sizes and exports the files.

- `bounty-app-icon.svg` / `bounty-app-icon-512.png` — purple grid plate with
  the glowing sparkle. This is what goes in the developer portal.
- `bounty-mark.svg` — the sparkle pair on its own, using `currentColor`.
- `bounty-mark-solo.svg` — one sparkle, for favicons and anywhere under 32px
  where the small spark just becomes a smudge.

Colours: void `#0E0618`, deep `#1A0B2E`, violet `#5B2E9D` (the default embed
colour, set in the schema), lilac `#B98CFF` for grid lines and live state.
The mark itself stays plain white so it works on any background.
