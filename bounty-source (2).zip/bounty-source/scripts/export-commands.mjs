/**
 * Walks the real command registry and writes site/commands.json.
 *
 * The website's command list is generated from the bot itself, so it cannot
 * drift: a command that is renamed, gains a permission or is deleted shows up
 * on the site the next time this runs.
 */
import { CommandRegistry } from '../dist/core/registry.js';
import { PermissionsBitField } from 'discord.js';
import { writeFile, mkdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

process.env.LOG_LEVEL ??= 'silent';
const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, '..');

const registry = new CommandRegistry();
await registry.loadAll(path.join(root, 'dist', 'modules'));

/** Display groups on the site, mapped from the bot's internal module names. */
const GROUPS = {
  Utility: 'server',
  Moderation: 'moderation',
  Lookups: 'information',
  VoiceMaster: 'voice',
  Aesthetic: 'roles',
  Giveaways: 'giveaways',
  Tickets: 'tickets',
  LastFM: 'last.fm',
  Bio: 'bio',
  CustomInstanceHost: 'hosting',
};

/**
 * Permissions are stored as bitfield flags, so 32 has to become "Manage Guild"
 * before it goes anywhere near the website.
 */
const prettyPermission = (value) => {
  const names = typeof value === 'string'
    ? [value]
    : new PermissionsBitField(value).toArray();
  return names.map((name) => name.replace(/([a-z])([A-Z])/g, '$1 $2'));
};

/** Pulls <angle> and [square] argument names out of a usage string. */
const argsFrom = (usage, name) => {
  if (!usage) return [];
  return [...usage.matchAll(/[<[]([^>\]]+)[>\]]/g)].map((m) => m[1].split('|')[0].trim());
};

const commands = [];

const walk = (command, trail, inherited) => {
  const path = [...trail, command.name];
  const permissions = [
    ...inherited,
    ...(command.userPermissions ?? []).flatMap(prettyPermission),
  ];

  if (command.execute) {
    commands.push({
      name: path.join(' '),
      description: command.description,
      group: GROUPS[command.module] ?? 'server',
      aliases: command.aliases ?? [],
      args: argsFrom(command.usage, command.name),
      permissions: [...new Set(permissions)],
      usage: command.usage ? `,${command.usage}` : `,${path.join(' ')}`,
      examples: (command.examples ?? []).map((e) => `,${e}`),
      premium: Boolean(command.premium),
    });
  }

  for (const child of Object.values(command.subcommands ?? {})) {
    walk(child, path, permissions);
  }
};

for (const command of registry.commands.values()) walk(command, [], []);

commands.sort((a, b) => a.name.localeCompare(b.name));

const groups = {};
for (const command of commands) {
  groups[command.group] = (groups[command.group] ?? 0) + 1;
}

const payload = {
  generatedAt: new Date().toISOString(),
  total: commands.length,
  aliasCount: commands.reduce((n, c) => n + c.aliases.length, 0),
  groups: Object.entries(groups)
    .sort((a, b) => b[1] - a[1])
    .map(([name, count]) => ({ name, count })),
  commands,
};

await mkdir(path.join(root, 'site'), { recursive: true });
await writeFile(path.join(root, 'site', 'commands.json'), JSON.stringify(payload, null, 2));

console.log(`wrote site/commands.json — ${payload.total} commands, ${payload.aliasCount} aliases`);
for (const g of payload.groups) console.log(`  ${g.name.padEnd(14)} ${g.count}`);
process.exit(0);
