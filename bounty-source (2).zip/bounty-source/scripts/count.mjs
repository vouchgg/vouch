/** Counts the command surface by loading the real registry. */
import { CommandRegistry } from '../dist/core/registry.js';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

process.env.LOG_LEVEL ??= 'silent';
const here = path.dirname(fileURLToPath(import.meta.url));

const registry = new CommandRegistry();
await registry.loadAll(path.join(here, '..', 'dist', 'modules'));

let leaves = 0, groups = 0, aliases = 0;
const byModule = {};

const walk = (command) => {
  aliases += (command.aliases ?? []).length;
  const children = Object.values(command.subcommands ?? {});
  if (children.length) groups += 1;
  if (command.execute) {
    leaves += 1;
    byModule[command.module] = (byModule[command.module] ?? 0) + 1;
  }
  children.forEach(walk);
};

for (const command of registry.commands.values()) walk(command);

console.log(`runnable commands : ${leaves}`);
console.log(`groups            : ${groups}`);
console.log(`aliases           : ${aliases}`);
console.log(`invokable names   : ${leaves + groups + aliases}\n`);
for (const [module, n] of Object.entries(byModule).sort((a, b) => b[1] - a[1])) {
  console.log(`  ${module.padEnd(20)} ${n}`);
}
process.exit(0);
