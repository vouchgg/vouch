CREATE TYPE "public"."activity_type" AS ENUM('playing', 'listening', 'watching', 'competing', 'streaming');--> statement-breakpoint
CREATE TYPE "public"."asset_type" AS ENUM('avatar', 'banner', 'guild_avatar');--> statement-breakpoint
CREATE TYPE "public"."case_kind" AS ENUM('ban', 'unban', 'softban', 'kick', 'timeout', 'untimeout', 'jail', 'unjail', 'warn', 'unwarn', 'purge', 'lockdown');--> statement-breakpoint
CREATE TYPE "public"."counter_kind" AS ENUM('members', 'humans', 'bots', 'boosters', 'online', 'channels', 'roles', 'joins_today');--> statement-breakpoint
CREATE TYPE "public"."custom_bot_status" AS ENUM('offline', 'starting', 'online', 'invalid_token', 'suspended');--> statement-breakpoint
CREATE TYPE "public"."giveaway_status" AS ENUM('running', 'ended', 'cancelled');--> statement-breakpoint
CREATE TYPE "public"."greet_kind" AS ENUM('welcome', 'goodbye', 'boost');--> statement-breakpoint
CREATE TYPE "public"."log_category" AS ENUM('messages', 'images', 'members', 'moderation', 'roles', 'channels', 'voice', 'invites', 'server', 'emojis', 'threads', 'webhooks', 'boosts', 'automod', 'bots', 'nicknames', 'avatars', 'reactions');--> statement-breakpoint
CREATE TYPE "public"."member_event_kind" AS ENUM('join', 'leave');--> statement-breakpoint
CREATE TYPE "public"."name_change_type" AS ENUM('username', 'global_name', 'nickname');--> statement-breakpoint
CREATE TYPE "public"."presence_status" AS ENUM('online', 'idle', 'dnd', 'invisible');--> statement-breakpoint
CREATE TYPE "public"."ticket_status" AS ENUM('open', 'claimed', 'closed', 'deleted');--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "asset_history" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"user_id" varchar(20) NOT NULL,
	"type" "asset_type" NOT NULL,
	"guild_id" varchar(20),
	"hash" varchar(64) NOT NULL,
	"stored_url" text NOT NULL,
	"animated" boolean DEFAULT false NOT NULL,
	"accent_color" varchar(6),
	"first_seen_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_seen_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "booster_roles" (
	"guild_id" varchar(20) NOT NULL,
	"user_id" varchar(20) NOT NULL,
	"role_id" varchar(20) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "booster_roles_guild_id_user_id_pk" PRIMARY KEY("guild_id","user_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "command_aliases" (
	"guild_id" varchar(20) NOT NULL,
	"alias" varchar(32) NOT NULL,
	"target" varchar(128) NOT NULL,
	"created_by" varchar(20) NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "command_aliases_guild_id_alias_pk" PRIMARY KEY("guild_id","alias")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "counter_channels" (
	"channel_id" varchar(20) PRIMARY KEY NOT NULL,
	"guild_id" varchar(20) NOT NULL,
	"kind" "counter_kind" NOT NULL,
	"template" varchar(64) DEFAULT 'Members: {count}' NOT NULL,
	"last_value" integer,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "custom_bots" (
	"id" serial PRIMARY KEY NOT NULL,
	"owner_id" varchar(20) NOT NULL,
	"guild_id" varchar(20) NOT NULL,
	"token_ciphertext" text NOT NULL,
	"token_iv" varchar(32) NOT NULL,
	"token_auth_tag" varchar(32) NOT NULL,
	"token_fingerprint" varchar(64) NOT NULL,
	"application_id" varchar(20),
	"bot_user_id" varchar(20),
	"bot_username" varchar(32),
	"prefix" varchar(8) DEFAULT ',' NOT NULL,
	"status" "custom_bot_status" DEFAULT 'offline' NOT NULL,
	"activity_kind" "activity_type",
	"activity_text" varchar(128),
	"stream_url" text,
	"presence" "presence_status" DEFAULT 'online' NOT NULL,
	"worker_id" varchar(64),
	"last_started_at" timestamp with time zone,
	"last_error" text,
	"restart_count" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "giveaway_entries" (
	"giveaway_id" integer NOT NULL,
	"user_id" varchar(20) NOT NULL,
	"weight" smallint DEFAULT 1 NOT NULL,
	"entered_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "giveaway_entries_giveaway_id_user_id_pk" PRIMARY KEY("giveaway_id","user_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "giveaways" (
	"id" serial PRIMARY KEY NOT NULL,
	"guild_id" varchar(20) NOT NULL,
	"channel_id" varchar(20) NOT NULL,
	"message_id" varchar(20) NOT NULL,
	"host_id" varchar(20) NOT NULL,
	"prize" varchar(256) NOT NULL,
	"description" text,
	"winner_count" smallint DEFAULT 1 NOT NULL,
	"requirements" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"status" "giveaway_status" DEFAULT 'running' NOT NULL,
	"winner_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"entry_count" integer DEFAULT 0 NOT NULL,
	"ends_at" timestamp with time zone NOT NULL,
	"ended_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "greet_configs" (
	"guild_id" varchar(20) NOT NULL,
	"kind" "greet_kind" NOT NULL,
	"channel_id" varchar(20),
	"content" text,
	"embed_json" jsonb,
	"delete_after" smallint DEFAULT 0 NOT NULL,
	"dm_enabled" boolean DEFAULT false NOT NULL,
	"dm_content" text,
	"auto_role_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "greet_configs_guild_id_kind_pk" PRIMARY KEY("guild_id","kind")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "guild_moderation" (
	"guild_id" varchar(20) PRIMARY KEY NOT NULL,
	"jail_role_id" varchar(20),
	"jail_channel_id" varchar(20),
	"mute_role_id" varchar(20),
	"min_account_age_days" smallint DEFAULT 7 NOT NULL,
	"dm_on_punish" boolean DEFAULT true NOT NULL,
	"delete_invoke_message" boolean DEFAULT false NOT NULL,
	"next_case_number" integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "guilds" (
	"id" varchar(20) PRIMARY KEY NOT NULL,
	"prefix" varchar(8) DEFAULT ',' NOT NULL,
	"embed_color" varchar(6) DEFAULT '5B2E9D' NOT NULL,
	"footer_text" varchar(128),
	"footer_icon_url" text,
	"timestamp_style" varchar(16) DEFAULT 'relative' NOT NULL,
	"locale" varchar(8) DEFAULT 'en-GB' NOT NULL,
	"premium_until" timestamp with time zone,
	"blacklisted" boolean DEFAULT false NOT NULL,
	"blacklist_reason" text,
	"disabled_modules" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"command_overrides" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"joined_at" timestamp with time zone DEFAULT now() NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "invite_adjustments" (
	"guild_id" varchar(20) NOT NULL,
	"user_id" varchar(20) NOT NULL,
	"bonus" integer DEFAULT 0 NOT NULL,
	CONSTRAINT "invite_adjustments_guild_id_user_id_pk" PRIMARY KEY("guild_id","user_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "invite_attribution" (
	"guild_id" varchar(20) NOT NULL,
	"user_id" varchar(20) NOT NULL,
	"inviter_id" varchar(20),
	"code" varchar(32),
	"fake" boolean DEFAULT false NOT NULL,
	"valid" boolean DEFAULT true NOT NULL,
	"rejoins" smallint DEFAULT 0 NOT NULL,
	"joined_at" timestamp with time zone DEFAULT now() NOT NULL,
	"left_at" timestamp with time zone,
	CONSTRAINT "invite_attribution_guild_id_user_id_pk" PRIMARY KEY("guild_id","user_id")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "invite_codes" (
	"code" varchar(32) PRIMARY KEY NOT NULL,
	"guild_id" varchar(20) NOT NULL,
	"inviter_id" varchar(20),
	"channel_id" varchar(20),
	"uses" integer DEFAULT 0 NOT NULL,
	"max_uses" integer DEFAULT 0 NOT NULL,
	"expires_at" timestamp with time zone,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "invite_rewards" (
	"id" serial PRIMARY KEY NOT NULL,
	"guild_id" varchar(20) NOT NULL,
	"threshold" integer NOT NULL,
	"role_id" varchar(20) NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "log_channels" (
	"guild_id" varchar(20) NOT NULL,
	"category" "log_category" NOT NULL,
	"channel_id" varchar(20) NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"webhook_id" varchar(20),
	"webhook_token" text,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "log_channels_guild_id_category_pk" PRIMARY KEY("guild_id","category")
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "log_settings" (
	"guild_id" varchar(20) PRIMARY KEY NOT NULL,
	"ignored_channel_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"ignored_user_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"ignored_role_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"ignore_bots" boolean DEFAULT true NOT NULL,
	"mirror_attachments" boolean DEFAULT true NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "member_events" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"guild_id" varchar(20) NOT NULL,
	"user_id" varchar(20) NOT NULL,
	"kind" "member_event_kind" NOT NULL,
	"member_count" integer,
	"at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "mod_cases" (
	"id" serial PRIMARY KEY NOT NULL,
	"guild_id" varchar(20) NOT NULL,
	"case_number" integer NOT NULL,
	"kind" "case_kind" NOT NULL,
	"target_id" varchar(20) NOT NULL,
	"moderator_id" varchar(20) NOT NULL,
	"reason" text,
	"restore_role_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"expires_at" timestamp with time zone,
	"active" boolean DEFAULT true NOT NULL,
	"log_message_id" varchar(20),
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "name_history" (
	"id" bigserial PRIMARY KEY NOT NULL,
	"user_id" varchar(20) NOT NULL,
	"type" "name_change_type" NOT NULL,
	"guild_id" varchar(20),
	"previous_value" varchar(64),
	"new_value" varchar(64),
	"changed_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "ticket_panels" (
	"id" serial PRIMARY KEY NOT NULL,
	"guild_id" varchar(20) NOT NULL,
	"channel_id" varchar(20) NOT NULL,
	"message_id" varchar(20),
	"title" varchar(256) DEFAULT 'Support' NOT NULL,
	"description" text,
	"color" varchar(6),
	"category_id" varchar(20),
	"transcript_channel_id" varchar(20),
	"support_role_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"channel_name_template" varchar(64) DEFAULT 'ticket-{number}' NOT NULL,
	"options" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"per_user_limit" smallint DEFAULT 1 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "tickets" (
	"id" serial PRIMARY KEY NOT NULL,
	"guild_id" varchar(20) NOT NULL,
	"panel_id" integer,
	"channel_id" varchar(20) NOT NULL,
	"number" integer NOT NULL,
	"owner_id" varchar(20) NOT NULL,
	"claimed_by" varchar(20),
	"topic" varchar(64),
	"form_responses" jsonb,
	"added_user_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"status" "ticket_status" DEFAULT 'open' NOT NULL,
	"transcript_url" text,
	"message_count" integer DEFAULT 0 NOT NULL,
	"opened_at" timestamp with time zone DEFAULT now() NOT NULL,
	"closed_at" timestamp with time zone,
	"closed_by" varchar(20),
	"close_reason" text
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "users" (
	"id" varchar(20) PRIMARY KEY NOT NULL,
	"embed_color" varchar(6),
	"lastfm_username" varchar(64),
	"lastfm_session_key" text,
	"bio_slug" varchar(32),
	"timezone" varchar(48),
	"blacklisted" boolean DEFAULT false NOT NULL,
	"blacklist_reason" text,
	"history_opt_out" boolean DEFAULT false NOT NULL,
	"first_seen_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_seen_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "vm_channels" (
	"channel_id" varchar(20) PRIMARY KEY NOT NULL,
	"guild_id" varchar(20) NOT NULL,
	"owner_id" varchar(20) NOT NULL,
	"claimable" boolean DEFAULT false NOT NULL,
	"locked" boolean DEFAULT false NOT NULL,
	"hidden" boolean DEFAULT false NOT NULL,
	"trusted_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_empty_at" timestamp with time zone
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "vm_configs" (
	"guild_id" varchar(20) PRIMARY KEY NOT NULL,
	"generator_channel_id" varchar(20) NOT NULL,
	"category_id" varchar(20) NOT NULL,
	"interface_channel_id" varchar(20),
	"interface_message_id" varchar(20),
	"name_template" varchar(64) DEFAULT '{user}''s channel' NOT NULL,
	"default_limit" smallint DEFAULT 0 NOT NULL,
	"default_bitrate" integer DEFAULT 64000 NOT NULL,
	"default_region" varchar(24),
	"empty_grace_seconds" smallint DEFAULT 5 NOT NULL,
	"auto_transfer_owner" boolean DEFAULT false NOT NULL,
	"persist_user_settings" boolean DEFAULT true NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS "vm_user_settings" (
	"guild_id" varchar(20) NOT NULL,
	"user_id" varchar(20) NOT NULL,
	"name" varchar(100),
	"user_limit" smallint,
	"bitrate" integer,
	"region" varchar(24),
	"locked" boolean DEFAULT false NOT NULL,
	"hidden" boolean DEFAULT false NOT NULL,
	"permitted_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"rejected_ids" jsonb DEFAULT '[]'::jsonb NOT NULL,
	"updated_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "vm_user_settings_guild_id_user_id_pk" PRIMARY KEY("guild_id","user_id")
);
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "asset_history" ADD CONSTRAINT "asset_history_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "booster_roles" ADD CONSTRAINT "booster_roles_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "command_aliases" ADD CONSTRAINT "command_aliases_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "counter_channels" ADD CONSTRAINT "counter_channels_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "custom_bots" ADD CONSTRAINT "custom_bots_owner_id_users_id_fk" FOREIGN KEY ("owner_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "custom_bots" ADD CONSTRAINT "custom_bots_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "giveaway_entries" ADD CONSTRAINT "giveaway_entries_giveaway_id_giveaways_id_fk" FOREIGN KEY ("giveaway_id") REFERENCES "public"."giveaways"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "giveaways" ADD CONSTRAINT "giveaways_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "greet_configs" ADD CONSTRAINT "greet_configs_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "guild_moderation" ADD CONSTRAINT "guild_moderation_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "invite_adjustments" ADD CONSTRAINT "invite_adjustments_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "invite_attribution" ADD CONSTRAINT "invite_attribution_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "invite_codes" ADD CONSTRAINT "invite_codes_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "invite_rewards" ADD CONSTRAINT "invite_rewards_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "log_channels" ADD CONSTRAINT "log_channels_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "log_settings" ADD CONSTRAINT "log_settings_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "member_events" ADD CONSTRAINT "member_events_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "mod_cases" ADD CONSTRAINT "mod_cases_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "name_history" ADD CONSTRAINT "name_history_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "ticket_panels" ADD CONSTRAINT "ticket_panels_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "tickets" ADD CONSTRAINT "tickets_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "tickets" ADD CONSTRAINT "tickets_panel_id_ticket_panels_id_fk" FOREIGN KEY ("panel_id") REFERENCES "public"."ticket_panels"("id") ON DELETE set null ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "vm_channels" ADD CONSTRAINT "vm_channels_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "vm_configs" ADD CONSTRAINT "vm_configs_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
DO $$ BEGIN
 ALTER TABLE "vm_user_settings" ADD CONSTRAINT "vm_user_settings_guild_id_guilds_id_fk" FOREIGN KEY ("guild_id") REFERENCES "public"."guilds"("id") ON DELETE cascade ON UPDATE no action;
EXCEPTION
 WHEN duplicate_object THEN null;
END $$;
--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "asset_history_uniq" ON "asset_history" USING btree ("user_id","type","hash");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "asset_history_lookup_idx" ON "asset_history" USING btree ("user_id","type","first_seen_at" DESC NULLS LAST);--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "booster_roles_role_idx" ON "booster_roles" USING btree ("role_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "counter_channels_guild_idx" ON "counter_channels" USING btree ("guild_id");--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "custom_bots_fingerprint_idx" ON "custom_bots" USING btree ("token_fingerprint");--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "custom_bots_guild_idx" ON "custom_bots" USING btree ("guild_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "custom_bots_worker_idx" ON "custom_bots" USING btree ("worker_id","status");--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "giveaways_message_idx" ON "giveaways" USING btree ("message_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "giveaways_due_idx" ON "giveaways" USING btree ("status","ends_at");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "giveaways_guild_idx" ON "giveaways" USING btree ("guild_id","status");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "invite_attribution_leaderboard_idx" ON "invite_attribution" USING btree ("guild_id","inviter_id","valid");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "invite_codes_guild_idx" ON "invite_codes" USING btree ("guild_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "invite_codes_inviter_idx" ON "invite_codes" USING btree ("guild_id","inviter_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "invite_rewards_guild_idx" ON "invite_rewards" USING btree ("guild_id","threshold");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "log_channels_guild_idx" ON "log_channels" USING btree ("guild_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "member_events_window_idx" ON "member_events" USING btree ("guild_id","at");--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "mod_cases_number_idx" ON "mod_cases" USING btree ("guild_id","case_number");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "mod_cases_target_idx" ON "mod_cases" USING btree ("guild_id","target_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "mod_cases_due_idx" ON "mod_cases" USING btree ("active","expires_at");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "name_history_lookup_idx" ON "name_history" USING btree ("user_id","changed_at" DESC NULLS LAST);--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "name_history_guild_idx" ON "name_history" USING btree ("guild_id","user_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "ticket_panels_guild_idx" ON "ticket_panels" USING btree ("guild_id");--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "ticket_panels_message_idx" ON "ticket_panels" USING btree ("message_id");--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "tickets_channel_idx" ON "tickets" USING btree ("channel_id");--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "tickets_number_idx" ON "tickets" USING btree ("guild_id","number");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "tickets_open_by_user_idx" ON "tickets" USING btree ("guild_id","owner_id","status");--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "users_bio_slug_idx" ON "users" USING btree ("bio_slug");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "users_lastfm_idx" ON "users" USING btree ("lastfm_username");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "vm_channels_guild_idx" ON "vm_channels" USING btree ("guild_id");--> statement-breakpoint
CREATE INDEX IF NOT EXISTS "vm_channels_owner_idx" ON "vm_channels" USING btree ("guild_id","owner_id");--> statement-breakpoint
CREATE UNIQUE INDEX IF NOT EXISTS "vm_configs_generator_idx" ON "vm_configs" USING btree ("generator_channel_id");